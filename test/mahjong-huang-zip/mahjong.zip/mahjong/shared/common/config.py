"""共享配置模块"""
from pydantic import BaseSettings, Field
from typing import Optional
import os


class Settings(BaseSettings):
    """应用配置"""
    # 应用配置
    APP_NAME: str = "unmanned-system"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = Field(default=False, env="DEBUG")
    
    # 数据库配置
    DATABASE_URL: str = Field(..., env="DATABASE_URL")
    DATABASE_POOL_SIZE: int = Field(default=20, env="DATABASE_POOL_SIZE")
    DATABASE_MAX_OVERFLOW: int = Field(default=30, env="DATABASE_MAX_OVERFLOW")
    
    # Redis配置
    REDIS_URL: str = Field(..., env="REDIS_URL")
    REDIS_POOL_SIZE: int = Field(default=10, env="REDIS_POOL_SIZE")
    
    # JWT配置
    JWT_SECRET_KEY: str = Field(..., env="JWT_SECRET_KEY")
    JWT_ALGORITHM: str = Field(default="HS256", env="JWT_ALGORITHM")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=30, env="ACCESS_TOKEN_EXPIRE_MINUTES")
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(default=7, env="REFRESH_TOKEN_EXPIRE_DAYS")
    
    # 消息队列配置
    RABBITMQ_URL: str = Field(..., env="RABBITMQ_URL")
    
    # 微信支付配置
    WECHAT_APP_ID: Optional[str] = Field(default=None, env="WECHAT_APP_ID")
    WECHAT_MCH_ID: Optional[str] = Field(default=None, env="WECHAT_MCH_ID")
    WECHAT_API_KEY: Optional[str] = Field(default=None, env="WECHAT_API_KEY")
    WECHAT_SECRET_KEY: Optional[str] = Field(default=None, env="WECHAT_SECRET_KEY")
    
    # 监控配置
    SENTRY_DSN: Optional[str] = Field(default=None, env="SENTRY_DSN")
    PROMETHEUS_PORT: int = Field(default=8000, env="PROMETHEUS_PORT")
    
    # API配置
    API_V1_PREFIX: str = "/api/v1"
    CORS_ORIGINS: list = Field(default=["*"], env="CORS_ORIGINS")
    
    # 日志配置
    LOG_LEVEL: str = Field(default="INFO", env="LOG_LEVEL")
    LOG_FORMAT: str = Field(default="json", env="LOG_FORMAT")
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# 全局配置实例
settings = Settings()


class DatabaseConfig:
    """数据库配置"""
    @staticmethod
    def get_async_database_url() -> str:
        """获取异步数据库URL"""
        url = settings.DATABASE_URL
        if url.startswith("mysql://"):
            return url.replace("mysql://", "mysql+aiomysql://", 1)
        elif url.startswith("postgresql://"):
            return url.replace("postgresql://", "postgresql+asyncpg://", 1)
        return url


class RedisConfig:
    """Redis配置"""
    @staticmethod
    def get_redis_config():
        """获取Redis配置"""
        from urllib.parse import urlparse
        
        parsed = urlparse(settings.REDIS_URL)
        return {
            "host": parsed.hostname or "localhost",
            "port": parsed.port or 6379,
            "password": parsed.password,
            "db": int(parsed.path[1:]) if parsed.path else 0,
        }


class ServiceConfig:
    """服务配置"""
    SERVICE_PORTS = {
        "user-service": 8001,
        "store-service": 8002,
        "order-service": 8003,
        "payment-service": 8004,
        "iot-service": 8005,
        "groupbuy-service": 8006,
        "analytics-service": 8007,
    }
