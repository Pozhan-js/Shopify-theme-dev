"""
安全防护中间件
提供身份认证、权限控制、数据加密等安全功能
"""
import re
import jwt
import hashlib
import secrets
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from fastapi import HTTPException, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession

from .config import settings
from ..database import get_db

class SecurityMiddleware:
    """安全中间件"""
    
    def __init__(self):
        self.secret_key = settings.SECRET_KEY
        self.algorithm = "HS256"
        self.access_token_expire_minutes = 30
        self.refresh_token_expire_days = 7
        
    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None):
        """创建访问令牌"""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=self.access_token_expire_minutes)
        
        to_encode.update({"exp": expire, "type": "access"})
        encoded_jwt = jwt.encode(to_encode, self.secret_key, algorithm=self.algorithm)
        return encoded_jwt
    
    def create_refresh_token(self, data: dict):
        """创建刷新令牌"""
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(days=self.refresh_token_expire_days)
        to_encode.update({"exp": expire, "type": "refresh"})
        encoded_jwt = jwt.encode(to_encode, self.secret_key, algorithm=self.algorithm)
        return encoded_jwt
    
    def verify_token(self, token: str, token_type: str = "access") -> Dict[str, Any]:
        """验证令牌"""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            
            # 验证令牌类型
            if payload.get("type") != token_type:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="无效的令牌类型"
                )
            
            # 检查过期时间
            exp = payload.get("exp")
            if exp is None or datetime.utcnow() > datetime.fromtimestamp(exp):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="令牌已过期"
                )
            
            return payload
            
        except jwt.PyJWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="无效的令牌"
            )

class InputValidator:
    """输入验证器"""
    
    @staticmethod
    def validate_phone(phone: str) -> bool:
        """验证手机号格式"""
        pattern = r'^1[3-9]\d{9}$'
        return bool(re.match(pattern, phone))
    
    @staticmethod
    def validate_email(email: str) -> bool:
        """验证邮箱格式"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    @staticmethod
    def validate_password(password: str) -> bool:
        """验证密码强度"""
        if len(password) < 8:
            return False
        if not re.search(r'[A-Z]', password):
            return False
        if not re.search(r'[a-z]', password):
            return False
        if not re.search(r'\d', password):
            return False
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            return False
        return True
    
    @staticmethod
    def sanitize_input(input_str: str) -> str:
        """清理输入，防止XSS攻击"""
        if not isinstance(input_str, str):
            return str(input_str)
        
        # 移除HTML标签
        input_str = re.sub(r'<[^>]+>', '', input_str)
        
        # 转义特殊字符
        input_str = input_str.replace('&', '&')
        input_str = input_str.replace('<', '<')
        input_str = input_str.replace('>', '>')
        input_str = input_str.replace('"', '"')
        input_str = input_str.replace("'", '&#x27;')
        
        return input_str.strip()

class SQLInjectionProtector:
    """SQL注入防护"""
    
    @staticmethod
    def validate_query(query: str) -> bool:
        """验证查询字符串"""
        # 检测SQL注入关键字
        sql_keywords = [
            'select', 'insert', 'update', 'delete', 'drop', 'create',
            'alter', 'exec', 'execute', 'union', 'where', 'or', 'and',
            'like', 'in', 'between', 'having', 'group', 'order'
        ]
        
        query_lower = query.lower()
        for keyword in sql_keywords:
            if keyword in query_lower:
                return False
        return True
    
    @staticmethod
    def escape_string(input_str: str) -> str:
        """转义字符串"""
        if not isinstance(input_str, str):
            return str(input_str)
        
        # 转义SQL特殊字符
        input_str = input_str.replace("'", "''")
        input_str = input_str.replace('"', '""')
        input_str = input_str.replace('\\', '\\\\')
        
        return input_str

class RateLimiter:
    """限流器"""
    
    def __init__(self):
        self.requests = {}
        self.max_requests = 100
        self.window_seconds = 60
    
    def is_allowed(self, client_ip: str) -> bool:
        """检查是否允许请求"""
        now = datetime.utcnow()
        
        if client_ip not in self.requests:
            self.requests[client_ip] = []
        
        # 清理过期请求
        self.requests[client_ip] = [
            req_time for req_time in self.requests[client_ip]
            if now - req_time < timedelta(seconds=self.window_seconds)
        ]
        
        # 检查请求数量
        if len(self.requests[client_ip]) >= self.max_requests:
            return False
        
        # 记录新请求
        self.requests[client_ip].append(now)
        return True

class EncryptionService:
    """加密服务"""
    
    @staticmethod
    def hash_password(password: str) -> str:
        """密码哈希"""
        salt = secrets.token_hex(16)
        password_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        )
        return f"{salt}${password_hash.hex()}"
    
    @staticmethod
    def verify_password(password: str, hashed: str) -> bool:
        """验证密码"""
        try:
            salt, hash_hex = hashed.split('$')
            password_hash = hashlib.pbkdf2_hmac(
                'sha256',
                password.encode('utf-8'),
                salt.encode('utf-8'),
                100000
            )
            return password_hash.hex() == hash_hex
        except:
            return False
    
    @staticmethod
    def encrypt_sensitive_data(data: str) -> str:
        """加密敏感数据"""
        # 使用Fernet对称加密
        from cryptography.fernet import Fernet
        f = Fernet(settings.ENCRYPTION_KEY.encode())
        return f.encrypt(data.encode()).decode()
    
    @staticmethod
    def decrypt_sensitive_data(encrypted_data: str) -> str:
        """解密敏感数据"""
        from cryptography.fernet import Fernet
        f = Fernet(settings.ENCRYPTION_KEY.encode())
        return f.decrypt(encrypted_data.encode()).decode()

class PermissionChecker:
    """权限检查器"""
    
    PERMISSIONS = {
        "admin": ["*"],  # 所有权限
        "store_manager": [
            "read_store", "write_store", "read_order", "write_order",
            "read_device", "write_device", "read_stats"
        ],
        "cleaner": [
            "read_store", "read_order", "read_device"
        ],
        "customer": [
            "read_store", "create_order", "read_own_order", "read_own_device"
        ]
    }
    
    @staticmethod
    def check_permission(user_type: str, permission: str) -> bool:
        """检查用户权限"""
        if user_type not in PermissionChecker.PERMISSIONS:
            return False
        
        user_permissions = PermissionChecker.PERMISSIONS[user_type]
        
        # 超级管理员拥有所有权限
        if "*" in user_permissions:
            return True
        
        return permission in user_permissions
    
    @staticmethod
    def check_resource_access(user_id: int, resource_owner_id: int, user_type: str) -> bool:
        """检查资源访问权限"""
        if user_type == "admin":
            return True
        
        return user_id == resource_owner_id

class SecurityHeaders:
    """安全头设置"""
    
    @staticmethod
    def get_security_headers() -> Dict[str, str]:
        """获取安全头"""
        return {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
            "Content-Security-Policy": "default-src 'self'",
            "Referrer-Policy": "strict-origin-when-cross-origin"
        }

class AuditLogger:
    """审计日志"""
    
    @staticmethod
    async def log_user_action(
        db: AsyncSession,
        user_id: int,
        action: str,
        resource: str,
        resource_id: Optional[int] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None
    ):
        """记录用户操作日志"""
        from ..models.audit_log import AuditLog
        
        log_entry = AuditLog(
            user_id=user_id,
            action=action,
            resource=resource,
            resource_id=resource_id,
            ip_address=ip_address,
            user_agent=user_agent,
            created_at=datetime.utcnow()
        )
        
        db.add(log_entry)
        await db.commit()
    
    @staticmethod
    async def log_failed_login(
        db: AsyncSession,
        username: str,
        ip_address: str,
        reason: str
    ):
        """记录登录失败日志"""
        from ..models.audit_log import AuditLog
        
        log_entry = AuditLog(
            user_id=None,
            action="failed_login",
            resource="auth",
            ip_address=ip_address,
            user_agent=f"username: {username}, reason: {reason}",
            created_at=datetime.utcnow()
        )
        
        db.add(log_entry)
        await db.commit()

class DeviceSecurity:
    """设备安全"""
    
    @staticmethod
    def generate_device_token(device_id: str) -> str:
        """生成设备令牌"""
        payload = {
            "device_id": device_id,
            "exp": datetime.utcnow() + timedelta(days=365),
            "type": "device"
        }
        return jwt.encode(payload, settings.DEVICE_SECRET_KEY, algorithm="HS256")
    
    @staticmethod
    def verify_device_token(token: str) -> Dict[str, Any]:
        """验证设备令牌"""
        try:
            payload = jwt.decode(token, settings.DEVICE_SECRET_KEY, algorithms=["HS256"])
            if payload.get("type") != "device":
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="无效的设备令牌"
                )
            return payload
        except jwt.PyJWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="无效的设备令牌"
            )

class WebSocketSecurity:
    """WebSocket安全"""
    
    @staticmethod
    def validate_websocket_origin(origin: str) -> bool:
        """验证WebSocket来源"""
        allowed_origins = settings.ALLOWED_ORIGINS
        return origin in allowed_origins
    
    @staticmethod
    def generate_websocket_token(user_id: int) -> str:
        """生成WebSocket令牌"""
        payload = {
            "user_id": user_id,
            "exp": datetime.utcnow() + timedelta(hours=1),
            "type": "websocket"
        }
        return jwt.encode(payload, settings.WEBSOCKET_SECRET_KEY, algorithm="HS256")
