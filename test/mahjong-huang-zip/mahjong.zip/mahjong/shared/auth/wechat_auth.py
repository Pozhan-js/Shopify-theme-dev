"""微信小程序认证模块"""
import httpx
from typing import Optional, Dict, Any
from pydantic import BaseModel
from shared.common.config import settings

class WeChatLoginRequest(BaseModel):
    """微信小程序登录请求"""
    code: str
    user_info: Optional[Dict[str, Any]] = None


class WeChatUserInfo(BaseModel):
    """微信用户信息"""
    openid: str
    session_key: str
    unionid: Optional[str] = None
    errcode: Optional[int] = None
    errmsg: Optional[str] = None


class WeChatAuth:
    """微信小程序认证类"""
    
    @staticmethod
    async def code_to_session(code: str) -> WeChatUserInfo:
        """
        通过code获取openid和session_key
        
        微信官方文档：https://developers.weixin.qq.com/miniprogram/dev/OpenApiDoc/user-login/code2Session.html
        """
        url = "https://api.weixin.qq.com/sns/jscode2session"
        params = {
            "appid": settings.WECHAT_APP_ID,
            "secret": settings.WECHAT_SECRET_KEY,
            "js_code": code,
            "grant_type": "authorization_code"
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.get(url, params=params)
            data = response.json()
            
            if "errcode" in data and data["errcode"] != 0:
                raise ValueError(f"微信认证失败: {data.get('errmsg', '未知错误')}")
            
            return WeChatUserInfo(**data)
    
    @staticmethod
    async def get_access_token() -> str:
        """获取微信接口调用凭证"""
        url = "https://api.weixin.qq.com/cgi-bin/token"
        params = {
            "grant_type": "client_credential",
            "appid": settings.WECHAT_APP_ID,
            "secret": settings.WECHAT_SECRET_KEY
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.get(url, params=params)
            data = response.json()
            
            if "errcode" in data:
                raise ValueError(f"获取access_token失败: {data.get('errmsg', '未知错误')}")
            
            return data["access_token"]
    
    @staticmethod
    async def send_template_message(
        openid: str,
        template_id: str,
        data: Dict[str, Any],
        page: Optional[str] = None
    ) -> bool:
        """发送微信模板消息"""
        try:
            access_token = await WeChatAuth.get_access_token()
            url = f"https://api.weixin.qq.com/cgi-bin/message/subscribe/send"
            params = {"access_token": access_token}
            
            payload = {
                "touser": openid,
                "template_id": template_id,
                "data": data
            }
            
            if page:
                payload["page"] = page
            
            async with httpx.AsyncClient() as client:
                response = await client.post(url, params=params, json=payload)
                result = response.json()
                
                return result.get("errcode") == 0
                
        except Exception as e:
            print(f"发送模板消息失败: {e}")
            return False


class WeChatTemplate:
    """微信模板消息"""
    
    # 订单开始提醒
    ORDER_START = {
        "template_id": "order_start_template_id",
        "data": {
            "thing1": {"value": "房间名称"},
            "time2": {"value": "开始时间"},
            "thing3": {"value": "订单号"},
            "thing4": {"value": "温馨提示"}
        }
    }
    
    # 订单结束提醒
    ORDER_END = {
        "template_id": "order_end_template_id",
        "data": {
            "thing1": {"value": "房间名称"},
            "time2": {"value": "结束时间"},
            "thing3": {"value": "使用时长"},
            "thing4": {"value": "感谢使用"}
        }
    }
    
    # 续费提醒
    RENEWAL_REMINDER = {
        "template_id": "renewal_reminder_template_id",
        "data": {
            "thing1": {"value": "房间名称"},
            "time2": {"value": "剩余时间"},
            "thing3": {"value": "续费提示"}
        }
    }
