# 无人系统后端架构设计文档

## 1. 系统概述

基于Python的无人系统后端，采用微服务架构，支持无人麻将馆、无人茶室等场景。

## 2. 技术栈

- **Web框架**: FastAPI (异步高性能)
- **ORM**: SQLAlchemy 2.0 + Alembic (数据库迁移)
- **数据库**: MySQL 8.0 (主库) + Redis (缓存)
- **消息队列**: RabbitMQ + Celery (异步任务)
- **API文档**: FastAPI自动生成 + Swagger UI
- **部署**: Docker + Docker Compose + Nginx
- **监控**: Prometheus + Grafana
- **日志**: ELK Stack (Elasticsearch + Logstash + Kibana)

## 3. 微服务架构

### 3.1 服务拆分

```
unmanned-system/
├── services/
│   ├── user-service/          # 用户服务
│   ├── store-service/         # 门店服务
│   ├── order-service/         # 订单服务
│   ├── payment-service/       # 支付服务
│   ├── iot-service/           # 物联网服务
│   ├── groupbuy-service/      # 团购服务
│   └── analytics-service/     # 数据统计服务
├── shared/
│   ├── common/               # 公共库
│   ├── auth/                 # 认证授权
│   └── proto/                # 协议定义
├── infrastructure/
│   ├── docker/               # Docker配置
│   ├── k8s/                  # Kubernetes配置
│   └── monitoring/           # 监控配置
└── docs/                     # 项目文档
```

### 3.2 服务详情

#### 用户服务 (user-service)
- 用户注册/登录
- JWT令牌管理
- 权限控制
- 用户信息管理

#### 门店服务 (store-service)
- 门店信息管理
- 房间配置
- 营业时间设置
- 价格策略

#### 订单服务 (order-service)
- 预约管理
- 订单生命周期
- 取消/退款
- 订单查询

#### 支付服务 (payment-service)
- 微信支付集成
- 余额支付
- 支付回调处理
- 退款处理

#### 物联网服务 (iot-service)
- 设备控制
- 门锁管理
- 状态监控
- 异常报警

#### 团购服务 (groupbuy-service)
- 美团团购验券
- 抖音团购验券
- 团购订单同步

#### 数据统计服务 (analytics-service)
- 营业报表
- 用户行为分析
- 收入统计
- 设备使用率

## 4. 数据库设计

### 4.1 MySQL数据库结构

```sql
-- 用户表
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(100),
    password_hash VARCHAR(255) NOT NULL,
    real_name VARCHAR(50),
    avatar_url VARCHAR(500),
    balance DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('active', 'inactive', 'banned') DEFAULT 'active',
    user_type ENUM('customer', 'store_manager', 'cleaner', 'admin') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 门店表
CREATE TABLE stores (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    phone VARCHAR(20),
    business_hours JSON,
    status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
    manager_id BIGINT,
    settings JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (manager_id) REFERENCES users(id)
);

-- 房间表
CREATE TABLE rooms (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_id BIGINT NOT NULL,
    name VARCHAR(50) NOT NULL,
    type ENUM('mahjong', 'tea_room', 'ktv') NOT NULL,
    capacity INT DEFAULT 4,
    price_per_hour DECIMAL(10,2) NOT NULL,
    status ENUM('available', 'occupied', 'maintenance', 'cleaning') DEFAULT 'available',
    device_info JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id)
);

-- 订单表
CREATE TABLE orders (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_no VARCHAR(32) UNIQUE NOT NULL,
    user_id BIGINT NOT NULL,
    store_id BIGINT NOT NULL,
    room_id BIGINT NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    duration_hours INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    discount_amount DECIMAL(10,2) DEFAULT 0.00,
    final_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'confirmed', 'in_progress', 'completed', 'cancelled', 'refunded') DEFAULT 'pending',
    payment_method ENUM('wechat', 'balance', 'groupbuy'),
    payment_status ENUM('unpaid', 'paid', 'refunded', 'partially_refunded') DEFAULT 'unpaid',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (store_id) REFERENCES stores(id),
    FOREIGN KEY (room_id) REFERENCES rooms(id)
);

-- 支付记录表
CREATE TABLE payments (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL,
    payment_no VARCHAR(64),
    payment_method ENUM('wechat', 'balance') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'success', 'failed', 'refunded') DEFAULT 'pending',
    transaction_id VARCHAR(64),
    paid_at TIMESTAMP NULL,
    refunded_at TIMESTAMP NULL,
    refund_amount DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- 团购券表
CREATE TABLE groupbuy_vouchers (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    voucher_code VARCHAR(64) UNIQUE NOT NULL,
    platform ENUM('meituan', 'douyin') NOT NULL,
    order_id BIGINT,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('unused', 'used', 'expired', 'refunded') DEFAULT 'unused',
    used_at TIMESTAMP NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- 设备表
CREATE TABLE devices (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_id BIGINT NOT NULL,
    room_id BIGINT,
    device_type ENUM('door_lock', 'light', 'ac', 'monitor') NOT NULL,
    device_id VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(100),
    status ENUM('online', 'offline', 'error') DEFAULT 'offline',
    last_seen TIMESTAMP NULL,
    config JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (store_id) REFERENCES stores(id),
    FOREIGN KEY (room_id) REFERENCES rooms(id)
);

-- 设备日志表
CREATE TABLE device_logs (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    device_id BIGINT NOT NULL,
    action VARCHAR(50) NOT NULL,
    data JSON,
    result ENUM('success', 'failed') DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (device_id) REFERENCES devices(id)
);
```

### 4.2 Redis缓存结构

```
# 用户会话
session:{user_id} -> {token, expire_time, permissions}

# 设备状态
device:status:{device_id} -> {status, last_update, battery_level}

# 房间状态
room:status:{room_id} -> {status, current_order_id, next_available_time}

# 订单缓存
order:{order_id} -> {order_info, expire_in_1h}

# 限流计数器
rate_limit:{api_path}:{user_id} -> {count, reset_time}
```

## 5. API设计规范

### 5.1 RESTful API规范

- **基础URL**: `https://api.unmanned-system.com/v1`
- **认证方式**: Bearer Token (JWT)
- **请求格式**: JSON
- **响应格式**: 统一JSON格式

### 5.2 响应格式标准

```json
{
    "code": 200,
    "message": "success",
    "data": {},
    "timestamp": 1635760800,
    "request_id": "uuid"
}
```

### 5.3 错误码规范

- 200: 成功
- 400: 请求参数错误
- 401: 未授权
- 403: 权限不足
- 404: 资源不存在
- 429: 请求过于频繁
- 500: 服务器内部错误

### 5.4 权限分级

1. **超级管理员**: 系统所有权限
2. **门店管理员**: 管理单个门店的所有操作
3. **保洁员**: 查看清洁任务、更新房间状态
4. **普通用户**: 预约、支付、查看个人订单

## 6. 部署架构

### 6.1 Docker部署

```yaml
# docker-compose.yml
version: '3.8'
services:
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl

  user-service:
    build: ./services/user-service
    environment:
      - DATABASE_URL=mysql://user:pass@mysql:3306/user_db
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      - mysql
      - redis

  store-service:
    build: ./services/store-service
    environment:
      - DATABASE_URL=mysql://user:pass@mysql:3306/store_db
    depends_on:
      - mysql

  # 其他服务类似配置...

  mysql:
    image: mysql:8.0
    environment:
      - MYSQL_ROOT_PASSWORD=rootpassword
      - MYSQL_DATABASE=unmanned_system
    volumes:
      - mysql_data:/var/lib/mysql

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data

  rabbitmq:
    image: rabbitmq:3-management
    environment:
      - RABBITMQ_DEFAULT_USER=admin
      - RABBITMQ_DEFAULT_PASS=admin
    ports:
      - "15672:15672"

volumes:
  mysql_data:
  redis_data:
```

### 6.2 监控配置

- **Prometheus**: 指标收集
- **Grafana**: 可视化监控
- **Jaeger**: 分布式追踪
- **ELK Stack**: 日志分析

## 7. 安全设计

### 7.1 认证授权
- JWT Token认证
- OAuth 2.0集成
- 角色权限控制 (RBAC)

### 7.2 数据安全
- 敏感数据加密存储
- API传输HTTPS
- 数据库连接加密
- 定期安全审计

### 7.3 防护措施
- API限流
- SQL注入防护
- XSS防护
- CSRF防护
- 敏感操作二次验证

## 8. 性能优化

### 8.1 缓存策略
- Redis缓存热点数据
- CDN加速静态资源
- 数据库查询优化

### 8.2 异步处理
- Celery处理耗时任务
- 消息队列削峰填谷
- 批量操作优化

### 8.3 数据库优化
- 读写分离
- 分库分表策略
- 索引优化
- 连接池管理
