-- 用户服务数据库表
USE user_service;

-- 用户表
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(100),
    password_hash VARCHAR(255),
    real_name VARCHAR(50),
    avatar_url VARCHAR(500),
    
    -- 微信相关
    openid VARCHAR(100) UNIQUE,
    unionid VARCHAR(100) UNIQUE,
    wechat_nickname VARCHAR(100),
    wechat_avatar_url VARCHAR(500),
    
    -- 基本信息
    user_type ENUM('customer', 'store_manager', 'cleaner', 'admin') DEFAULT 'customer',
    status ENUM('active', 'inactive', 'banned') DEFAULT 'active',
    
    -- 账户信息
    balance DECIMAL(10,2) DEFAULT 0.00,
    points INT DEFAULT 0,
    
    -- 扩展信息
    extra_info JSON DEFAULT '{}',
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_phone (phone),
    INDEX idx_openid (openid),
    INDEX idx_status (status)
);

-- 用户角色表
CREATE TABLE user_roles (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    role_name VARCHAR(50) NOT NULL,
    permissions JSON DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_role (user_id, role_name)
);

-- 用户余额表
CREATE TABLE user_balance (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    balance DECIMAL(10,2) DEFAULT 0.00,
    frozen_amount DECIMAL(10,2) DEFAULT 0.00,
    total_recharge DECIMAL(10,2) DEFAULT 0.00,
    total_consumption DECIMAL(10,2) DEFAULT 0.00,
    last_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_balance (user_id)
);

-- 用户地址表
CREATE TABLE user_address (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    address_type ENUM('home', 'work', 'other') DEFAULT 'home',
    contact_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    province VARCHAR(50),
    city VARCHAR(50),
    district VARCHAR(50),
    address TEXT NOT NULL,
    postal_code VARCHAR(10),
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_address (user_id)
);

-- 用户会话表
CREATE TABLE user_sessions (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    device_type ENUM('web', 'ios', 'android', 'miniprogram') NOT NULL,
    device_info JSON DEFAULT '{}',
    ip_address VARCHAR(45),
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expire_time TIMESTAMP NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_session_token (session_token),
    INDEX idx_user_sessions (user_id, is_active)
);

-- 门店服务数据库表
USE store_service;

-- 门店表
CREATE TABLE stores (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    phone VARCHAR(20),
    business_hours JSON DEFAULT '{"weekday":{"open":"09:00","close":"22:00"},"weekend":{"open":"09:00","close":"24:00"}}',
    settings JSON DEFAULT '{"cleaning_duration":30,"advance_booking_days":7,"min_booking_hours":1,"max_booking_hours":24}',
    status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
    manager_id BIGINT,
    location JSON DEFAULT '{}',
    images JSON DEFAULT '[]',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_status (status),
    INDEX idx_manager (manager_id)
);

-- 门店管理员表
CREATE TABLE store_admins (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    role ENUM('manager', 'assistant', 'cleaner') NOT NULL,
    permissions JSON DEFAULT '{}',
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_store_user (store_id, user_id),
    INDEX idx_store_admins (store_id, is_active)
);

-- 房间表
CREATE TABLE rooms (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_id BIGINT NOT NULL,
    name VARCHAR(50) NOT NULL,
    type ENUM('mahjong', 'tea_room', 'ktv', 'meeting') NOT NULL,
    capacity INT DEFAULT 4,
    price_per_hour DECIMAL(10,2) NOT NULL,
    price_per_night DECIMAL(10,2),
    status ENUM('available', 'occupied', 'maintenance', 'cleaning') DEFAULT 'available',
    device_info JSON DEFAULT '{}',
    features JSON DEFAULT '{"has_wifi":true,"has_ac":true,"has_tv":false,"has_fridge":false}',
    images JSON DEFAULT '[]',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_rooms (store_id, status),
    INDEX idx_room_type (type)
);

-- 房间类型表
CREATE TABLE room_types (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    type_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    default_features JSON DEFAULT '{}',
    base_price DECIMAL(10,2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 订单服务数据库表
USE order_service;

-- 订单表
CREATE TABLE orders (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_no VARCHAR(32) UNIQUE NOT NULL,
    user_id BIGINT NOT NULL,
    store_id BIGINT NOT NULL,
    room_id BIGINT NOT NULL,
    
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    duration_hours INT NOT NULL,
    
    total_amount DECIMAL(10,2) NOT NULL,
    discount_amount DECIMAL(10,2) DEFAULT 0.00,
    final_amount DECIMAL(10,2) NOT NULL,
    
    status ENUM('pending', 'confirmed', 'in_progress', 'completed', 'cancelled', 'refunded') DEFAULT 'pending',
    payment_method ENUM('wechat', 'balance', 'groupbuy', 'package'),
    payment_status ENUM('unpaid', 'paid', 'refunded', 'partially_refunded') DEFAULT 'unpaid',
    
    notes TEXT,
    extra_data JSON DEFAULT '{}',
    
    actual_start_time DATETIME,
    actual_end_time DATETIME,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_order_no (order_no),
    INDEX idx_user_orders (user_id, status),
    INDEX idx_store_orders (store_id, status),
    INDEX idx_room_orders (room_id, status),
    INDEX idx_order_status (status, payment_status)
);

-- 订单明细表
CREATE TABLE order_items (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL,
    item_type ENUM('room', 'service', 'product') NOT NULL,
    item_name VARCHAR(100) NOT NULL,
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    metadata JSON DEFAULT '{}',
    
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    INDEX idx_order_items (order_id)
);

-- 订单续费记录
CREATE TABLE order_extensions (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL,
    original_end_time DATETIME NOT NULL,
    new_end_time DATETIME NOT NULL,
    extended_hours INT NOT NULL,
    extension_fee DECIMAL(10,2) NOT NULL,
    
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    INDEX idx_order_extensions (order_id)
);

-- 订单分享记录
CREATE TABLE order_shares (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL,
    share_code VARCHAR(8) UNIQUE NOT NULL,
    max_uses INT DEFAULT 1,
    current_uses INT DEFAULT 0,
    expires_at DATETIME NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    INDEX idx_share_code (share_code),
    INDEX idx_order_shares (order_id)
);

-- 支付服务数据库表
USE payment_service;

-- 支付记录表
CREATE TABLE payments (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL,
    payment_no VARCHAR(64) UNIQUE,
    payment_method ENUM('wechat', 'balance', 'groupbuy') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'success', 'failed', 'refunded') DEFAULT 'pending',
    transaction_id VARCHAR(64),
    paid_at DATETIME,
    refund_amount DECIMAL(10,2) DEFAULT 0.00,
    payment_data JSON DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_order_payments (order_id, status),
    INDEX idx_payment_no (payment_no)
);

-- 退款记录表
CREATE TABLE refunds (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL,
    payment_id BIGINT NOT NULL,
    refund_no VARCHAR(64) UNIQUE NOT NULL,
    refund_amount DECIMAL(10,2) NOT NULL,
    reason TEXT,
    status ENUM('pending', 'approved', 'rejected', 'completed') DEFAULT 'pending',
    refund_id VARCHAR(64),
    refunded_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE,
    INDEX idx_order_refunds (order_id, status)
);

-- 物联网服务数据库表
USE iot_service;

-- 设备表
CREATE TABLE devices (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_id BIGINT NOT NULL,
    room_id BIGINT,
    device_type ENUM('door_lock', 'light', 'ac', 'monitor', 'speaker', 'sensor') NOT NULL,
    device_id VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(100),
    brand VARCHAR(50),
    model VARCHAR(50),
    status ENUM('online', 'offline', 'error', 'maintenance') DEFAULT 'offline',
    config JSON DEFAULT '{}',
    last_seen DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_store_devices (store_id, device_type),
    INDEX idx_device_status (status)
);

-- 设备指令表
CREATE TABLE device_commands (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    device_id BIGINT NOT NULL,
    command_type VARCHAR(50) NOT NULL,
    command_data JSON NOT NULL,
    status ENUM('pending', 'sent', 'executed', 'failed', 'timeout') DEFAULT 'pending',
    response_data JSON,
    executed_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE,
    INDEX idx_device_commands (device_id, status),
    INDEX idx_command_status (status)
);

-- 设备日志表
CREATE TABLE device_logs (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    device_id BIGINT NOT NULL,
    action VARCHAR(50) NOT NULL,
    data JSON,
    result ENUM('success', 'failed') DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE,
    INDEX idx_device_logs (device_id, action),
    INDEX idx_logs_created (created_at)
);

-- 团购服务数据库表
USE groupbuy_service;

-- 团购券码表
CREATE TABLE groupon_codes (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(64) UNIQUE NOT NULL,
    platform ENUM('meituan', 'douyin', 'dianping') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('unused', 'used', 'expired', 'refunded') DEFAULT 'unused',
    expires_at DATETIME NOT NULL,
    platform_data JSON DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_code_status (code, status),
    INDEX idx_platform_codes (platform, status)
);

-- 团购验券记录表
CREATE TABLE groupon_verification (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    groupon_code_id BIGINT NOT NULL,
    order_id BIGINT,
    verification_code VARCHAR(64),
    verified_amount DECIMAL(10,2) NOT NULL,
    verified_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    verification_data JSON DEFAULT '{}',
    
    FOREIGN KEY (groupon_code_id) REFERENCES groupon_codes(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
    INDEX idx_verification (groupon_code_id, order_id)
);

-- 创建触发器：订单状态变更时更新房间状态
DELIMITER $$
CREATE TRIGGER update_room_status_on_order_change
AFTER UPDATE ON order_service.orders
FOR EACH ROW
BEGIN
    IF NEW.status = 'confirmed' AND OLD.status != 'confirmed' THEN
        UPDATE store_service.rooms 
        SET status = 'occupied' 
        WHERE id = NEW.room_id;
    ELSEIF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        UPDATE store_service.rooms 
        SET status = 'available' 
        WHERE id = NEW.room_id;
    END IF;
END$$
DELIMITER ;

-- 创建触发器：用户余额变更记录
DELIMITER $$
CREATE TRIGGER update_user_balance_on_change
AFTER UPDATE ON user_service.user_balance
FOR EACH ROW
BEGIN
    IF NEW.balance != OLD.balance THEN
        INSERT INTO user_service.balance_logs (user_id, change_amount, new_balance, reason, created_at)
        VALUES (NEW.user_id, NEW.balance - OLD.balance, NEW.balance, 'balance_change', NOW());
    END IF;
END$$
DELIMITER ;
