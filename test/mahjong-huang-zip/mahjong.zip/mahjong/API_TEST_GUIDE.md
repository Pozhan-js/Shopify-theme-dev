# API测试指南

## 🚀 快速开始

### 1. 启动服务
```bash
# 启动所有服务
./start.sh

# 检查服务状态
docker-compose ps
```

### 2. 测试环境
- **用户服务**: http://localhost:8001
- **门店服务**: http://localhost:8002
- **订单服务**: http://localhost:8003
- **支付服务**: http://localhost:8004
- **API文档**: http://localhost:8080/docs

## 🔐 认证测试

### 微信小程序登录
```bash
curl -X POST http://localhost:8001/api/v1/auth/wx-login \
  -H "Content-Type: application/json" \
  -d '{
    "code": "test_wx_code_123456"
  }'
```

### Web后台登录
```bash
curl -X POST http://localhost:8001/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123",
    "captcha": "1234"
  }'
```

## 👤 用户API测试

### 获取用户信息
```bash
# 替换YOUR_TOKEN为实际获取的token
curl -X GET http://localhost:8001/api/v1/users/profile \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 更新用户信息
```bash
curl -X PUT http://localhost:8001/api/v1/users/profile \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "real_name": "张三",
    "email": "zhangsan@example.com",
    "avatar_url": "https://example.com/avatar.jpg"
  }'
```

### 查询余额
```bash
curl -X GET http://localhost:8001/api/v1/users/balance \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 余额充值
```bash
curl -X POST http://localhost:8001/api/v1/users/recharge \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 100.00,
    "payment_method": "wechat"
  }'
```

## 🏪 门店API测试

### 获取门店列表
```bash
curl -X GET "http://localhost:8002/api/v1/stores?page=1&limit=10&city=北京"
```

### 获取门店详情
```bash
curl -X GET http://localhost:8002/api/v1/stores/1
```

### 获取房间列表
```bash
curl -X GET "http://localhost:8002/api/v1/stores/1/rooms?date=2023-12-01&start_time=14:00&end_time=16:00"
```

### 获取房间详情
```bash
curl -X GET http://localhost:8002/api/v1/rooms/1
```

## 📋 订单API测试

### 创建订单
```bash
curl -X POST http://localhost:8003/api/v1/orders \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "store_id": 1,
    "room_id": 1,
    "start_time": "2023-12-01T14:00:00Z",
    "end_time": "2023-12-01T16:00:00Z",
    "payment_method": "wechat",
    "notes": "需要安静的环境"
  }'
```

### 获取订单列表
```bash
curl -X GET "http://localhost:8003/api/v1/orders?status=pending&page=1&limit=10" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 获取订单详情
```bash
curl -X GET http://localhost:8003/api/v1/orders/1 \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 订单续费
```bash
curl -X POST http://localhost:8003/api/v1/orders/1/renew \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "extend_hours": 1
  }'
```

### 取消订单
```bash
curl -X POST http://localhost:8003/api/v1/orders/1/cancel \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 开门操作
```bash
curl -X POST http://localhost:8003/api/v1/orders/1/open-door \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 💳 支付API测试

### 微信支付
```bash
curl -X POST http://localhost:8004/api/v1/payments/wechat \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": 1,
    "amount": 100.00
  }'
```

### 余额支付
```bash
curl -X POST http://localhost:8004/api/v1/payments/balance \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": 1,
    "amount": 100.00,
    "password": "123456"
  }'
```

### 团购支付
```bash
curl -X POST http://localhost:8004/api/v1/payments/groupon \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": 1,
    "groupon_code": "MT1234567890"
  }'
```

### 退款申请
```bash
curl -X POST http://localhost:8004/api/v1/payments/refund \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": 1,
    "refund_amount": 50.00,
    "reason": "提前结束使用"
  }'
```

## 🔧 管理员API测试

### 获取数据统计
```bash
curl -X GET "http://localhost:8001/api/v1/admin/stats?store_id=1" \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

### 获取订单管理列表
```bash
curl -X GET "http://localhost:8001/api/v1/admin/orders?store_id=1&status=all&page=1&limit=20" \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

### 修改订单
```bash
curl -X POST http://localhost:8001/api/v1/admin/orders/1/modify \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "end_time": "2023-12-01T17:00:00Z",
    "notes": "管理员调整"
  }'
```

### 获取设备列表
```bash
curl -X GET "http://localhost:8001/api/v1/admin/devices?store_id=1&page=1&limit=20" \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

### 设备控制
```bash
curl -X POST http://localhost:8001/api/v1/admin/devices/1/control \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "action": "unlock",
    "data": {
      "duration": 300
    }
  }'
```

## 📱 微信小程序专用测试

### 获取小程序码
```bash
curl -X GET "http://localhost:8001/api/v1/wx/qrcode?scene=store_id=1&page=pages/store/detail" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 订阅消息
```bash
curl -X POST http://localhost:8001/api/v1/wx/subscribe-message \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "template_id": "order_start_template",
    "data": {
      "thing1": {"value": "麻将房A"},
      "time2": {"value": "14:00"}
    }
  }'
```

## 🧪 测试数据

### 测试账号
- **管理员账号**:
  - 用户名: admin
  - 密码: admin123
  - 权限: 超级管理员

- **门店管理员**:
  - 用户名: store_manager
  - 密码: manager123
  - 权限: 门店管理

- **普通用户**:
  - 用户名: user123
  - 密码: user123
  - 权限: 普通用户

### 测试门店数据
- **中关村店**:
  - ID: 1
  - 地址: 北京市海淀区中关村大街1号
  - 电话: 010-12345678

- **朝阳店**:
  - ID: 2
  - 地址: 北京市朝阳区建国路88号
  - 电话: 010-87654321

### 测试房间数据
- **麻将房A**:
  - ID: 1
  - 类型: mahjong
  - 容量: 4人
  - 价格: 50元/小时

- **茶室B**:
  - ID: 2
  - 类型: tea_room
  - 容量: 6人
  - 价格: 80元/小时

## 🔍 调试工具

### 1. 使用Postman
导入以下Postman集合文件：`docs/postman_collection.json`

### 2. 使用curl测试脚本
运行测试脚本：`./scripts/test_api.sh`

### 3. 查看日志
```bash
# 查看用户服务日志
docker-compose logs user-service

# 查看所有服务日志
docker-compose logs -f
```

### 4. 数据库查询
```bash
# 进入MySQL容器
docker-compose exec mysql mysql -u root -p

# 查询用户表
USE unmanned_user;
SELECT * FROM users LIMIT 10;

# 查询订单表
USE unmanned_order;
SELECT * FROM orders LIMIT 10;
```

## ⚡ 性能测试

### 使用Apache Bench
```bash
# 测试门店列表接口
ab -n 1000 -c 10 http://localhost:8002/api/v1/stores

# 测试订单创建接口
ab -n 100 -c 5 -p test_order.json -T application/json \
  -H "Authorization: Bearer YOUR_TOKEN" \
  http://localhost:8003/api/v1/orders
```

### 使用Locust
```bash
# 启动Locust
locust -f tests/locustfile.py --host=http://localhost:8080

# 访问 http://localhost:8089 进行性能测试
```

## 🚨 常见问题

### 1. 认证失败
- 检查token是否正确
- 检查token是否过期
- 检查用户权限

### 2. 数据库连接失败
- 检查MySQL服务是否启动
- 检查数据库配置
- 检查网络连接

### 3. 微信支付失败
- 检查微信配置
- 检查订单状态
- 检查支付金额

### 4. 设备控制失败
- 检查设备状态
- 检查网络连接
- 检查权限

## 📊 监控指标

### 1. 系统监控
- CPU使用率
- 内存使用率
- 磁盘使用率
- 网络流量

### 2. 应用监控
- API响应时间
- 错误率
- 并发用户数
- 数据库连接数

### 3. 业务监控
- 订单量
- 支付成功率
- 用户活跃度
- 设备在线率

## 🎯 测试检查清单

### ✅ 功能测试
- [ ] 用户注册/登录
- [ ] 门店查询
- [ ] 订单创建/取消
- [ ] 支付功能
- [ ] 管理员功能
- [ ] 微信小程序集成

### ✅ 性能测试
- [ ] 并发用户测试
- [ ] 数据库性能测试
- [ ] API响应时间测试
- [ ] 内存使用测试

### ✅ 安全测试
- [ ] 权限验证
- [ ] SQL注入测试
- [ ] XSS攻击测试
- [ ] 敏感数据保护

### ✅ 集成测试
- [ ] 服务间通信
- [ ] 数据库事务
- [ ] 消息队列
- [ ] 缓存一致性
