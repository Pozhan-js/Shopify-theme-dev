# 无人系统数据库设计文档

## 🗂️ 数据库架构概览

### 数据库分布
- **user_service**: 用户相关数据
- **store_service**: 门店相关数据
- **order_service**: 订单相关数据
- **payment_service**: 支付相关数据
- **iot_service**: 设备相关数据
- **groupbuy_service**: 团购相关数据

## 📊 完整ER图

```mermaid
erDiagram
    %% 用户相关表
    users ||--o{ user_roles : has
    users ||--o{ user_balance : has
    users ||--o{ user_address : has
    users ||--o{ user_sessions : has
    users ||--o{ orders : creates
    users ||--o{ store_admins : manages
    
    %% 门店相关表
    stores ||--o{ store_admins : has
    stores ||--o{ rooms : contains
    stores ||--o{ orders : receives
    rooms ||--o{ room_types : belongs_to
    rooms ||--o{ orders : booked
    
    %% 订单相关表
    orders ||--o{ order_items : contains
    orders ||--o{ payments : has
    orders ||--o{ refunds : has
    orders ||--|| devices : uses
    
    %% 设备相关表
    devices ||--o{ device_commands : receives
    devices ||--o{ device_logs : generates
    
    %% 团购相关表
    groupon_codes ||--o{ groupon_verification : verified
    
    %% 用户表
    users {
        bigint id PK
        string username
        string phone
        string email
        string password_hash
        string real_name
        string avatar_url
        string openid
        string unionid
        string user_type
        string status
        decimal balance
        json extra_info
        datetime created_at
        datetime updated_at
    }
    
    %% 用户角色表
    user_roles {
        bigint id PK
        bigint user_id FK
        string role_name
        json permissions
        datetime created_at
    }
    
    %% 用户余额表
    user_balance {
        bigint id PK
        bigint user_id FK
        decimal balance
        decimal frozen_amount
        datetime last_update
    }
    
    %% 用户地址表
    user_address {
        bigint id PK
        bigint user_id FK
        string address_type
        string contact_name
        string phone
        string province
        string city
        string district
        string address
        boolean is_default
        datetime created_at
    }
    
    %% 用户会话表
    user_sessions {
        bigint id PK
        bigint user_id FK
        string session_token
        string device_type
        string device_info
        string ip_address
        datetime login_time
        datetime expire_time
        boolean is_active
    }
    
    %% 门店表
    stores {
        bigint id PK
        string name
        text address
        string phone
        json business_hours
        json settings
        string status
        bigint manager_id FK
        datetime created_at
        datetime updated_at
    }
    
    %% 门店管理员表
    store_admins {
        bigint id PK
        bigint store_id FK
        bigint user_id FK
        string role
        json permissions
        datetime assigned_at
    }
    
    %% 房间表
    rooms {
        bigint id PK
        bigint store_id FK
        string name
        string type
        int capacity
        decimal price_per_hour
        decimal price_per_night
        string status
        json device_info
        json features
        datetime created_at
        datetime updated_at
    }
    
    %% 房间类型表
    room_types {
        bigint id PK
        string type_name
        string description
        json default_features
        decimal base_price
        boolean is_active
    }
    
    %% 订单表
    orders {
        bigint id PK
        string order_no
        bigint user_id FK
        bigint store_id FK
        bigint room_id FK
        datetime start_time
        datetime end_time
        int duration_hours
        decimal total_amount
        decimal discount_amount
        decimal final_amount
        string status
        string payment_method
        string payment_status
        text notes
        json extra_data
        datetime actual_start_time
        datetime actual_end_time
        datetime created_at
        datetime updated_at
    }
    
    %% 订单明细表
    order_items {
        bigint id PK
        bigint order_id FK
        string item_type
        string item_name
        int quantity
        decimal unit_price
        decimal total_price
        json metadata
    }
    
    %% 支付记录表
    payments {
        bigint id PK
        bigint order_id FK
        string payment_no
        string payment_method
        decimal amount
        string status
        string transaction_id
        datetime paid_at
        json payment_data
        datetime created_at
    }
    
    %% 退款记录表
    refunds {
        bigint id PK
        bigint order_id FK
        bigint payment_id FK
        string refund_no
        decimal refund_amount
        string reason
        string status
        string refund_id
        datetime refunded_at
        datetime created_at
    }
    
    %% 设备表
    devices {
        bigint id PK
        bigint store_id FK
        bigint room_id FK
        string device_type
        string device_id
        string name
        string status
        json config
        datetime last_seen
        datetime created_at
    }
    
    %% 设备指令表
    device_commands {
        bigint id PK
        bigint device_id FK
        string command_type
        json command_data
        string status
        json response_data
        datetime executed_at
        datetime created_at
    }
    
    %% 设备日志表
    device_logs {
        bigint id PK
        bigint device_id FK
        string action
        json data
        string result
        text error_message
        datetime created_at
    }
    
    %% 团购券码表
    groupon_codes {
        bigint id PK
        string code
        string platform
        decimal amount
        string status
        datetime expires_at
        json platform_data
        datetime created_at
    }
    
    %% 团购验券记录表
    groupon_verification {
        bigint id PK
        bigint groupon_code_id FK
        bigint order_id FK
        string verification_code
        decimal verified_amount
        datetime verified_at
        json verification_data
    }
```

## 📋 完整表结构定义

### 1. 用户相关表

#### users - 用户表
```sql
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(100),
    password_hash VARCHAR(255),
    real_name VARCHAR(50),
    avatar_url VARCHAR(500),
    
    -- 微信相关
    openid VARCHAR(100) UNIQUE,
    unionid VARCHAR(100) UNIQUE,
    wechat_nickname VARCHAR(100),
    wechat_avatar_url VARCHAR(500),
    
    -- 基本信息
    user_type ENUM('customer', 'store_manager', 'cleaner', 'admin') DEFAULT 'customer',
    status ENUM('active', 'inactive', 'banned') DEFAULT 'active',
    
    -- 账户信息
    balance DECIMAL(10,2) DEFAULT 0.00,
    points INT DEFAULT 0,
    
    -- 扩展信息
    extra_info JSON DEFAULT '{}',
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_phone (phone),
    INDEX idx_openid (openid),
    INDEX idx_status (status)
);
```

#### user_roles - 用户角色表
```sql
CREATE TABLE user_roles (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    role_name VARCHAR(50) NOT NULL,
    permissions JSON DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_role (user_id, role_name)
);
```

#### user_balance - 用户余额表
```sql
CREATE TABLE user_balance (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    balance DECIMAL(10,2) DEFAULT 0.00,
    frozen_amount DECIMAL(10,2) DEFAULT 0.00,
    total_recharge DECIMAL(10,2) DEFAULT 0.00,
    total_consumption DECIMAL(10,2) DEFAULT 0.00,
    last_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_balance (user_id)
);
```

#### user_address - 用户地址表
```sql
CREATE TABLE user_address (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    address_type ENUM('home', 'work', 'other') DEFAULT 'home',
    contact_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    province VARCHAR(50),
    city VARCHAR(50),
    district VARCHAR(50),
    address TEXT NOT NULL,
    postal_code VARCHAR(10),
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_address (user_id)
);
```

#### user_sessions - 用户会话表
```sql
CREATE TABLE user_sessions (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    device_type ENUM('web', 'ios', 'android', 'miniprogram') NOT NULL,
    device_info JSON DEFAULT '{}',
    ip_address VARCHAR(45),
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expire_time TIMESTAMP NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_session_token (session_token),
    INDEX idx_user_sessions (user_id, is_active)
);
```

### 2. 门店相关表

#### stores - 门店表
```sql
CREATE TABLE stores (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    phone VARCHAR(20),
    business_hours JSON DEFAULT '{"weekday":{"open":"09:00","close":"22:00"},"weekend":{"open":"09:00","close":"24:00"}}',
    settings JSON DEFAULT '{"cleaning_duration":30,"advance_booking_days":7,"min_booking_hours":1,"max_booking_hours":24}',
    status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
    manager_id BIGINT,
    location JSON DEFAULT '{}',
    images JSON DEFAULT '[]',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_status (status),
    INDEX idx_manager (manager_id)
);
```

#### store_admins - 门店管理员表
```sql
CREATE TABLE store_admins (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    role ENUM('manager', 'assistant', 'cleaner') NOT NULL,
    permissions JSON DEFAULT '{}',
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_store_user (store_id, user_id),
    INDEX idx_store_admins (store_id, is_active)
);
```

#### rooms - 房间表
```sql
CREATE TABLE rooms (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_id BIGINT NOT NULL,
    name VARCHAR(50) NOT NULL,
    type ENUM('mahjong', 'tea_room', 'ktv', 'meeting') NOT NULL,
    capacity INT DEFAULT 4,
    price_per_hour DECIMAL(10,2) NOT NULL,
    price_per_night DECIMAL(10,2),
    status ENUM('available', 'occupied', 'maintenance', 'cleaning') DEFAULT 'available',
    device_info JSON DEFAULT '{}',
    features JSON DEFAULT '{"has_wifi":true,"has_ac":true,"has_tv":false,"has_fridge":false}',
    images JSON DEFAULT '[]',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    INDEX idx_store_rooms (store_id, status),
    INDEX idx_room_type (type)
);
```

#### room_types - 房间类型表
```sql
CREATE TABLE room_types (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    type_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    default_features JSON DEFAULT '{}',
    base_price DECIMAL(10,2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 3. 订单相关表

#### orders - 订单表
```sql
CREATE TABLE orders (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_no VARCHAR(32) UNIQUE NOT NULL,
    user_id BIGINT NOT NULL,
    store_id BIGINT NOT NULL,
    room_id BIGINT NOT NULL,
    
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    duration_hours INT NOT NULL,
    
    total_amount DECIMAL(10,2) NOT NULL,
    discount_amount DECIMAL(10,2) DEFAULT 0.00,
    final_amount DECIMAL(10,2) NOT NULL,
    
    status ENUM('pending', 'confirmed', 'in_progress', 'completed', 'cancelled', 'refunded') DEFAULT 'pending',
    payment_method ENUM('wechat', 'balance', 'groupbuy', 'package'),
    payment_status ENUM('unpaid', 'paid', 'refunded', 'partially_refunded') DEFAULT 'unpaid',
    
    notes TEXT,
    extra_data JSON DEFAULT '{}',
    
    actual_start_time DATETIME,
    actual_end_time DATETIME,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (store_id) REFERENCES stores(id),
    FOREIGN KEY (room_id) REFERENCES rooms(id),
    INDEX idx_order_no (order_no),
    INDEX idx_user_orders (user_id, status),
    INDEX idx_store_orders (store_id, status),
    INDEX idx_room_orders (room_id, status),
    INDEX idx_order_status (status, payment_status)
);
```

#### order_items - 订单明细表
```sql
CREATE TABLE order_items (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL,
    item_type ENUM('room', 'service', 'product') NOT NULL,
    item_name VARCHAR(100) NOT NULL,
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    metadata JSON DEFAULT '{}',
    
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    INDEX idx_order_items (order_id)
);
```

#### payments - 支付记录表
```sql
CREATE TABLE payments (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL,
    payment_no VARCHAR(64) UNIQUE,
    payment_method ENUM('wechat', 'balance', 'groupbuy') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'success', 'failed', 'refunded') DEFAULT 'pending',
    transaction_id VARCHAR(64),
    paid_at DATETIME,
    refund_amount DECIMAL(10,2) DEFAULT 0.00,
    payment_data JSON DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    INDEX idx_order_payments (order_id, status),
    INDEX idx_payment_no (payment_no)
);
```

#### refunds - 退款记录表
```sql
CREATE TABLE refunds (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL,
    payment_id BIGINT NOT NULL,
    refund_no VARCHAR(64) UNIQUE NOT NULL,
    refund_amount DECIMAL(10,2) NOT NULL,
    reason TEXT,
    status ENUM('pending', 'approved', 'rejected', 'completed') DEFAULT 'pending',
    refund_id VARCHAR(64),
    refunded_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE,
    INDEX idx_order_refunds (order_id, status)
);
```

### 4. 设备相关表

#### devices - 设备表
```sql
CREATE TABLE devices (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_id BIGINT NOT NULL,
    room_id BIGINT,
    device_type ENUM('door_lock', 'light', 'ac', 'monitor', 'speaker', 'sensor') NOT NULL,
    device_id VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(100),
    brand VARCHAR(50),
    model VARCHAR(50),
    status ENUM('online', 'offline', 'error', 'maintenance') DEFAULT 'offline',
    config JSON DEFAULT '{}',
    last_seen DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL,
    INDEX idx_store_devices (store_id, device_type),
    INDEX idx_device_status (status)
);
```

#### device_commands - 设备指令表
```sql
CREATE TABLE device_commands (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    device_id BIGINT NOT NULL,
    command_type VARCHAR(50) NOT NULL,
    command_data JSON NOT NULL,
    status ENUM('pending', 'sent', 'executed', 'failed', 'timeout') DEFAULT 'pending',
    response_data JSON,
    executed_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE,
    INDEX idx_device_commands (device_id, status),
    INDEX idx_command_status (status)
);
```

#### device_logs - 设备日志表
```sql
CREATE TABLE device_logs (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    device_id BIGINT NOT NULL,
    action VARCHAR(50) NOT NULL,
    data JSON,
    result ENUM('success', 'failed') DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE,
    INDEX idx_device_logs (device_id, action),
    INDEX idx_logs_created (created_at)
);
```

### 5. 团购相关表

#### groupon_codes - 团购券码表
```sql
CREATE TABLE groupon_codes (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(64) UNIQUE NOT NULL,
    platform ENUM('meituan', 'douyin', 'dianping') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('unused', 'used', 'expired', 'refunded') DEFAULT 'unused',
    expires_at DATETIME NOT NULL,
    platform_data JSON DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_code_status (code, status),
    INDEX idx_platform_codes (platform, status)
);
```

#### groupon_verification - 验券记录表
```sql
CREATE TABLE groupon_verification (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    groupon_code_id BIGINT NOT NULL,
    order_id BIGINT,
    verification_code VARCHAR(64),
    verified_amount DECIMAL(10,2) NOT NULL,
    verified_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    verification_data JSON DEFAULT '{}',
    
    FOREIGN KEY (groupon_code_id) REFERENCES groupon_codes(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
    INDEX idx_verification (groupon_code_id, order_id)
);
```

## 🔍 索引设计

### 核心索引
1. **用户查询**: idx_phone, idx_openid, idx_status
2. **订单查询**: idx_order_no, idx_user_orders, idx_store_orders
3. **房间查询**: idx_store_rooms, idx_room_status
4. **设备查询**: idx_store_devices, idx_device_status
5. **支付查询**: idx_order_payments, idx_payment_no

### 复合索引
- 用户订单: (user_id, status, created_at)
- 门店订单: (store_id, status, start_time)
- 房间可用性: (room_id, status, start_time, end_time)

## 🔄 数据一致性

### 事务处理
- 订单创建时的库存扣减
- 支付成功后的订单状态更新
- 退款时的余额回滚

### 触发器示例
```sql
-- 订单状态更新触发器
DELIMITER $$
CREATE TRIGGER update_room_status
AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
    IF NEW.status = 'confirmed' THEN
        UPDATE rooms SET status = 'occupied' WHERE id = NEW.room_id;
    ELSEIF NEW.status = 'completed' THEN
        UPDATE rooms SET status = 'available' WHERE id = NEW.room_id;
    END IF;
END$$
DELIMITER ;
```

## 📈 性能优化

### 分区策略
- 订单表按时间分区
- 日志表按月份分区

### 缓存策略
- Redis缓存热点数据
- 用户会话缓存
- 房间状态缓存

## 🛡️ 数据安全

### 敏感数据加密
- 用户密码: bcrypt哈希
- 支付信息: 字段级加密
- 个人身份信息: 脱敏存储

### 备份策略
- 每日全量备份
- 实时binlog备份
- 跨地域备份
