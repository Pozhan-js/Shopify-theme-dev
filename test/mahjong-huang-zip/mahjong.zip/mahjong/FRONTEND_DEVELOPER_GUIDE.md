# 无人系统后端项目 - 前端开发者指南

> 📢 **专为前端开发者编写的后端项目指南**  
> 从零开始，手把手教你部署和维护这个无人系统后端项目

## 🎯 项目简介

这是一个完整的无人系统（无人麻将馆/茶室）后端项目，采用微服务架构，支持微信小程序和Web管理后台。作为前端开发者，你只需要按照本指南操作，即可快速搭建开发环境。

## 📦 环境准备 - 新手必看

### 1. 安装必需软件

#### Windows系统
```bash
# 1. 安装Docker Desktop
# 访问：https://www.docker.com/products/docker-desktop/
# 下载并安装，安装后重启电脑

# 2. 验证安装
docker --version
docker-compose --version
```

#### macOS系统
```bash
# 1. 安装Docker Desktop
# 访问：https://www.docker.com/products/docker-desktop/
# 下载并安装

# 2. 或使用Homebrew
brew install docker
brew install docker-compose
```

#### Linux系统
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install docker.io docker-compose

# CentOS/RHEL
sudo yum install docker docker-compose
```

### 2. 安装开发工具（推荐）
```bash
# 安装VS Code
# 访问：https://code.visualstudio.com/

# 安装Postman（API测试）
# 访问：https://www.postman.com/downloads/

# 安装MySQL客户端（可选）
# 访问：https://dev.mysql.com/downloads/workbench/
```

## 📁 项目结构详解

### 根目录结构
```
unmanned-system/
├── services/                    # 微服务目录（8个独立服务）
│   ├── user-service/           # 用户服务 - 用户注册、登录、认证
│   ├── store-service/          # 门店服务 - 门店、房间管理
│   ├── order-service/          # 订单服务 - 订单创建、管理
│   ├── payment-service/        # 支付服务 - 支付、退款
│   ├── iot-service/            # IoT服务 - 设备控制、状态监控
│   ├── groupbuy-service/       # 团购服务 - 团购码验证
│   ├── analytics-service/      # 分析服务 - 数据统计
│   └── analytics-service/      # 分析服务 - 数据统计
├── shared/                     # 共享组件
│   ├── auth/                  # 认证相关
│   ├── security/              # 安全防护
│   └── common/                # 通用配置
├── infrastructure/            # 基础设施
│   └── docker/               # Docker配置
├── docs/                     # 项目文档
├── .env.example             # 环境变量模板
├── start.sh                # 一键启动脚本
└── README.md               # 项目说明
```

### 各服务详细说明

#### 1. user-service/ 用户服务
```
user-service/
├── src/
│   ├── models/          # 数据库模型（用户表）
│   ├── schemas/         # 数据验证模型
│   ├── services/        # 业务逻辑
│   ├── routers/         # API路由
│   │   ├── auth.py      # 认证接口（登录、注册）
│   │   ├── users.py     # 用户接口
│   │   └── admin.py     # 管理员接口
│   └── main.py          # 服务入口
├── Dockerfile          # Docker镜像配置
└── requirements.txt    # Python依赖
```

#### 2. store-service/ 门店服务
```
store-service/
├── src/
│   ├── models/          # 门店、房间模型
│   ├── schemas/         # 数据验证
│   ├── services/        # 业务逻辑
│   └── routers/         # API路由
│       └── stores.py    # 门店相关接口
```

#### 3. order-service/ 订单服务
```
order-service/
├── src/
│   ├── models/          # 订单模型
│   ├── schemas/         # 订单验证
│   ├── services/        # 订单业务
│   └── routers/         # 订单接口
│       └── orders.py    # 订单CRUD接口
```

#### 4. payment-service/ 支付服务
```
payment-service/
├── src/
│   ├── models/          # 支付模型
│   ├── services/        # 支付业务
│   └── routers/         # 支付接口
│       └── payments.py  # 支付相关接口
```

#### 5. iot-service/ IoT服务
```
iot-service/
├── src/
│   ├── protocols/       # 通信协议
│   │   └── mqtt_protocol.py  # MQTT协议实现
│   ├── models/          # 设备模型
│   ├── services/        # 设备业务
│   └── routers/         # 设备接口
│       └── devices.py   # 设备控制接口
```

## 🚀 项目启动方法

### 方法一：一键启动（推荐新手）
```bash
# 1. 克隆项目
git clone <项目地址>
cd unmanned-system

# 2. 复制环境变量
cp .env.example .env

# 3. 编辑配置文件（重要！）
# 用记事本打开.env文件，修改以下配置：
# - 数据库密码
# - 微信配置（找后端同事获取）
# - JWT密钥（可保持默认）

# 4. 一键启动
./start.sh

# 5. 验证启动
docker-compose ps
# 应该看到8个服务都在运行
```

### 方法二：分步启动（了解原理）
```bash
# 1. 启动基础设施
docker-compose up -d mysql redis rabbitmq

# 2. 等待30秒让数据库初始化
sleep 30

# 3. 启动各个服务
docker-compose up -d user-service
docker-compose up -d store-service
docker-compose up -d order-service
docker-compose up -d payment-service
docker-compose up -d iot-service

# 4. 启动Nginx网关
docker-compose up -d nginx
```

## 🌐 服务器部署指南

### 1. 购买服务器（推荐配置）
- **阿里云/腾讯云轻量应用服务器**
- **配置**: 2核4G内存，50G硬盘
- **系统**: Ubuntu 20.04 LTS
- **价格**: 约100元/月

### 2. 服务器环境准备
```bash
# 连接服务器
ssh root@你的服务器IP

# 更新系统
apt update && apt upgrade -y

# 安装Docker
curl -fsSL https://get.docker.com | bash
systemctl start docker
systemctl enable docker

# 安装Docker Compose
curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
```

### 3. 部署项目
```bash
# 1. 上传项目到服务器
scp -r unmanned-system root@你的服务器IP:/root/

# 2. 进入项目目录
cd /root/unmanned-system

# 3. 配置环境变量
cp .env.example .env
nano .env  # 编辑配置文件

# 4. 启动项目
./start.sh

# 5. 开放端口
ufw allow 8080  # API端口
ufw allow 3306  # MySQL（仅内网）
```

### 4. 配置域名（可选）
```bash
# 1. 购买域名（阿里云/腾讯云）
# 2. 配置DNS解析到服务器IP
# 3. 修改Nginx配置
# 编辑：infrastructure/docker/nginx/nginx.conf
# 将localhost改为你的域名
```

## 🔧 项目维护指南

### 日常维护命令
```bash
# 查看服务状态
docker-compose ps

# 查看日志
docker-compose logs user-service  # 查看用户服务日志
docker-compose logs -f            # 实时查看所有日志

# 重启单个服务
docker-compose restart user-service

# 更新服务
docker-compose pull
docker-compose up -d

# 备份数据库
docker-compose exec mysql mysqldump -u root -p unmanned_user > backup_user.sql
```

### 数据库维护
```bash
# 进入MySQL容器
docker-compose exec mysql mysql -u root -p

# 常用SQL命令
SHOW DATABASES;                    # 查看数据库
USE unmanned_user;                 # 切换数据库
SHOW TABLES;                       # 查看表
SELECT * FROM users LIMIT 10;      # 查看用户数据
```

## ✏️ 新增接口开发指南

### 1. 确定在哪个服务添加接口
- **用户相关** → user-service
- **门店相关** → store-service
- **订单相关** → order-service
- **支付相关** → payment-service
- **设备相关** → iot-service

### 2. 以新增"用户收藏门店"接口为例

#### 步骤1：添加数据库模型
```python
# 在对应服务的models目录下创建新文件
# services/user-service/src/models/favorite.py

from sqlalchemy import Column, Integer, ForeignKey, DateTime
from .base import Base

class UserFavorite(Base):
    __tablename__ = "user_favorites"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    store_id = Column(Integer, ForeignKey("stores.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
```

#### 步骤2：创建数据验证模型
```python
# services/user-service/src/schemas/favorite.py

from pydantic import BaseModel

class FavoriteCreate(BaseModel):
    store_id: int

class FavoriteResponse(BaseModel):
    id: int
    store_id: int
    created_at: datetime
```

#### 步骤3：编写业务逻辑
```python
# services/user-service/src/services/favorite_service.py

class FavoriteService:
    async def add_favorite(self, user_id: int, store_id: int):
        # 检查是否已收藏
        existing = await self.db.query(UserFavorite).filter(
            UserFavorite.user_id == user_id,
            UserFavorite.store_id == store_id
        ).first()
        
        if existing:
            raise HTTPException(status_code=400, detail="已收藏")
        
        favorite = UserFavorite(user_id=user_id, store_id=store_id)
        self.db.add(favorite)
        await self.db.commit()
        return favorite
```

#### 步骤4：添加路由接口
```python
# services/user-service/src/routers/favorites.py

@router.post("/favorites", response_model=dict)
async def add_favorite(
    favorite_data: FavoriteCreate,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    token = credentials.credentials
    payload = verify_token(token)
    user_id = int(payload.get("sub"))
    
    favorite_service = FavoriteService(db)
    result = await favorite_service.add_favorite(user_id, favorite_data.store_id)
    
    return {"code": 200, "message": "收藏成功", "data": result}
```

#### 步骤5：注册路由
```python
# 在services/user-service/src/main.py中添加
from src.routers import favorites
app.include_router(favorites.router)
```

### 3. 测试新接口
```bash
# 重启服务
docker-compose restart user-service

# 测试接口
curl -X POST http://localhost:8080/api/v1/favorites \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"store_id": 1}'
```

## 🐛 常见问题解决

### 1. 端口被占用
```bash
# 查看端口占用
lsof -i :8080

# 杀掉占用进程
kill -9 PID
```

### 2. 数据库连接失败
```bash
# 检查MySQL容器
docker-compose logs mysql

# 重置数据库（谨慎操作）
docker-compose down
docker volume prune
docker-compose up -d
```

### 3. 服务启动失败
```bash
# 查看详细日志
docker-compose logs [服务名]

# 常见原因：
# - 端口冲突：修改docker-compose.yml中的端口
# - 配置错误：检查.env文件
# - 依赖问题：确保Docker和Docker Compose版本最新
```

## 📞 技术支持

### 开发环境
- **API文档**: http://localhost:8080/docs
- **测试工具**: Postman或curl
- **数据库**: MySQL Workbench连接localhost:3306

### 获取帮助
- **查看日志**: `docker-compose logs -f`
- **重启服务**: `docker-compose restart [服务名]`
- **清理环境**: `docker-compose down && docker-compose up -d`

### 联系支持
- **QQ群**: 123456789（前端开发者交流群）
- **邮箱**: support@unmanned-system.com

---

**🎉 恭喜！现在你已经掌握了完整的无人系统后端部署和维护技能。作为前端开发者，你可以专注于小程序和管理后台的开发，后端部分已经为你准备好了！**

**下一步建议：**
1. 先按照"一键启动"方法跑起来
2. 用Postman测试几个API接口
3. 开始你的小程序开发
4. 遇到问题随时查看日志
