from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional, List
from datetime import datetime

from shared.common.database import get_db
from shared.auth.jwt_handler import verify_token
from ..models.store import Store, Room, RoomPrice
from ..schemas.store import StoreResponse, RoomResponse, RoomListParams
from ..services.store_service import StoreService

router = APIRouter(prefix="/stores", tags=["门店"])
security = HTTPBearer()

@router.get("", response_model=dict)
async def get_stores(
    city: Optional[str] = None,
    status: Optional[str] = "active",
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """获取门店列表"""
    try:
        store_service = StoreService(db)
        stores = await store_service.get_stores(
            city=city,
            status=status,
            page=page,
            limit=limit
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "stores": [
                    {
                        "id": store.id,
                        "name": store.name,
                        "address": store.address,
                        "phone": store.phone,
                        "status": store.status,
                        "business_hours": store.business_hours,
                        "images": store.images,
                        "description": store.description,
                        "latitude": float(store.latitude) if store.latitude else None,
                        "longitude": float(store.longitude) if store.longitude else None
                    }
                    for store in stores["items"]
                ],
                "total": stores["total"],
                "page": page,
                "limit": limit
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/{store_id}", response_model=dict)
async def get_store_detail(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取门店详情"""
    try:
        store_service = StoreService(db)
        store = await store_service.get_store_by_id(store_id)
        
        if not store:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="门店不存在"
            )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "id": store.id,
                "name": store.name,
                "address": store.address,
                "phone": store.phone,
                "status": store.status,
                "business_hours": store.business_hours,
                "images": store.images,
                "description": store.description,
                "latitude": float(store.latitude) if store.latitude else None,
                "longitude": float(store.longitude) if store.longitude else None,
                "total_rooms": store.total_rooms,
                "available_rooms": store.available_rooms
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/{store_id}/rooms", response_model=dict)
async def get_store_rooms(
    store_id: int,
    date: Optional[str] = None,
    start_time: Optional[str] = None,
    end_time: Optional[str] = None,
    room_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """获取门店房间列表"""
    try:
        store_service = StoreService(db)
        
        # 验证门店存在
        store = await store_service.get_store_by_id(store_id)
        if not store:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="门店不存在"
            )
        
        # 解析日期时间
        target_date = None
        if date:
            target_date = datetime.strptime(date, "%Y-%m-%d").date()
        
        start_dt = None
        end_dt = None
        if start_time and end_time:
            start_dt = datetime.strptime(f"{date} {start_time}", "%Y-%m-%d %H:%M")
            end_dt = datetime.strptime(f"{date} {end_time}", "%Y-%m-%d %H:%M")
        
        rooms = await store_service.get_store_rooms(
            store_id=store_id,
            date=target_date,
            start_time=start_dt,
            end_time=end_dt,
            room_type=room_type
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "rooms": [
                    {
                        "id": room.id,
                        "name": room.name,
                        "type": room.type,
                        "capacity": room.capacity,
                        "description": room.description,
                        "images": room.images,
                        "features": room.features,
                        "status": room.status,
                        "price_per_hour": float(room.price_per_hour),
                        "min_hours": room.min_hours,
                        "max_hours": room.max_hours,
                        "is_available": room.is_available
                    }
                    for room in rooms
                ]
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/rooms/{room_id}", response_model=dict)
async def get_room_detail(
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取房间详情"""
    try:
        store_service = StoreService(db)
        room = await store_service.get_room_by_id(room_id)
        
        if not room:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="房间不存在"
            )
        
        # 获取价格策略
        price_strategies = await store_service.get_room_prices(room_id)
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "id": room.id,
                "store_id": room.store_id,
                "name": room.name,
                "type": room.type,
                "capacity": room.capacity,
                "description": room.description,
                "images": room.images,
                "features": room.features,
                "status": room.status,
                "price_per_hour": float(room.price_per_hour),
                "min_hours": room.min_hours,
                "max_hours": room.max_hours,
                "price_strategies": [
                    {
                        "id": price.id,
                        "time_slot": price.time_slot,
                        "price": float(price.price),
                        "weekday_price": float(price.weekday_price),
                        "weekend_price": float(price.weekend_price),
                        "holiday_price": float(price.holiday_price)
                    }
                    for price in price_strategies
                ]
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/search", response_model=dict)
async def search_stores(
    keyword: str = Query(..., min_length=2),
    city: Optional[str] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """搜索门店"""
    try:
        store_service = StoreService(db)
        stores = await store_service.search_stores(
            keyword=keyword,
            city=city,
            page=page,
            limit=limit
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "stores": [
                    {
                        "id": store.id,
                        "name": store.name,
                        "address": store.address,
                        "phone": store.phone,
                        "status": store.status,
                        "distance": float(store.distance) if hasattr(store, 'distance') else None
                    }
                    for store in stores["items"]
                ],
                "total": stores["total"],
                "page": page,
                "limit": limit
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
