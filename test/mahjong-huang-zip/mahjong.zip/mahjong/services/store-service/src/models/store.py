"""门店和房间模型"""
from sqlalchemy import String, Enum, DECIMAL, JSON, ForeignKey, DateTime, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from enum import Enum as PyEnum
from datetime import time
from typing import Optional, List

from shared.common.database import BaseModel


class StoreStatus(PyEnum):
    """门店状态"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    MAINTENANCE = "maintenance"


class RoomType(PyEnum):
    """房间类型"""
    MAHJONG = "mahjong"
    TEA_ROOM = "tea_room"
    KTV = "ktv"
    MEETING = "meeting"


class RoomStatus(PyEnum):
    """房间状态"""
    AVAILABLE = "available"
    OCCUPIED = "occupied"
    MAINTENANCE = "maintenance"
    CLEANING = "cleaning"


class Store(BaseModel):
    """门店模型"""
    __tablename__ = "stores"
    
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    address: Mapped[str] = mapped_column(Text, nullable=False)
    phone: Mapped[str] = mapped_column(String(20), nullable=True)
    business_hours: Mapped[dict] = mapped_column(JSON, default={
        "weekday": {"open": "09:00", "close": "22:00"},
        "weekend": {"open": "09:00", "close": "24:00"}
    })
    status: Mapped[StoreStatus] = mapped_column(Enum(StoreStatus), default=StoreStatus.ACTIVE)
    manager_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=True)
    settings: Mapped[dict] = mapped_column(JSON, default={
        "cleaning_duration": 30,  # 清洁时长（分钟）
        "advance_booking_days": 7,  # 可提前预订天数
        "min_booking_hours": 1,  # 最少预订时长
        "max_booking_hours": 24  # 最多预订时长
    })
    
    # 关系
    rooms: Mapped[List["Room"]] = relationship("Room", back_populates="store", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Store(id={self.id}, name={self.name})>"


class Room(BaseModel):
    """房间模型"""
    __tablename__ = "rooms"
    
    store_id: Mapped[int] = mapped_column(ForeignKey("stores.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(50), nullable=False)
    type: Mapped[RoomType] = mapped_column(Enum(RoomType), nullable=False)
    capacity: Mapped[int] = mapped_column(default=4)
    price_per_hour: Mapped[float] = mapped_column(DECIMAL(10, 2), nullable=False)
    price_per_night: Mapped[float] = mapped_column(DECIMAL(10, 2), nullable=True)  # 通宵价格
    status: Mapped[RoomStatus] = mapped_column(Enum(RoomStatus), default=RoomStatus.AVAILABLE)
    device_info: Mapped[dict] = mapped_column(JSON, default={
        "door_lock": None,
        "light": None,
        "ac": None,
        "monitor": None
    })
    features: Mapped[dict] = mapped_column(JSON, default={
        "has_wifi": True,
        "has_ac": True,
        "has_tv": False,
        "has_fridge": False
    })
    
    # 关系
    store: Mapped[Store] = relationship("Store", back_populates="rooms")
    
    def __repr__(self):
        return f"<Room(id={self.id}, name={self.name}, store_id={self.store_id})>"


class RoomPrice(BaseModel):
    """房间价格策略模型"""
    __tablename__ = "room_prices"
    
    room_id: Mapped[int] = mapped_column(ForeignKey("rooms.id"), nullable=False)
    day_type: Mapped[str] = mapped_column(String(10), nullable=False)  # weekday, weekend, holiday
    start_time: Mapped[str] = mapped_column(String(5), nullable=False)  # HH:MM
    end_time: Mapped[str] = mapped_column(String(5), nullable=False)  # HH:MM
    price: Mapped[float] = mapped_column(DECIMAL(10, 2), nullable=False)
    
    def __repr__(self):
        return f"<RoomPrice(room_id={self.room_id}, day_type={self.day_type}, price={self.price})>"
