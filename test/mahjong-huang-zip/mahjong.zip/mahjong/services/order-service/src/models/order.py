"""订单模型"""
from sqlalchemy import String, Enum, DECIMAL, ForeignKey, DateTime, Integer, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from enum import Enum as PyEnum
from datetime import datetime

from shared.common.database import BaseModel


class OrderStatus(PyEnum):
    """订单状态"""
    PENDING = "pending"  # 待支付
    CONFIRMED = "confirmed"  # 已确认
    IN_PROGRESS = "in_progress"  # 使用中
    COMPLETED = "completed"  # 已完成
    CANCELLED = "cancelled"  # 已取消
    REFUNDED = "refunded"  # 已退款


class PaymentStatus(PyEnum):
    """支付状态"""
    UNPAID = "unpaid"
    PAID = "paid"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"


class PaymentMethod(PyEnum):
    """支付方式"""
    WECHAT = "wechat"
    BALANCE = "balance"
    GROUPBUY = "groupbuy"
    PACKAGE = "package"


class Order(BaseModel):
    """订单模型"""
    __tablename__ = "orders"
    
    order_no: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    store_id: Mapped[int] = mapped_column(ForeignKey("stores.id"), nullable=False)
    room_id: Mapped[int] = mapped_column(ForeignKey("rooms.id"), nullable=False)
    
    start_time: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    end_time: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    duration_hours: Mapped[int] = mapped_column(Integer, nullable=False)
    
    total_amount: Mapped[float] = mapped_column(DECIMAL(10, 2), nullable=False)
    discount_amount: Mapped[float] = mapped_column(DECIMAL(10, 2), default=0.00)
    final_amount: Mapped[float] = mapped_column(DECIMAL(10, 2), nullable=False)
    
    status: Mapped[OrderStatus] = mapped_column(Enum(OrderStatus), default=OrderStatus.PENDING)
    payment_method: Mapped[PaymentMethod] = mapped_column(Enum(PaymentMethod), nullable=True)
    payment_status: Mapped[PaymentStatus] = mapped_column(Enum(PaymentStatus), default=PaymentStatus.UNPAID)
    
    # 额外信息
    notes: Mapped[str] = mapped_column(Text, nullable=True)
    extra_data: Mapped[dict] = mapped_column(JSON, default={})
    
    # 时间相关
    actual_start_time: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    actual_end_time: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    
    def __repr__(self):
        return f"<Order(id={self.id}, order_no={self.order_no}, status={self.status})>"


class OrderExtension(BaseModel):
    """订单续费记录"""
    __tablename__ = "order_extensions"
    
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), nullable=False)
    original_end_time: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    new_end_time: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    extended_hours: Mapped[int] = mapped_column(Integer, nullable=False)
    extension_fee: Mapped[float] = mapped_column(DECIMAL(10, 2), nullable=False)
    
    def __repr__(self):
        return f"<OrderExtension(id={self.id}, order_id={self.order_id}, extended_hours={self.extended_hours})>"


class OrderShare(BaseModel):
    """订单分享记录"""
    __tablename__ = "order_shares"
    
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), nullable=False)
    share_code: Mapped[str] = mapped_column(String(8), unique=True, nullable=False)
    max_uses: Mapped[int] = mapped_column(Integer, default=1)
    current_uses: Mapped[int] = mapped_column(Integer, default=0)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    is_active: Mapped[bool] = mapped_column(default=True)
    
    def __repr__(self):
        return f"<OrderShare(id={self.id}, share_code={self.share_code})>"
