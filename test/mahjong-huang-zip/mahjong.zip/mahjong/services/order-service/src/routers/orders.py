from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional

from shared.common.database import get_db
from shared.auth.jwt_handler import verify_token
from ..models.order import Order, OrderStatus
from ..schemas.order import OrderCreate, OrderUpdate, OrderRenew
from ..services.order_service import OrderService

router = APIRouter(prefix="/orders", tags=["订单"])
security = HTTPBearer()

@router.post("", response_model=dict)
async def create_order(
    order_data: OrderCreate,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """创建订单"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        order_service = OrderService(db)
        
        # 验证订单时间
        if order_data.start_time >= order_data.end_time:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="结束时间必须晚于开始时间"
            )
        
        # 计算时长
        duration_hours = (order_data.end_time - order_data.start_time).total_seconds() / 3600
        
        # 创建订单
        order = await order_service.create_order(
            user_id=user_id,
            store_id=order_data.store_id,
            room_id=order_data.room_id,
            start_time=order_data.start_time,
            end_time=order_data.end_time,
            duration_hours=duration_hours,
            payment_method=order_data.payment_method,
            notes=order_data.notes
        )
        
        return {
            "code": 200,
            "message": "订单创建成功",
            "data": {
                "order": {
                    "id": order.id,
                    "order_no": order.order_no,
                    "store_name": order.store_name,
                    "room_name": order.room_name,
                    "start_time": order.start_time.isoformat(),
                    "end_time": order.end_time.isoformat(),
                    "duration_hours": float(order.duration_hours),
                    "total_amount": float(order.total_amount),
                    "status": order.status,
                    "created_at": order.created_at.isoformat()
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("", response_model=dict)
async def get_orders(
    status: Optional[str] = None,
    store_id: Optional[int] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取订单列表"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        order_service = OrderService(db)
        orders = await order_service.get_user_orders(
            user_id=user_id,
            status=status,
            store_id=store_id,
            page=page,
            limit=limit
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "orders": [
                    {
                        "id": order.id,
                        "order_no": order.order_no,
                        "store_name": order.store_name,
                        "room_name": order.room_name,
                        "start_time": order.start_time.isoformat(),
                        "end_time": order.end_time.isoformat(),
                        "duration_hours": float(order.duration_hours),
                        "total_amount": float(order.total_amount),
                        "status": order.status,
                        "payment_status": order.payment_status,
                        "created_at": order.created_at.isoformat()
                    }
                    for order in orders["items"]
                ],
                "total": orders["total"],
                "page": page,
                "limit": limit
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/{order_id}", response_model=dict)
async def get_order_detail(
    order_id: int,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取订单详情"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        order_service = OrderService(db)
        order = await order_service.get_order_by_id(order_id)
        
        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="订单不存在"
            )
        
        # 验证订单归属
        if order.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权查看此订单"
            )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "id": order.id,
                "order_no": order.order_no,
                "store": {
                    "id": order.store_id,
                    "name": order.store_name,
                    "address": order.store_address,
                    "phone": order.store_phone
                },
                "room": {
                    "id": order.room_id,
                    "name": order.room_name,
                    "type": order.room_type,
                    "capacity": order.room_capacity
                },
                "start_time": order.start_time.isoformat(),
                "end_time": order.end_time.isoformat(),
                "duration_hours": float(order.duration_hours),
                "total_amount": float(order.total_amount),
                "actual_amount": float(order.actual_amount),
                "discount_amount": float(order.discount_amount or 0),
                "status": order.status,
                "payment_status": order.payment_status,
                "payment_method": order.payment_method,
                "notes": order.notes,
                "qr_code": order.qr_code,
                "door_code": order.door_code,
                "created_at": order.created_at.isoformat(),
                "updated_at": order.updated_at.isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/{order_id}/renew", response_model=dict)
async def renew_order(
    order_id: int,
    renew_data: OrderRenew,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """订单续费"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        order_service = OrderService(db)
        
        # 验证订单
        order = await order_service.get_order_by_id(order_id)
        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="订单不存在"
            )
        
        if order.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权操作此订单"
            )
        
        if order.status not in [OrderStatus.CONFIRMED, OrderStatus.IN_PROGRESS]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="当前订单状态不允许续费"
            )
        
        # 续费订单
        renewed_order = await order_service.renew_order(
            order_id=order_id,
            extend_hours=renew_data.extend_hours
        )
        
        return {
            "code": 200,
            "message": "续费成功",
            "data": {
                "order": {
                    "id": renewed_order.id,
                    "order_no": renewed_order.order_no,
                    "new_end_time": renewed_order.end_time.isoformat(),
                    "new_total_amount": float(renewed_order.total_amount),
                    "extend_hours": renew_data.extend_hours,
                    "extend_amount": float(renewed_order.extend_amount)
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/{order_id}/cancel", response_model=dict)
async def cancel_order(
    order_id: int,
    reason: Optional[str] = None,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """取消订单"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        order_service = OrderService(db)
        
        # 验证订单
        order = await order_service.get_order_by_id(order_id)
        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="订单不存在"
            )
        
        if order.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权操作此订单"
            )
        
        if order.status not in [OrderStatus.PENDING, OrderStatus.CONFIRMED]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="当前订单状态不允许取消"
            )
        
        # 取消订单
        cancelled_order = await order_service.cancel_order(
            order_id=order_id,
            reason=reason
        )
        
        return {
            "code": 200,
            "message": "取消成功",
            "data": {
                "order": {
                    "id": cancelled_order.id,
                    "order_no": cancelled_order.order_no,
                    "status": cancelled_order.status,
                    "cancel_reason": cancelled_order.cancel_reason,
                    "refund_amount": float(cancelled_order.refund_amount or 0)
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/{order_id}/open-door", response_model=dict)
async def open_door(
    order_id: int,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """开门操作"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        order_service = OrderService(db)
        
        # 验证订单
        order = await order_service.get_order_by_id(order_id)
        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="订单不存在"
            )
        
        if order.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权操作此订单"
            )
        
        if order.status != OrderStatus.CONFIRMED:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="订单未确认，无法开门"
            )
        
        # 检查时间是否在有效范围内
        now = datetime.utcnow()
        if now < order.start_time - timedelta(minutes=15):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="未到开门时间"
            )
        
        if now > order.end_time + timedelta(minutes=30):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="已超过使用时间"
            )
        
        # 执行开门操作
        door_result = await order_service.open_door(order_id)
        
        return {
            "code": 200,
            "message": "开门成功",
            "data": {
                "door_code": door_result["door_code"],
                "expires_in": door_result["expires_in"],
                "message": "请在5分钟内进入房间"
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/upcoming/checkin", response_model=dict)
async def get_upcoming_checkin(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取即将入住的订单"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        order_service = OrderService(db)
        orders = await order_service.get_upcoming_checkin(user_id)
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "orders": [
                    {
                        "id": order.id,
                        "order_no": order.order_no,
                        "store_name": order.store_name,
                        "room_name": order.room_name,
                        "start_time": order.start_time.isoformat(),
                        "door_code": order.door_code,
                        "qr_code": order.qr_code
                    }
                    for order in orders
                ]
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
