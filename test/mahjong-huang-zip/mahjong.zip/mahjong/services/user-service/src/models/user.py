"""用户模型"""
from sqlalchemy import String, Enum, DECIMAL, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from enum import Enum as PyEnum

from shared.common.database import BaseModel


class UserType(PyEnum):
    """用户类型枚举"""
    CUSTOMER = "customer"
    STORE_MANAGER = "store_manager"
    CLEANER = "cleaner"
    ADMIN = "admin"


class UserStatus(PyEnum):
    """用户状态枚举"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    BANNED = "banned"


class User(BaseModel):
    """用户模型"""
    __tablename__ = "users"
    
    username: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    phone: Mapped[str] = mapped_column(String(20), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(100), nullable=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    real_name: Mapped[str] = mapped_column(String(50), nullable=True)
    avatar_url: Mapped[str] = mapped_column(Text, nullable=True)
    balance: Mapped[float] = mapped_column(DECIMAL(10, 2), default=0.00)
    status: Mapped[UserStatus] = mapped_column(
        Enum(UserStatus), 
        default=UserStatus.ACTIVE
    )
    user_type: Mapped[UserType] = mapped_column(
        Enum(UserType), 
        default=UserType.CUSTOMER
    )
    
    def __repr__(self):
        return f"<User(id={self.id}, username={self.username}, phone={self.phone})>"
