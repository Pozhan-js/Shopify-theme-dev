"""用户数据模型"""
from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional
from datetime import datetime

from src.models.user import UserType, UserStatus


class UserBase(BaseModel):
    """用户基础模型"""
    username: str = Field(..., min_length=3, max_length=50)
    phone: str = Field(..., regex=r'^1[3-9]\d{9}$')
    email: Optional[EmailStr] = None
    real_name: Optional[str] = Field(None, max_length=50)
    avatar_url: Optional[str] = None


class UserCreate(UserBase):
    """创建用户模型"""
    password: str = Field(..., min_length=6, max_length=128)
    
    @validator('username')
    def username_alphanumeric(cls, v):
        if not v.isalnum():
            raise ValueError('用户名只能包含字母和数字')
        return v


class UserUpdate(BaseModel):
    """更新用户模型"""
    email: Optional[EmailStr] = None
    real_name: Optional[str] = Field(None, max_length=50)
    avatar_url: Optional[str] = None


class UserResponse(UserBase):
    """用户响应模型"""
    id: int
    balance: float
    status: UserStatus
    user_type: UserType
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class UserLogin(BaseModel):
    """用户登录模型"""
    username: str
    password: str


class TokenResponse(BaseModel):
    """令牌响应模型"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class PasswordChange(BaseModel):
    """密码修改模型"""
    old_password: str
    new_password: str = Field(..., min_length=6, max_length=128)


class PasswordReset(BaseModel):
    """密码重置模型"""
    phone: str = Field(..., regex=r'^1[3-9]\d{9}$')
    new_password: str = Field(..., min_length=6, max_length=128)
    verification_code: str = Field(..., min_length=4, max_length=6)
