"""用户服务业务逻辑"""
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from sqlalchemy.orm import selectinload
from typing import Optional, List
import uuid

from src.models.user import User, UserType, UserStatus
from src.schemas.user import UserCreate, UserUpdate
from shared.auth.jwt_handler import PasswordHandler, JWTHandler
from shared.common.database import db_manager


class UserService:
    """用户服务类"""
    
    @staticmethod
    async def create_user(db: AsyncSession, user_data: UserCreate) -> User:
        """创建用户"""
        # 检查用户名是否已存在
        existing_user = await UserService.get_user_by_username(db, user_data.username)
        if existing_user:
            raise ValueError("用户名已存在")
        
        # 检查手机号是否已存在
        existing_user = await UserService.get_user_by_phone(db, user_data.phone)
        if existing_user:
            raise ValueError("手机号已注册")
        
        # 创建新用户
        user = User(
            username=user_data.username,
            phone=user_data.phone,
            email=user_data.email,
            password_hash=PasswordHandler.hash_password(user_data.password),
            real_name=user_data.real_name,
            avatar_url=user_data.avatar_url,
        )
        
        db.add(user)
        await db.commit()
        await db.refresh(user)
        return user
    
    @staticmethod
    async def get_user_by_id(db: AsyncSession, user_id: int) -> Optional[User]:
        """根据ID获取用户"""
        result = await db.execute(
            select(User).where(User.id == user_id)
        )
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_user_by_username(db: AsyncSession, username: str) -> Optional[User]:
        """根据用户名获取用户"""
        result = await db.execute(
            select(User).where(User.username == username)
        )
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_user_by_phone(db: AsyncSession, phone: str) -> Optional[User]:
        """根据手机号获取用户"""
        result = await db.execute(
            select(User).where(User.phone == phone)
        )
        return result.scalar_one_or_none()
    
    @staticmethod
    async def authenticate_user(db: AsyncSession, username: str, password: str) -> Optional[User]:
        """用户认证"""
        user = await UserService.get_user_by_username(db, username)
        if not user:
            return None
        
        if user.status == UserStatus.BANNED:
            raise ValueError("账户已被禁用")
        
        if not PasswordHandler.verify_password(password, user.password_hash):
            return None
        
        return user
    
    @staticmethod
    async def update_user(db: AsyncSession, user_id: int, user_data: UserUpdate) -> Optional[User]:
        """更新用户信息"""
        user = await UserService.get_user_by_id(db, user_id)
        if not user:
            return None
        
        update_data = user_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(user, field, value)
        
        await db.commit()
        await db.refresh(user)
        return user
    
    @staticmethod
    async def change_password(db: AsyncSession, user_id: int, old_password: str, new_password: str) -> bool:
        """修改密码"""
        user = await UserService.get_user_by_id(db, user_id)
        if not user:
            return False
        
        if not PasswordHandler.verify_password(old_password, user.password_hash):
            raise ValueError("原密码错误")
        
        user.password_hash = PasswordHandler.hash_password(new_password)
        await db.commit()
        return True
    
    @staticmethod
    async def reset_password(db: AsyncSession, phone: str, new_password: str) -> bool:
        """重置密码"""
        user = await UserService.get_user_by_phone(db, phone)
        if not user:
            return False
        
        user.password_hash = PasswordHandler.hash_password(new_password)
        await db.commit()
        return True
    
    @staticmethod
    async def get_users(
        db: AsyncSession,
        skip: int = 0,
        limit: int = 100,
        user_type: Optional[UserType] = None,
        status: Optional[UserStatus] = None
    ) -> List[User]:
        """获取用户列表"""
        query = select(User).offset(skip).limit(limit)
        
        if user_type:
            query = query.where(User.user_type == user_type)
        
        if status:
            query = query.where(User.status == status)
        
        result = await db.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def update_user_status(db: AsyncSession, user_id: int, status: UserStatus) -> bool:
        """更新用户状态"""
        user = await UserService.get_user_by_id(db, user_id)
        if not user:
            return False
        
        user.status = status
        await db.commit()
        return True
    
    @staticmethod
    async def update_user_balance(db: AsyncSession, user_id: int, amount: float) -> bool:
        """更新用户余额"""
        user = await UserService.get_user_by_id(db, user_id)
        if not user:
            return False
        
        user.balance += amount
        await db.commit()
        return True
    
    @staticmethod
    async def generate_tokens(user: User) -> dict:
        """生成用户令牌"""
        token_data = {
            "sub": str(user.id),
            "username": user.username,
            "phone": user.phone,
            "role": user.user_type.value,
            "permissions": UserService.get_user_permissions(user.user_type)
        }
        
        access_token = JWTHandler.create_access_token(token_data)
        refresh_token = JWTHandler.create_refresh_token(token_data)
        
        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "expires_in": 1800  # 30分钟
        }
    
    @staticmethod
    def get_user_permissions(user_type: UserType) -> List[str]:
        """获取用户权限列表"""
        permissions = {
            UserType.CUSTOMER: ["read_profile", "update_profile", "create_order", "read_order"],
            UserType.CLEANER: ["read_cleaning_tasks", "update_room_status", "read_store_info"],
            UserType.STORE_MANAGER: [
                "read_profile", "update_profile", "create_order", "read_order",
                "manage_store", "manage_rooms", "view_analytics", "manage_cleaners"
            ],
            UserType.ADMIN: ["*"]  # 所有权限
        }
        return permissions.get(user_type, [])
