from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timedelta
from typing import Optional

from shared.common.database import get_db
from shared.auth.jwt_handler import verify_token
from ..services.admin_service import AdminService

router = APIRouter(prefix="/admin", tags=["管理员"])
security = HTTPBearer()

@router.get("/stats", response_model=dict)
async def get_admin_stats(
    store_id: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取数据统计"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        # 验证管理员权限
        if payload.get("type") not in ["admin", "store_manager"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无管理员权限"
            )
        
        admin_service = AdminService(db)
        
        # 解析日期
        start_dt = None
        end_dt = None
        if start_date:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        if end_date:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        
        stats = await admin_service.get_statistics(
            user_id=user_id,
            store_id=store_id,
            start_date=start_dt,
            end_date=end_dt
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "today": {
                    "orders": stats["today_orders"],
                    "revenue": float(stats["today_revenue"]),
                    "new_users": stats["today_new_users"]
                },
                "yesterday": {
                    "orders": stats["yesterday_orders"],
                    "revenue": float(stats["yesterday_revenue"]),
                    "new_users": stats["yesterday_new_users"]
                },
                "this_month": {
                    "orders": stats["month_orders"],
                    "revenue": float(stats["month_revenue"]),
                    "new_users": stats["month_new_users"]
                },
                "total": {
                    "users": stats["total_users"],
                    "orders": stats["total_orders"],
                    "revenue": float(stats["total_revenue"])
                },
                "occupancy_rate": float(stats["occupancy_rate"]),
                "popular_rooms": stats["popular_rooms"]
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/orders", response_model=dict)
async def get_admin_orders(
    store_id: Optional[int] = None,
    status: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取订单管理列表"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        # 验证管理员权限
        if payload.get("type") not in ["admin", "store_manager"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无管理员权限"
            )
        
        admin_service = AdminService(db)
        
        # 解析日期
        start_dt = None
        end_dt = None
        if start_date:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        if end_date:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        
        orders = await admin_service.get_orders(
            user_id=user_id,
            store_id=store_id,
            status=status,
            start_date=start_dt,
            end_date=end_dt,
            page=page,
            limit=limit
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "orders": [
                    {
                        "id": order.id,
                        "order_no": order.order_no,
                        "user": {
                            "id": order.user_id,
                            "username": order.username,
                            "phone": order.phone
                        },
                        "store": {
                            "id": order.store_id,
                            "name": order.store_name
                        },
                        "room": {
                            "id": order.room_id,
                            "name": order.room_name
                        },
                        "start_time": order.start_time.isoformat(),
                        "end_time": order.end_time.isoformat(),
                        "duration_hours": float(order.duration_hours),
                        "total_amount": float(order.total_amount),
                        "status": order.status,
                        "payment_status": order.payment_status,
                        "created_at": order.created_at.isoformat()
                    }
                    for order in orders["items"]
                ],
                "total": orders["total"],
                "page": page,
                "limit": limit
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/orders/{order_id}/modify", response_model=dict)
async def modify_order(
    order_id: int,
    end_time: Optional[str] = None,
    notes: Optional[str] = None,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """修改订单"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        # 验证管理员权限
        if payload.get("type") not in ["admin", "store_manager"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无管理员权限"
            )
        
        admin_service = AdminService(db)
        
        # 解析新的结束时间
        new_end_time = None
        if end_time:
            new_end_time = datetime.fromisoformat(end_time)
        
        modified_order = await admin_service.modify_order(
            order_id=order_id,
            new_end_time=new_end_time,
            notes=notes,
            admin_id=user_id
        )
        
        if not modified_order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="订单不存在"
            )
        
        return {
            "code": 200,
            "message": "订单修改成功",
            "data": {
                "order": {
                    "id": modified_order.id,
                    "order_no": modified_order.order_no,
                    "new_end_time": modified_order.end_time.isoformat(),
                    "new_total_amount": float(modified_order.total_amount),
                    "notes": modified_order.notes,
                    "modified_by": user_id
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/devices", response_model=dict)
async def get_devices(
    store_id: Optional[int] = None,
    device_type: Optional[str] = None,
    status: Optional[str] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取设备列表"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        # 验证管理员权限
        if payload.get("type") not in ["admin", "store_manager"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无管理员权限"
            )
        
        admin_service = AdminService(db)
        devices = await admin_service.get_devices(
            user_id=user_id,
            store_id=store_id,
            device_type=device_type,
            status=status,
            page=page,
            limit=limit
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "devices": [
                    {
                        "id": device.id,
                        "store_id": device.store_id,
                        "store_name": device.store_name,
                        "device_type": device.device_type,
                        "device_name": device.device_name,
                        "device_code": device.device_code,
                        "status": device.status,
                        "last_online": device.last_online.isoformat() if device.last_online else None,
                        "location": device.location,
                        "description": device.description
                    }
                    for device in devices["items"]
                ],
                "total": devices["total"],
                "page": page,
                "limit": limit
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/devices/{device_id}/control", response_model=dict)
async def control_device(
    device_id: int,
    action: str,
    data: Optional[dict] = None,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """设备控制"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        # 验证管理员权限
        if payload.get("type") not in ["admin", "store_manager"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无管理员权限"
            )
        
        admin_service = AdminService(db)
        
        # 控制设备
        result = await admin_service.control_device(
            device_id=device_id,
            action=action,
            data=data or {},
            admin_id=user_id
        )
        
        if not result["success"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=result["message"]
            )
        
        return {
            "code": 200,
            "message": "设备控制成功",
            "data": {
                "device_id": device_id,
                "action": action,
                "result": result["data"]
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/dashboard", response_model=dict)
async def get_dashboard(
    store_id: Optional[int] = None,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取管理后台仪表盘数据"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        # 验证管理员权限
        if payload.get("type") not in ["admin", "store_manager"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无管理员权限"
            )
        
        admin_service = AdminService(db)
        dashboard = await admin_service.get_dashboard(
            user_id=user_id,
            store_id=store_id
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": dashboard
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
