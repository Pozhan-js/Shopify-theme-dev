from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional

from shared.common.database import get_db
from shared.auth.jwt_handler import create_access_token, create_refresh_token, verify_token
from shared.auth.wechat_auth import WeChatAuth
from .schemas.user import UserLogin, UserCreate, TokenResponse, UserProfile
from .services.user_service import UserService

router = APIRouter(prefix="/auth", tags=["认证"])
security = HTTPBearer()

@router.post("/wx-login", response_model=dict)
async def wechat_login(
    code: str,
    db: AsyncSession = Depends(get_db)
):
    """微信小程序登录"""
    try:
        # 获取微信用户信息
        wx_auth = WeChatAuth()
        wx_user = await wx_auth.get_user_info(code)
        
        if not wx_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="微信登录失败"
            )
        
        user_service = UserService(db)
        
        # 查找或创建用户
        user = await user_service.get_or_create_wechat_user(
            openid=wx_user["openid"],
            unionid=wx_user.get("unionid"),
            nickname=wx_user.get("nickname"),
            avatar_url=wx_user.get("headimgurl"),
            phone=wx_user.get("phone")
        )
        
        # 创建令牌
        access_token = create_access_token({"sub": str(user.id), "type": user.user_type})
        refresh_token = create_refresh_token({"sub": str(user.id)})
        
        return {
            "code": 200,
            "message": "登录成功",
            "data": {
                "token": access_token,
                "refresh_token": refresh_token,
                "user_info": {
                    "id": user.id,
                    "username": user.username,
                    "phone": user.phone,
                    "real_name": user.real_name,
                    "avatar_url": user.avatar_url,
                    "user_type": user.user_type,
                    "balance": float(user.balance)
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/login", response_model=dict)
async def web_login(
    login_data: UserLogin,
    db: AsyncSession = Depends(get_db)
):
    """Web后台登录"""
    try:
        user_service = UserService(db)
        user = await user_service.authenticate_user(
            username=login_data.username,
            password=login_data.password
        )
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="用户名或密码错误"
            )
        
        # 创建令牌
        access_token = create_access_token({"sub": str(user.id), "type": user.user_type})
        refresh_token = create_refresh_token({"sub": str(user.id)})
        
        return {
            "code": 200,
            "message": "登录成功",
            "data": {
                "token": access_token,
                "refresh_token": refresh_token,
                "user_info": {
                    "id": user.id,
                    "username": user.username,
                    "real_name": user.real_name,
                    "user_type": user.user_type,
                    "permissions": ["*"] if user.user_type == "admin" else []
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/refresh", response_model=dict)
async def refresh_token(
    refresh_token: str,
    db: AsyncSession = Depends(get_db)
):
    """刷新访问令牌"""
    try:
        payload = verify_token(refresh_token, token_type="refresh")
        user_id = int(payload.get("sub"))
        
        user_service = UserService(db)
        user = await user_service.get_user_by_id(user_id)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="用户不存在"
            )
        
        # 创建新的令牌
        new_access_token = create_access_token({"sub": str(user.id), "type": user.user_type})
        new_refresh_token = create_refresh_token({"sub": str(user.id)})
        
        return {
            "code": 200,
            "message": "令牌刷新成功",
            "data": {
                "token": new_access_token,
                "refresh_token": new_refresh_token
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="刷新令牌无效"
        )

@router.post("/logout", response_model=dict)
async def logout(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """退出登录"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        
        # 这里可以添加令牌黑名单逻辑
        
        return {
            "code": 200,
            "message": "退出成功"
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/profile", response_model=dict)
async def get_profile(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取用户信息"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        user_service = UserService(db)
        user = await user_service.get_user_by_id(user_id)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="用户不存在"
            )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "id": user.id,
                "username": user.username,
                "phone": user.phone,
                "email": user.email,
                "real_name": user.real_name,
                "avatar_url": user.avatar_url,
                "user_type": user.user_type,
                "balance": float(user.balance),
                "points": user.points,
                "created_at": user.created_at.isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
