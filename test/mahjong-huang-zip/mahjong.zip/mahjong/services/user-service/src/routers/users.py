from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from decimal import Decimal

from shared.common.database import get_db
from shared.auth.jwt_handler import verify_token
from .schemas.user import UserUpdate, BalanceRecharge
from .services.user_service import UserService

router = APIRouter(prefix="/users", tags=["用户"])
security = HTTPBearer()

@router.get("/profile", response_model=dict)
async def get_user_profile(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取用户详细信息"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        user_service = UserService(db)
        user = await user_service.get_user_by_id(user_id)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="用户不存在"
            )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "id": user.id,
                "username": user.username,
                "phone": user.phone,
                "email": user.email,
                "real_name": user.real_name,
                "avatar_url": user.avatar_url,
                "user_type": user.user_type,
                "balance": float(user.balance),
                "points": user.points,
                "total_recharge": float(user.total_recharge or 0),
                "total_consumption": float(user.total_consumption or 0),
                "created_at": user.created_at.isoformat(),
                "updated_at": user.updated_at.isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.put("/profile", response_model=dict)
async def update_user_profile(
    update_data: UserUpdate,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """更新用户信息"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        user_service = UserService(db)
        updated_user = await user_service.update_user_profile(
            user_id=user_id,
            update_data=update_data
        )
        
        if not updated_user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="用户不存在"
            )
        
        return {
            "code": 200,
            "message": "更新成功",
            "data": {
                "id": updated_user.id,
                "username": updated_user.username,
                "phone": updated_user.phone,
                "email": updated_user.email,
                "real_name": updated_user.real_name,
                "avatar_url": updated_user.avatar_url
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/balance", response_model=dict)
async def get_user_balance(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取用户余额信息"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        user_service = UserService(db)
        balance_info = await user_service.get_user_balance(user_id)
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "balance": float(balance_info["balance"]),
                "frozen_amount": float(balance_info["frozen_amount"]),
                "total_recharge": float(balance_info["total_recharge"]),
                "total_consumption": float(balance_info["total_consumption"])
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/recharge", response_model=dict)
async def recharge_balance(
    recharge_data: BalanceRecharge,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """余额充值"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        user_service = UserService(db)
        
        # 创建充值订单
        recharge_order = await user_service.create_recharge_order(
            user_id=user_id,
            amount=Decimal(str(recharge_data.amount)),
            payment_method=recharge_data.payment_method
        )
        
        return {
            "code": 200,
            "message": "充值订单创建成功",
            "data": {
                "order_id": recharge_order.id,
                "order_no": recharge_order.order_no,
                "amount": float(recharge_order.amount),
                "payment_method": recharge_order.payment_method,
                "status": recharge_order.status,
                "created_at": recharge_order.created_at.isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/transactions", response_model=dict)
async def get_transaction_history(
    page: int = 1,
    limit: int = 10,
    transaction_type: str = None,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取交易记录"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        user_service = UserService(db)
        transactions = await user_service.get_user_transactions(
            user_id=user_id,
            page=page,
            limit=limit,
            transaction_type=transaction_type
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "transactions": [
                    {
                        "id": t.id,
                        "transaction_type": t.transaction_type,
                        "amount": float(t.amount),
                        "balance_after": float(t.balance_after),
                        "description": t.description,
                        "created_at": t.created_at.isoformat()
                    }
                    for t in transactions["items"]
                ],
                "total": transactions["total"],
                "page": page,
                "limit": limit
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
