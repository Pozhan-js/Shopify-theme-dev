from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from decimal import Decimal
from typing import Optional

from shared.common.database import get_db
from shared.auth.jwt_handler import verify_token
from ..models.payment import Payment, PaymentStatus, PaymentMethod
from ..services.payment_service import PaymentService
from ..schemas.payment import (
    WeChatPaymentRequest, 
    BalancePaymentRequest,
    GrouponPaymentRequest,
    RefundRequest
)

router = APIRouter(prefix="/payments", tags=["支付"])
security = HTTPBearer()

@router.post("/wechat", response_model=dict)
async def create_wechat_payment(
    payment_data: WeChatPaymentRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """创建微信支付"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        payment_service = PaymentService(db)
        
        # 验证订单
        order = await payment_service.get_order_by_id(payment_data.order_id)
        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="订单不存在"
            )
        
        if order.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权操作此订单"
            )
        
        if order.payment_status == "paid":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="订单已支付"
            )
        
        # 创建微信支付
        payment = await payment_service.create_wechat_payment(
            order_id=payment_data.order_id,
            amount=Decimal(str(payment_data.amount)),
            user_id=user_id
        )
        
        return {
            "code": 200,
            "message": "微信支付创建成功",
            "data": {
                "payment": {
                    "id": payment.id,
                    "payment_no": payment.payment_no,
                    "order_id": payment.order_id,
                    "amount": float(payment.amount),
                    "status": payment.status,
                    "wechat_pay_params": payment.wechat_pay_params
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/balance", response_model=dict)
async def create_balance_payment(
    payment_data: BalancePaymentRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """创建余额支付"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        payment_service = PaymentService(db)
        
        # 验证订单
        order = await payment_service.get_order_by_id(payment_data.order_id)
        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="订单不存在"
            )
        
        if order.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权操作此订单"
            )
        
        if order.payment_status == "paid":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="订单已支付"
            )
        
        # 验证支付密码
        is_valid = await payment_service.validate_payment_password(
            user_id=user_id,
            password=payment_data.password
        )
        
        if not is_valid:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="支付密码错误"
            )
        
        # 检查余额
        has_sufficient_balance = await payment_service.check_user_balance(
            user_id=user_id,
            amount=Decimal(str(payment_data.amount))
        )
        
        if not has_sufficient_balance:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="余额不足"
            )
        
        # 创建余额支付
        payment = await payment_service.create_balance_payment(
            order_id=payment_data.order_id,
            amount=Decimal(str(payment_data.amount)),
            user_id=user_id
        )
        
        return {
            "code": 200,
            "message": "余额支付成功",
            "data": {
                "payment": {
                    "id": payment.id,
                    "payment_no": payment.payment_no,
                    "order_id": payment.order_id,
                    "amount": float(payment.amount),
                    "status": payment.status,
                    "balance_after": float(payment.balance_after)
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/groupon", response_model=dict)
async def create_groupon_payment(
    payment_data: GrouponPaymentRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """创建团购支付"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        payment_service = PaymentService(db)
        
        # 验证订单
        order = await payment_service.get_order_by_id(payment_data.order_id)
        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="订单不存在"
            )
        
        if order.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权操作此订单"
            )
        
        if order.payment_status == "paid":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="订单已支付"
            )
        
        # 验证团购码
        groupon_info = await payment_service.validate_groupon_code(
            code=payment_data.groupon_code,
            user_id=user_id,
            order_amount=Decimal(str(payment_data.amount))
        )
        
        if not groupon_info["valid"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=groupon_info["message"]
            )
        
        # 创建团购支付
        payment = await payment_service.create_groupon_payment(
            order_id=payment_data.order_id,
            amount=Decimal(str(payment_data.amount)),
            groupon_code=payment_data.groupon_code,
            discount_amount=groupon_info["discount_amount"],
            user_id=user_id
        )
        
        return {
            "code": 200,
            "message": "团购支付成功",
            "data": {
                "payment": {
                    "id": payment.id,
                    "payment_no": payment.payment_no,
                    "order_id": payment.order_id,
                    "amount": float(payment.amount),
                    "discount_amount": float(payment.discount_amount),
                    "actual_amount": float(payment.actual_amount),
                    "status": payment.status
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/refund", response_model=dict)
async def create_refund(
    refund_data: RefundRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """创建退款申请"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        payment_service = PaymentService(db)
        
        # 验证订单
        order = await payment_service.get_order_by_id(refund_data.order_id)
        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="订单不存在"
            )
        
        if order.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权操作此订单"
            )
        
        if order.payment_status != "paid":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="订单未支付，无法退款"
            )
        
        if order.status not in ["cancelled", "completed"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="订单状态不允许退款"
            )
        
        # 计算可退款金额
        refund_amount = await payment_service.calculate_refund_amount(
            order_id=refund_data.order_id,
            refund_amount=Decimal(str(refund_data.refund_amount))
        )
        
        # 创建退款申请
        refund = await payment_service.create_refund(
            order_id=refund_data.order_id,
            refund_amount=refund_amount,
            reason=refund_data.reason,
            user_id=user_id
        )
        
        return {
            "code": 200,
            "message": "退款申请已提交",
            "data": {
                "refund": {
                    "id": refund.id,
                    "refund_no": refund.refund_no,
                    "order_id": refund.order_id,
                    "refund_amount": float(refund.refund_amount),
                    "status": refund.status,
                    "reason": refund.reason,
                    "created_at": refund.created_at.isoformat()
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/{payment_id}", response_model=dict)
async def get_payment_detail(
    payment_id: int,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取支付详情"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        payment_service = PaymentService(db)
        payment = await payment_service.get_payment_by_id(payment_id)
        
        if not payment:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="支付记录不存在"
            )
        
        if payment.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权查看此支付记录"
            )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "id": payment.id,
                "payment_no": payment.payment_no,
                "order_id": payment.order_id,
                "amount": float(payment.amount),
                "payment_method": payment.payment_method,
                "status": payment.status,
                "transaction_id": payment.transaction_id,
                "paid_at": payment.paid_at.isoformat() if payment.paid_at else None,
                "created_at": payment.created_at.isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/wechat/notify", response_model=dict)
async def wechat_payment_notify(
    notify_data: dict,
    db: AsyncSession = Depends(get_db)
):
    """微信支付回调"""
    try:
        payment_service = PaymentService(db)
        
        # 处理微信支付回调
        result = await payment_service.handle_wechat_notify(notify_data)
        
        if result["success"]:
            return {
                "code": 200,
                "message": "success",
                "data": result
            }
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=result["message"]
            )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/balance/history", response_model=dict)
async def get_balance_history(
    page: int = 1,
    limit: int = 10,
    transaction_type: Optional[str] = None,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取余额变动记录"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        payment_service = PaymentService(db)
        transactions = await payment_service.get_balance_history(
            user_id=user_id,
            page=page,
            limit=limit,
            transaction_type=transaction_type
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "transactions": [
                    {
                        "id": t.id,
                        "transaction_type": t.transaction_type,
                        "amount": float(t.amount),
                        "balance_after": float(t.balance_after),
                        "description": t.description,
                        "created_at": t.created_at.isoformat()
                    }
                    for t in transactions["items"]
                ],
                "total": transactions["total"],
                "page": page,
                "limit": limit
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
