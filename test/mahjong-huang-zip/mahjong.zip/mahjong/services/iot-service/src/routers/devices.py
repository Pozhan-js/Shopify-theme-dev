from fastapi import APIRouter, Depends, HTTPException, status, Query, BackgroundTasks
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional, List
from datetime import datetime, timedelta

from shared.common.database import get_db
from shared.auth.jwt_handler import verify_token
from ..models.device import Device, DeviceStatus, DeviceLog
from ..services.device_service import DeviceService
from ..protocols.mqtt_protocol import MQTTProtocol, DeviceCommandBuilder

router = APIRouter(prefix="/devices", tags=["设备管理"])
security = HTTPBearer()

# MQTT客户端实例
mqtt_client = None

def get_mqtt_client():
    """获取MQTT客户端"""
    global mqtt_client
    if mqtt_client is None:
        from shared.common.config import settings
        mqtt_client = MQTTProtocol(
            broker_host=settings.MQTT_BROKER_HOST,
            broker_port=settings.MQTT_BROKER_PORT
        )
        mqtt_client.start()
    return mqtt_client

@router.post("/{device_id}/control", response_model=dict)
async def control_device(
    device_id: str,
    command: str,
    data: Optional[dict] = None,
    background_tasks: BackgroundTasks,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """设备控制接口"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        # 验证权限
        if payload.get("type") not in ["admin", "store_manager"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无设备控制权限"
            )
        
        device_service = DeviceService(db)
        device = await device_service.get_device_by_code(device_id)
        
        if not device:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="设备不存在"
            )
        
        # 验证设备权限
        has_permission = await device_service.check_device_permission(
            user_id=user_id,
            device_id=device.id
        )
        
        if not has_permission:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权控制此设备"
            )
        
        # 获取MQTT客户端
        mqtt = get_mqtt_client()
        
        # 构建命令
        command_data = DeviceCommandBuilder.build_command(
            command=command,
            device_id=device_id,
            data=data or {},
            user_id=user_id
        )
        
        # 记录命令日志
        await device_service.log_device_command(
            device_id=device.id,
            command=command,
            data=command_data,
            user_id=user_id
        )
        
        # 发送命令到设备
        success = mqtt.send_command(device_id, command, command_data)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="设备通信失败"
            )
        
        return {
            "code": 200,
            "message": "命令发送成功",
            "data": {
                "device_id": device_id,
                "command": command,
                "status": "sent",
                "timestamp": datetime.now().isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/{device_id}/status", response_model=dict)
async def get_device_status(
    device_id: str,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取设备状态"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        device_service = DeviceService(db)
        device = await device_service.get_device_by_code(device_id)
        
        if not device:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="设备不存在"
            )
        
        # 验证设备权限
        has_permission = await device_service.check_device_permission(
            user_id=user_id,
            device_id=device.id
        )
        
        if not has_permission:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权查看此设备"
            )
        
        # 获取实时状态
        status_data = await device_service.get_device_status(device.id)
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "device_id": device_id,
                "device_name": device.name,
                "status": status_data["status"],
                "door_status": status_data.get("door_status"),
                "light_status": status_data.get("light_status"),
                "temperature": status_data.get("temperature"),
                "humidity": status_data.get("humidity"),
                "battery_level": status_data.get("battery_level"),
                "last_online": status_data.get("last_online"),
                "last_heartbeat": status_data.get("last_heartbeat")
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/{device_id}/heartbeat", response_model=dict)
async def receive_heartbeat(
    device_id: str,
    heartbeat_data: dict,
    db: AsyncSession = Depends(get_db)
):
    """接收设备心跳"""
    try:
        device_service = DeviceService(db)
        device = await device_service.get_device_by_code(device_id)
        
        if not device:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="设备不存在"
            )
        
        # 更新设备在线状态
        await device_service.update_device_status(
            device_id=device.id,
            status="online",
            last_online=datetime.now()
        )
        
        # 记录心跳日志
        await device_service.log_device_heartbeat(
            device_id=device.id,
            data=heartbeat_data
        )
        
        return {
            "code": 200,
            "message": "心跳接收成功",
            "data": {
                "device_id": device_id,
                "timestamp": datetime.now().isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/{device_id}/status", response_model=dict)
async def update_device_status(
    device_id: str,
    status_data: dict,
    db: AsyncSession = Depends(get_db)
):
    """更新设备状态"""
    try:
        device_service = DeviceService(db)
        device = await device_service.get_device_by_code(device_id)
        
        if not device:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="设备不存在"
            )
        
        # 更新设备状态
        await device_service.update_device_status(
            device_id=device.id,
            **status_data
        )
        
        # 记录状态日志
        await device_service.log_device_status(
            device_id=device.id,
            data=status_data
        )
        
        return {
            "code": 200,
            "message": "状态更新成功",
            "data": {
                "device_id": device_id,
                "updated_at": datetime.now().isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/{device_id}/logs", response_model=dict)
async def get_device_logs(
    device_id: str,
    log_type: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取设备日志"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        device_service = DeviceService(db)
        device = await device_service.get_device_by_code(device_id)
        
        if not device:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="设备不存在"
            )
        
        # 验证设备权限
        has_permission = await device_service.check_device_permission(
            user_id=user_id,
            device_id=device.id
        )
        
        if not has_permission:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权查看此设备日志"
            )
        
        # 解析日期
        start_dt = None
        end_dt = None
        if start_date:
            start_dt = datetime.fromisoformat(start_date)
        if end_date:
            end_dt = datetime.fromisoformat(end_date)
        
        logs = await device_service.get_device_logs(
            device_id=device.id,
            log_type=log_type,
            start_date=start_dt,
            end_date=end_dt,
            page=page,
            limit=limit
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "logs": [
                    {
                        "id": log.id,
                        "log_type": log.log_type,
                        "message": log.message,
                        "created_at": log.created_at.isoformat()
                    }
                    for log in logs["items"]
                ],
                "total": logs["total"],
                "page": page,
                "limit": limit
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.get("/online", response_model=dict)
async def get_online_devices(
    store_id: Optional[int] = None,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """获取在线设备列表"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        device_service = DeviceService(db)
        devices = await device_service.get_online_devices(
            user_id=user_id,
            store_id=store_id
        )
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "devices": [
                    {
                        "device_id": device.device_code,
                        "device_name": device.name,
                        "device_type": device.device_type,
                        "store_name": device.store_name,
                        "status": device.status,
                        "last_online": device.last_online.isoformat() if device.last_online else None
                    }
                    for device in devices
                ],
                "total": len(devices)
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/batch/control", response_model=dict)
async def batch_control_devices(
    device_ids: List[str],
    command: str,
    data: Optional[dict] = None,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """批量控制设备"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        user_id = int(payload.get("sub"))
        
        # 验证权限
        if payload.get("type") not in ["admin", "store_manager"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无设备控制权限"
            )
        
        mqtt = get_mqtt_client()
        device_service = DeviceService(db)
        
        success_count = 0
        failed_devices = []
        
        for device_id in device_ids:
            try:
                device = await device_service.get_device_by_code(device_id)
                if not device:
                    failed_devices.append({"device_id": device_id, "reason": "设备不存在"})
                    continue
                
                # 验证权限
                has_permission = await device_service.check_device_permission(
                    user_id=user_id,
                    device_id=device.id
                )
                
                if not has_permission:
                    failed_devices.append({"device_id": device_id, "reason": "无权限"})
                    continue
                
                # 发送命令
                command_data = DeviceCommandBuilder.build_command(
                    command=command,
                    device_id=device_id,
                    data=data or {},
                    user_id=user_id
                )
                
                success = mqtt.send_command(device_id, command, command_data)
                
                if success:
                    success_count += 1
                    await device_service.log_device_command(
                        device_id=device.id,
                        command=command,
                        data=command_data,
                        user_id=user_id
                    )
                else:
                    failed_devices.append({"device_id": device_id, "reason": "通信失败"})
                    
            except Exception as e:
                failed_devices.append({"device_id": device_id, "reason": str(e)})
        
        return {
            "code": 200,
            "message": "批量控制完成",
            "data": {
                "total": len(device_ids),
                "success": success_count,
                "failed": len(failed_devices),
                "failed_devices": failed_devices
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
