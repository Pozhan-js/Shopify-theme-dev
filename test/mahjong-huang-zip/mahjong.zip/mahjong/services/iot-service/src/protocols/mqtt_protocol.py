"""
IoT设备MQTT通信协议实现
支持设备控制、状态上报、心跳检测
"""
import json
import asyncio
from datetime import datetime
from typing import Dict, Any, Optional
import paho.mqtt.client as mqtt
from sqlalchemy.ext.asyncio import AsyncSession
from ..models.device import Device, DeviceStatus, DeviceLog
from ..services.device_service import DeviceService

class MQTTProtocol:
    """MQTT协议处理器"""
    
    def __init__(self, broker_host: str, broker_port: int = 1883):
        self.broker_host = broker_host
        self.broker_port = broker_port
        self.client = mqtt.Client()
        self.device_service = None
        
    def setup_callbacks(self):
        """设置MQTT回调函数"""
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.on_disconnect = self.on_disconnect
        
    def on_connect(self, client, userdata, flags, rc):
        """连接成功回调"""
        print(f"Connected to MQTT broker with result code {rc}")
        
        # 订阅设备相关主题
        topics = [
            "devices/+/status",
            "devices/+/heartbeat",
            "devices/+/response"
        ]
        
        for topic in topics:
            client.subscribe(topic)
            print(f"Subscribed to: {topic}")
    
    def on_message(self, client, userdata, msg):
        """消息接收回调"""
        try:
            topic_parts = msg.topic.split('/')
            if len(topic_parts) >= 3:
                device_id = topic_parts[1]
                message_type = topic_parts[2]
                
                payload = json.loads(msg.payload.decode())
                asyncio.create_task(
                    self.handle_message(device_id, message_type, payload)
                )
                
        except Exception as e:
            print(f"Error processing message: {e}")
    
    def on_disconnect(self, client, userdata, rc):
        """断开连接回调"""
        print(f"Disconnected from MQTT broker with result code {rc}")
    
    async def handle_message(self, device_id: str, message_type: str, payload: Dict[str, Any]):
        """处理接收到的消息"""
        if message_type == "status":
            await self.handle_status_message(device_id, payload)
        elif message_type == "heartbeat":
            await self.handle_heartbeat_message(device_id, payload)
        elif message_type == "response":
            await self.handle_response_message(device_id, payload)
    
    async def handle_status_message(self, device_id: str, payload: Dict[str, Any]):
        """处理状态上报消息"""
        try:
            # 验证消息格式
            required_fields = ["status", "timestamp"]
            if not all(field in payload for field in required_fields):
                print(f"Invalid status message format from {device_id}")
                return
            
            # 更新设备状态
            device_data = {
                "status": payload["status"],
                "last_online": datetime.fromtimestamp(payload["timestamp"]),
                "door_status": payload.get("door_status"),
                "light_status": payload.get("light_status"),
                "temperature": payload.get("temperature"),
                "humidity": payload.get("humidity"),
                "battery_level": payload.get("battery_level")
            }
            
            # 记录设备日志
            log_data = {
                "device_id": device_id,
                "log_type": "status",
                "message": json.dumps(payload),
                "created_at": datetime.now()
            }
            
            # 这里应该调用DeviceService更新数据库
            print(f"Updated device {device_id} status: {device_data}")
            
        except Exception as e:
            print(f"Error handling status message: {e}")
    
    async def handle_heartbeat_message(self, device_id: str, payload: Dict[str, Any]):
        """处理心跳消息"""
        try:
            timestamp = payload.get("timestamp", datetime.now().timestamp())
            
            # 更新设备最后在线时间
            heartbeat_data = {
                "device_id": device_id,
                "last_online": datetime.fromtimestamp(timestamp),
                "status": "online"
            }
            
            print(f"Received heartbeat from {device_id}")
            
        except Exception as e:
            print(f"Error handling heartbeat: {e}")
    
    async def handle_response_message(self, device_id: str, payload: Dict[str, Any]):
        """处理设备响应消息"""
        try:
            command_id = payload.get("command_id")
            status = payload.get("status")
            result = payload.get("result", {})
            
            # 记录命令执行结果
            log_data = {
                "device_id": device_id,
                "command_id": command_id,
                "status": status,
                "result": json.dumps(result),
                "created_at": datetime.now()
            }
            
            print(f"Command {command_id} executed with status: {status}")
            
        except Exception as e:
            print(f"Error handling response message: {e}")
    
    def send_command(self, device_id: str, command: str, data: Dict[str, Any]) -> bool:
        """发送控制命令到设备"""
        try:
            topic = f"devices/{device_id}/command"
            
            message = {
                "command": command,
                "device_id": device_id,
                "timestamp": int(datetime.now().timestamp()),
                "data": data
            }
            
            payload = json.dumps(message)
            result = self.client.publish(topic, payload, qos=1)
            
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                print(f"Command sent to {device_id}: {command}")
                return True
            else:
                print(f"Failed to send command to {device_id}")
                return False
                
        except Exception as e:
            print(f"Error sending command: {e}")
            return False
    
    def start(self):
        """启动MQTT客户端"""
        self.setup_callbacks()
        self.client.connect(self.broker_host, self.broker_port, 60)
        self.client.loop_start()
    
    def stop(self):
        """停止MQTT客户端"""
        self.client.loop_stop()
        self.client.disconnect()

class DeviceCommandBuilder:
    """设备命令构建器"""
    
    @staticmethod
    def open_door(device_id: str, order_id: str, user_id: str, duration: int = 300) -> Dict[str, Any]:
        """构建开门命令"""
        return {
            "command": "open_door",
            "device_id": device_id,
            "timestamp": int(datetime.now().timestamp()),
            "order_id": order_id,
            "user_id": user_id,
            "duration": duration
        }
    
    @staticmethod
    def turn_on_light(device_id: str, brightness: int = 100) -> Dict[str, Any]:
        """构建开灯命令"""
        return {
            "command": "turn_on_light",
            "device_id": device_id,
            "timestamp": int(datetime.now().timestamp()),
            "brightness": brightness
        }
    
    @staticmethod
    def turn_off_light(device_id: str) -> Dict[str, Any]:
        """构建关灯命令"""
        return {
            "command": "turn_off_light",
            "device_id": device_id,
            "timestamp": int(datetime.now().timestamp())
        }
    
    @staticmethod
    def set_temperature(device_id: str, temperature: float) -> Dict[str, Any]:
        """构建温度设置命令"""
        return {
            "command": "set_temperature",
            "device_id": device_id,
            "timestamp": int(datetime.now().timestamp()),
            "temperature": temperature
        }
    
    @staticmethod
    def get_status(device_id: str) -> Dict[str, Any]:
        """构建状态查询命令"""
        return {
            "command": "get_status",
            "device_id": device_id,
            "timestamp": int(datetime.now().timestamp())
        }

class MessageValidator:
    """消息格式验证器"""
    
    @staticmethod
    def validate_status_message(payload: Dict[str, Any]) -> bool:
        """验证状态消息格式"""
        required_fields = ["device_id", "status", "timestamp"]
        return all(field in payload for field in required_fields)
    
    @staticmethod
    def validate_command_message(payload: Dict[str, Any]) -> bool:
        """验证命令消息格式"""
        required_fields = ["command", "device_id", "timestamp"]
        return all(field in payload for field in required_fields)
    
    @staticmethod
    def validate_heartbeat_message(payload: Dict[str, Any]) -> bool:
        """验证心跳消息格式"""
        required_fields = ["device_id", "timestamp"]
        return all(field in payload for field in required_fields)
