# 无人系统API文档

## 🎯 API概览

### 基础信息
- **Base URL**: `https://api.unmanned-system.com/v1`
- **认证方式**: JWT Bearer Token
- **数据格式**: JSON
- **响应格式**: 统一JSON格式

### 统一响应格式
```json
{
  "code": 200,
  "message": "success",
  "data": {},
  "timestamp": 1635760800,
  "request_id": "uuid"
}
```

## 🔐 认证接口

### 1. 微信小程序登录
```http
POST /api/v1/auth/wx-login
Content-Type: application/json

{
  "code": "微信登录code"
}
```

**响应示例**:
```json
{
  "code": 200,
  "message": "登录成功",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user_info": {
      "id": 1,
      "username": "user123",
      "phone": "13800138000",
      "real_name": "张三",
      "avatar_url": "https://example.com/avatar.jpg",
      "user_type": "customer",
      "balance": 100.00
    }
  }
}
```

### 2. Web后台登录
```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "password123",
  "captcha": "1234"
}
```

**响应示例**:
```json
{
  "code": 200,
  "message": "登录成功",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user_info": {
      "id": 1,
      "username": "admin",
      "real_name": "管理员",
      "user_type": "admin",
      "permissions": ["*"]
    }
  }
}
```

### 3. 刷新令牌
```http
POST /api/v1/auth/refresh
Content-Type: application/json

{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**响应示例**:
```json
{
  "code": 200,
  "message": "令牌刷新成功",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### 4. 退出登录
```http
POST /api/v1/auth/logout
Authorization: Bearer <token>
```

**响应示例**:
```json
{
  "code": 200,
  "message": "退出成功"
}
```

### 5. 获取用户信息
```http
GET /api/v1/auth/profile
Authorization: Bearer <token>
```

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "username": "user123",
    "phone": "13800138000",
    "email": "user@example.com",
    "real_name": "张三",
    "avatar_url": "https://example.com/avatar.jpg",
    "user_type": "customer",
    "balance": 100.00,
    "points": 50,
    "created_at": "2023-01-01T00:00:00Z"
  }
}
```

## 👤 用户接口

### 1. 获取用户信息
```http
GET /api/v1/users/profile
Authorization: Bearer <token>
```

### 2. 更新用户信息
```http
PUT /api/v1/users/profile
Authorization: Bearer <token>
Content-Type: application/json

{
  "real_name": "张三",
  "email": "new@example.com",
  "avatar_url": "https://new-avatar.com"
}
```

### 3. 查询余额
```http
GET /api/v1/users/balance
Authorization: Bearer <token>
```

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "balance": 100.00,
    "frozen_amount": 0.00,
    "total_recharge": 500.00,
    "total_consumption": 400.00
  }
}
```

### 4. 余额充值
```http
POST /api/v1/users/recharge
Authorization: Bearer <token>
Content-Type: application/json

{
  "amount": 100.00,
  "payment_method": "wechat"
}
```

## 🏪 门店接口

### 1. 获取门店列表
```http
GET /api/v1/stores?page=1&limit=10&city=北京
```

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "stores": [
      {
        "id": 1,
        "name": "中关村店",
        "address": "北京市海淀区中关村大街1号",
        "phone": "010-12345678",
        "status": "active",
        "business_hours": {
          "weekday": {"open": "09:00", "close": "22:00"},
          "weekend": {"open": "09:00", "close": "24:00"}
        }
      }
    ],
    "total": 50,
    "page": 1,
    "limit": 10
  }
}
```

### 2. 获取门店详情
```http
GET /api/v1/stores/{store_id}
```

### 3. 获取房间列表
```http
GET /api/v1/stores/{store_id}/rooms?date=2023-12-01&start_time=14:00&end_time=16:00
```

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "rooms": [
      {
        "id": 1,
        "name": "麻将房A",
        "type": "mahjong",
        "capacity": 4,
        "price_per_hour": 50.00,
        "status": "available",
        "features": {
          "has_wifi": true,
          "has_ac": true,
          "has_tv": false
        }
      }
    ]
  }
}
```

### 4. 获取房间详情
```http
GET /api/v1/rooms/{room_id}
```

## 📋 订单接口

### 1. 创建订单
```http
POST /api/v1/orders
Authorization: Bearer <token>
Content-Type: application/json

{
  "store_id": 1,
  "room_id": 1,
  "start_time": "2023-12-01T14:00:00Z",
  "end_time": "2023-12-01T16:00:00Z",
  "payment_method": "wechat",
  "notes": "需要安静的环境"
}
```

**响应示例**:
```json
{
  "code": 200,
  "message": "订单创建成功",
  "data": {
    "order": {
      "id": 1,
      "order_no": "202312011400001",
      "store_name": "中关村店",
      "room_name": "麻将房A",
      "start_time": "2023-12-01T14:00:00Z",
      "end_time": "2023-12-01T16:00:00Z",
      "duration_hours": 2,
      "total_amount": 100.00,
      "status": "pending"
    }
  }
}
```

### 2. 获取订单列表
```http
GET /api/v1/orders?status=pending&page=1&limit=10
Authorization: Bearer <token>
```

### 3. 获取订单详情
```http
GET /api/v1/orders/{order_id}
Authorization: Bearer <token>
```

### 4. 订单续费
```http
POST /api/v1/orders/{order_id}/renew
Authorization: Bearer <token>
Content-Type: application/json

{
  "extend_hours": 1
}
```

### 5. 取消订单
```http
POST /api/v1/orders/{order_id}/cancel
Authorization: Bearer <token>
```

### 6. 开门操作
```http
POST /api/v1/orders/{order_id}/open-door
Authorization: Bearer <token>
```

## 💳 支付接口

### 1. 微信支付
```http
POST /api/v1/payments/wechat
Authorization: Bearer <token>
Content-Type: application/json

{
  "order_id": 1,
  "amount": 100.00
}
```

### 2. 余额支付
```http
POST /api/v1/payments/balance
Authorization: Bearer <token>
Content-Type: application/json

{
  "order_id": 1,
  "amount": 100.00,
  "password": "支付密码"
}
```

### 3. 团购支付
```http
POST /api/v1/payments/groupon
Authorization: Bearer <token>
Content-Type: application/json

{
  "order_id": 1,
  "groupon_code": "MT1234567890"
}
```

### 4. 退款申请
```http
POST /api/v1/payments/refund
Authorization: Bearer <token>
Content-Type: application/json

{
  "order_id": 1,
  "refund_amount": 50.00,
  "reason": "提前结束使用"
}
```

## 🔧 管理员接口

### 1. 数据统计
```http
GET /api/v1/admin/stats
Authorization: Bearer <token>
```

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "today_orders": 25,
    "today_revenue": 2500.00,
    "total_users": 1000,
    "active_rooms": 15,
    "occupancy_rate": 0.75
  }
}
```

### 2. 订单管理
```http
GET /api/v1/admin/orders?store_id=1&status=all&page=1&limit=20
Authorization: Bearer <token>
```

### 3. 修改订单
```http
POST /api/v1/admin/orders/{order_id}/modify
Authorization: Bearer <token>
Content-Type: application/json

{
  "end_time": "2023-12-01T17:00:00Z",
  "notes": "管理员调整"
}
```

### 4. 设备管理
```http
GET /api/v1/admin/devices?store_id=1
Authorization: Bearer <token>
```

### 5. 设备控制
```http
POST /api/v1/admin/devices/{device_id}/control
Authorization: Bearer <token>
Content-Type: application/json

{
  "action": "unlock",
  "data": {
    "duration": 300
  }
}
```

## 🚨 错误码说明

| 错误码 | 说明 |
|--------|------|
| 200 | 成功 |
| 400 | 请求参数错误 |
| 401 | 未授权 |
| 403 | 权限不足 |
| 404 | 资源不存在 |
| 409 | 业务冲突 |
| 422 | 参数验证失败 |
| 429 | 请求过于频繁 |
| 500 | 服务器内部错误 |

## 📱 微信小程序专用接口

### 1. 获取小程序码
```http
GET /api/v1/wx/qrcode?scene=store_id=1&page=pages/store/detail
Authorization: Bearer <token>
```

### 2. 订阅消息
```http
POST /api/v1/wx/subscribe-message
Authorization: Bearer <token>
Content-Type: application/json

{
  "template_id": "order_start_template",
  "data": {
    "thing1": {"value": "麻将房A"},
    "time2": {"value": "14:00"}
  }
}
```

## 🔍 分页参数

所有列表接口支持以下分页参数：
- `page`: 页码，默认1
- `limit`: 每页数量，默认10，最大100
- `sort`: 排序字段，如created_at
- `order`: 排序方式，asc或desc

## 🛡️ 权限说明

| 接口路径 | 所需权限 | 说明 |
|----------|----------|------|
| /api/v1/auth/* | 无 | 公开接口 |
| /api/v1/users/* | 已登录用户 | 用户个人信息 |
| /api/v1/stores/* | 公开/已登录 | 门店信息查询 |
| /api/v1/orders/* | 已登录用户 | 订单相关操作 |
| /api/v1/admin/* | 管理员权限 | 后台管理功能 |

## 📊 接口测试

### 测试环境
- **Base URL**: http://localhost:8001/api/v1
- **文档地址**: http://localhost:8001/api/v1/docs

### 测试账号
- **管理员**: admin / admin123
- **普通用户**: user123 / user123
- **微信小程序**: 使用微信code测试
