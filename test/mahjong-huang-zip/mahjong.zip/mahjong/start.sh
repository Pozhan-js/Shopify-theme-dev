#!/bin/bash

# 无人系统后端启动脚本

set -e

echo "🚀 启动无人系统后端服务..."

# 检查Docker是否安装
if ! command -v docker &> /dev/null; then
    echo "❌ Docker未安装，请先安装Docker"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose未安装，请先安装Docker Compose"
    exit 1
fi

# 创建环境文件（如果不存在）
if [ ! -f .env ]; then
    echo "📝 创建环境配置文件..."
    cp .env.example .env
    echo "⚠️  请编辑.env文件配置您的环境变量"
fi

# 创建必要的目录
mkdir -p infrastructure/docker/mysql/init
mkdir -p infrastructure/docker/nginx/conf.d
mkdir -p infrastructure/docker/nginx/ssl
mkdir -p infrastructure/docker/prometheus
mkdir -p infrastructure/docker/mqtt

# 启动基础设施服务
echo "🏗️  启动基础设施服务..."
cd infrastructure/docker

# 启动MySQL、Redis、RabbitMQ等基础服务
docker-compose up -d mysql redis rabbitmq mqtt

# 等待数据库启动
echo "⏳ 等待数据库启动..."
sleep 30

# 启动微服务
echo "🔧 启动微服务..."
docker-compose up -d user-service store-service order-service payment-service iot-service groupbuy-service analytics-service

# 启动反向代理和监控
echo "🌐 启动反向代理和监控..."
docker-compose up -d nginx prometheus grafana

echo "✅ 所有服务启动完成！"
echo ""
echo "📋 服务访问地址："
echo "  - 用户服务: http://localhost:8001/api/v1/docs"
echo "  - 门店服务: http://localhost:8002/api/v1/docs"
echo "  - 订单服务: http://localhost:8003/api/v1/docs"
echo "  - 支付服务: http://localhost:8004/api/v1/docs"
echo "  - 物联网服务: http://localhost:8005/api/v1/docs"
echo "  - 团购服务: http://localhost:8006/api/v1/docs"
echo "  - 数据统计服务: http://localhost:8007/api/v1/docs"
echo ""
echo "🔍 监控面板："
echo "  - API文档汇总: http://localhost/api/v1/docs"
echo "  - RabbitMQ管理: http://localhost:15672 (admin/admin)"
echo "  - Prometheus: http://localhost:9090"
echo "  - Grafana: http://localhost:3000 (admin/admin)"
echo ""
echo "🛑 停止所有服务: docker-compose -f infrastructure/docker/docker-compose.yml down"
