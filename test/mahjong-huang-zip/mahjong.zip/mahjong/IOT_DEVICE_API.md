# IoT设备通信API文档

## 🏗️ 通信架构

### 协议选择
- **MQTT** - 主要通信协议，适合物联网场景
- **WebSocket** - 实时控制通信
- **HTTP REST** - 设备状态上报和配置

### 消息格式
所有消息使用JSON格式，包含以下标准字段：
```json
{
  "device_id": "device_001",
  "timestamp": 1640995200,
  "message_type": "command|status|heartbeat",
  "data": {...}
}
```

## 📡 MQTT主题设计

### 主题结构
```
devices/{device_id}/{message_type}
```

### 具体主题
- `devices/{device_id}/command` - 控制指令下发
- `devices/{device_id}/status` - 状态上报
- `devices/{device_id}/heartbeat` - 心跳检测
- `devices/{device_id}/response` - 命令响应
- `devices/{device_id}/alert` - 异常告警

## 🔐 设备认证

### 设备注册
```http
POST /api/v1/devices/register
Content-Type: application/json

{
  "device_code": "door_001",
  "device_name": "前门控制器",
  "device_type": "door_lock",
  "store_id": 1,
  "location": "前门",
  "description": "智能门锁控制器"
}
```

### 设备令牌
设备注册后获得长期有效的设备令牌：
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

## 🎮 设备控制API

### 1. 开门控制
```http
POST /api/v1/devices/{device_id}/control
Authorization: Bearer {token}
Content-Type: application/json

{
  "command": "open_door",
  "data": {
    "order_id": "order_123",
    "user_id": "user_456",
    "duration": 300
  }
}
```

**MQTT消息示例：**
```json
{
  "command": "open_door",
  "device_id": "door_001",
  "timestamp": 1640995200,
  "order_id": "order_123",
  "user_id": "user_456",
  "duration": 300
}
```

### 2. 灯光控制
```http
POST /api/v1/devices/{device_id}/control
Authorization: Bearer {token}
Content-Type: application/json

{
  "command": "set_light",
  "data": {
    "brightness": 80,
    "color": "warm_white"
  }
}
```

### 3. 温度控制
```http
POST /api/v1/devices/{device_id}/control
Authorization: Bearer {token}
Content-Type: application/json

{
  "command": "set_temperature",
  "data": {
    "temperature": 25.5,
    "mode": "auto"
  }
}
```

### 4. 批量控制
```http
POST /api/v1/devices/batch/control
Authorization: Bearer {token}
Content-Type: application/json

{
  "device_ids": ["door_001", "light_001", "ac_001"],
  "command": "turn_on",
  "data": {
    "brightness": 100,
    "temperature": 24
  }
}
```

## 📊 状态上报

### 设备状态格式
```json
{
  "device_id": "door_001",
  "status": "online",
  "door_status": "closed",
  "lock_status": "locked",
  "battery_level": 85,
  "signal_strength": -45,
  "temperature": 25.5,
  "humidity": 60,
  "timestamp": 1640995200
}
```

### 心跳消息
```json
{
  "device_id": "door_001",
  "heartbeat": true,
  "timestamp": 1640995200,
  "uptime": 3600
}
```

### 异常告警
```json
{
  "device_id": "door_001",
  "alert_type": "low_battery",
  "severity": "warning",
  "message": "电池电量低于20%",
  "timestamp": 1640995200
}
```

## 🔍 设备管理API

### 获取设备状态
```http
GET /api/v1/devices/{device_id}/status
Authorization: Bearer {token}
```

**响应示例：**
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "device_id": "door_001",
    "device_name": "前门控制器",
    "status": "online",
    "door_status": "closed",
    "light_status": "on",
    "temperature": 25.5,
    "battery_level": 85,
    "last_online": "2023-12-01T14:00:00Z"
  }
}
```

### 获取在线设备
```http
GET /api/v1/devices/online?store_id=1
Authorization: Bearer {token}
```

### 获取设备日志
```http
GET /api/v1/devices/{device_id}/logs?log_type=status&page=1&limit=20
Authorization: Bearer {token}
```

## 🚨 异常处理

### 设备离线
- 心跳超时：超过5分钟未收到心跳
- 自动重连：设备尝试重新连接MQTT
- 告警通知：管理员收到设备离线通知

### 命令失败
- 超时处理：命令30秒内无响应
- 重试机制：最多重试3次
- 错误日志：记录失败原因

## 📱 微信小程序集成

### 扫码开门
```javascript
// 小程序端代码
wx.scanCode({
  success: (res) => {
    const deviceId = res.result;
    wx.request({
      url: '/api/v1/devices/' + deviceId + '/control',
      method: 'POST',
      data: {
        command: 'open_door',
        data: {
          order_id: getCurrentOrderId()
        }
      }
    });
  }
});
```

### 实时状态
```javascript
// WebSocket连接
wx.connectSocket({
  url: 'wss://api.unmanned-system.com/ws/devices'
});

wx.onSocketMessage((res) => {
  const data = JSON.parse(res.data);
  updateDeviceStatus(data);
});
```

## 🔐 安全机制

### 1. 设备认证
- 设备令牌：长期有效的JWT令牌
- 双向认证：设备和服务器双向验证
- 令牌刷新：定期更新设备令牌

### 2. 通信加密
- MQTT TLS：所有MQTT通信使用TLS加密
- 数据签名：重要数据使用HMAC签名
- 防重放：时间戳和nonce防止重放攻击

### 3. 权限控制
- 设备权限：按门店分配设备控制权限
- 操作日志：记录所有设备操作
- 异常检测：监控异常操作模式

## 📊 监控指标

### 设备健康
- 在线率：设备在线时间占比
- 响应时间：命令响应平均时间
- 错误率：命令执行失败率

### 网络质量
- 信号强度：WiFi/4G信号质量
- 延迟：MQTT消息往返延迟
- 丢包率：网络通信丢包情况

## 🛠️ 开发工具

### 设备模拟器
```python
# 设备模拟器示例
import paho.mqtt.client as mqtt
import json

client = mqtt.Client()
client.connect("localhost", 1883)

# 模拟设备状态上报
status_data = {
    "device_id": "door_001",
    "status": "online",
    "door_status": "closed",
    "timestamp": 1640995200
}

client.publish("devices/door_001/status", json.dumps(status_data))
```

### 调试接口
```http
GET /api/v1/devices/debug/{device_id}
Authorization: Bearer {admin_token}
```

## 🎯 使用场景

### 1. 用户扫码开门
1. 用户扫描房间二维码
2. 系统验证订单有效性
3. 发送开门命令到设备
4. 设备执行开门操作
5. 记录开门日志

### 2. 管理员远程控制
1. 管理员登录后台
2. 选择需要控制的设备
3. 发送控制命令
4. 查看执行结果
5. 记录操作日志

### 3. 自动化场景
1. 订单开始前5分钟自动开灯
2. 订单结束后自动关灯
3. 检测到无人时自动锁门
4. 温度异常时自动调节

## 📞 技术支持

### 设备接入
- **文档地址**: http://localhost:8080/docs#/devices
- **测试工具**: MQTT.fx 或 mosquitto_pub/sub
- **SDK下载**: 提供Python/JavaScript SDK

### 故障排查
- **日志查看**: `docker-compose logs iot-service`
- **设备诊断**: `/api/v1/devices/{device_id}/diagnose`
- **在线支持**: 技术支持QQ群

**IoT设备通信系统已完整实现，支持MQTT协议、实时控制和状态监控！**
