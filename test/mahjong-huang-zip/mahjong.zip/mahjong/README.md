# 无人系统后端架构

基于Python的无人麻将馆/茶室系统后端，采用微服务架构设计。

## 🏗️ 架构概览

- **微服务架构**: 7个核心微服务
- **技术栈**: FastAPI + SQLAlchemy + Redis + RabbitMQ
- **部署**: Docker + Docker Compose
- **监控**: Prometheus + Grafana
- **认证**: JWT + RBAC权限控制

## 📋 服务列表

| 服务名称 | 端口 | 描述 |
|---------|------|------|
| 用户服务 | 8001 | 用户注册、登录、权限管理 |
| 门店服务 | 8002 | 门店管理、房间配置 |
| 订单服务 | 8003 | 预约、订单管理 |
| 支付服务 | 8004 | 微信支付、余额支付 |
| 物联网服务 | 8005 | 设备控制、门锁管理 |
| 团购服务 | 8006 | 美团/抖音团购验券 |
| 数据统计服务 | 8007 | 报表生成、数据分析 |

## 🚀 快速开始

### 1. 环境要求

- Docker & Docker Compose
- Python 3.11+ (开发环境)
- MySQL 8.0+
- Redis 7.0+

### 2. 启动服务

```bash
# 一键启动所有服务
./start.sh

# 或者手动启动
cd infrastructure/docker
docker-compose up -d
```

### 3. 访问服务

- **API文档**: http://localhost/api/v1/docs
- **用户服务**: http://localhost:8001/api/v1/docs
- **RabbitMQ管理**: http://localhost:15672 (admin/admin)
- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3000 (admin/admin)

## 📁 项目结构

```
unmanned-system/
├── services/                 # 微服务目录
│   ├── user-service/        # 用户服务
│   ├── store-service/       # 门店服务
│   ├── order-service/       # 订单服务
│   ├── payment-service/     # 支付服务
│   ├── iot-service/         # 物联网服务
│   ├── groupbuy-service/    # 团购服务
│   └── analytics-service/   # 数据统计服务
├── shared/                  # 共享库
│   ├── common/             # 公共配置和工具
│   ├── auth/               # 认证授权
│   └── proto/              # 协议定义
├── infrastructure/         # 基础设施配置
│   ├── docker/            # Docker配置
│   ├── k8s/               # Kubernetes配置
│   └── monitoring/        # 监控配置
├── docs/                  # 项目文档
├── start.sh              # 启动脚本
└── README.md             # 项目说明
```

## 🔧 开发指南

### 1. 环境配置

```bash
# 复制环境配置
cp .env.example .env

# 编辑配置文件
vim .env
```

### 2. 本地开发

```bash
# 安装依赖
pip install -r shared/common/requirements.txt

# 启动用户服务（示例）
cd services/user-service
uvicorn main:app --reload --port 8001
```

### 3. 数据库迁移

```bash
# 创建迁移
alembic revision --autogenerate -m "Initial migration"

# 执行迁移
alembic upgrade head
```

## 🔐 API认证

所有API使用JWT Bearer Token认证：

```bash
# 获取Token
curl -X POST http://localhost/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"test","password":"123456"}'

# 使用Token访问API
curl -X GET http://localhost/api/v1/users/me \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 📊 权限分级

| 角色 | 权限描述 |
|------|----------|
| 超级管理员 | 系统所有权限 |
| 门店管理员 | 管理单个门店的所有操作 |
| 保洁员 | 查看清洁任务、更新房间状态 |
| 普通用户 | 预约、支付、查看个人订单 |

## 🐳 Docker部署

```bash
# 构建镜像
docker-compose build

# 启动服务
docker-compose up -d

# 查看日志
docker-compose logs -f user-service

# 停止服务
docker-compose down
```

## 📈 监控指标

- **应用指标**: Prometheus收集
- **系统指标**: 容器资源使用
- **业务指标**: 订单量、用户数等
- **告警规则**: 基于Grafana配置

## 🚨 故障排查

### 常见问题

1. **数据库连接失败**
   - 检查MySQL服务状态
   - 确认数据库配置正确

2. **Redis连接失败**
   - 检查Redis服务状态
   - 确认Redis配置正确

3. **服务启动失败**
   - 查看服务日志: `docker-compose logs [service-name]`
   - 检查端口占用情况

### 日志查看

```bash
# 查看所有服务日志
docker-compose logs -f

# 查看特定服务日志
docker-compose logs -f user-service

# 进入容器调试
docker-compose exec user-service bash
```

## 🤝 贡献指南

1. Fork项目
2. 创建功能分支
3. 提交代码
4. 创建Pull Request

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 📞 联系方式

- 项目维护: 无人系统团队
- 技术支持: support@unmanned-system.com
