# 无人自助系统后端部署指南

## 系统架构

本系统采用微服务架构，包含以下核心组件：

- **API服务**: FastAPI + SQLAlchemy
- **数据库**: PostgreSQL 14
- **缓存**: Redis
- **消息队列**: RabbitMQ
- **任务调度**: Celery
- **监控**: Prometheus + Grafana
- **反向代理**: Nginx

## 环境要求

- Docker 20.10+
- Docker Compose 2.0+
- Python 3.9+ (开发环境)

## 快速部署

### 1. 克隆项目

```bash
git clone <repository-url>
cd backend
```

### 2. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env 文件，配置必要的环境变量
```

### 3. 启动服务

```bash
# 一键启动所有服务
./scripts/dev_start.sh

# 或者手动启动
docker-compose up -d
```

### 4. 验证部署

访问以下地址验证服务是否正常：

- API文档: http://localhost/docs
- 管理后台: http://localhost/admin
- 监控面板: http://localhost/grafana
- Prometheus: http://localhost:9090

## 环境变量配置

### 数据库配置

```bash
# PostgreSQL
POSTGRES_HOST=postgres
POSTGRES_PORT=5432
POSTGRES_DB=unmanned_system
POSTGRES_USER=unmanned_user
POSTGRES_PASSWORD=your_secure_password

# Redis
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=your_redis_password
```

### 微信配置

```bash
WECHAT_APP_ID=your_wechat_app_id
WECHAT_SECRET=your_wechat_secret
WECHAT_MCH_ID=your_merchant_id
WECHAT_MCH_KEY=your_merchant_key
```

### 支付配置

```bash
ALIPAY_APP_ID=your_alipay_app_id
ALIPAY_PRIVATE_KEY=your_alipay_private_key
ALIPAY_PUBLIC_KEY=your_alipay_public_key
```

### 人脸识别配置

```bash
FACE_API_KEY=your_face_api_key
FACE_SECRET_KEY=your_face_secret_key
```

## 服务管理

### 启动服务

```bash
# 启动所有服务
docker-compose up -d

# 启动特定服务
docker-compose up -d postgres redis app
```

### 停止服务

```bash
# 停止所有服务
docker-compose down

# 停止特定服务
docker-compose stop app
```

### 查看日志

```bash
# 查看所有服务日志
docker-compose logs -f

# 查看特定服务日志
docker-compose logs -f app
```

### 重启服务

```bash
# 重启所有服务
docker-compose restart

# 重启特定服务
docker-compose restart app
```

## 数据库管理

### 初始化数据库

```bash
# 运行数据库迁移
alembic upgrade head

# 初始化基础数据
python scripts/init_db.py
```

### 创建新的迁移

```bash
alembic revision --autogenerate -m "描述变更"
```

### 回滚迁移

```bash
alembic downgrade -1
```

## 监控和日志

### 查看系统指标

- 访问 http://localhost/grafana 查看系统监控面板
- 默认用户名/密码: admin/admin

### 查看应用日志

```bash
# 实时查看应用日志
docker-compose logs -f app

# 查看特定时间段的日志
docker-compose logs --since 1h app
```

## 备份和恢复

### 数据库备份

```bash
# 创建数据库备份
docker-compose exec postgres pg_dump -U unmanned_user unmanned_system > backup_$(date +%Y%m%d_%H%M%S).sql

# 恢复数据库
docker-compose exec -T postgres psql -U unmanned_user unmanned_system < backup_file.sql
```

## 性能优化

### 数据库优化

- 确保PostgreSQL配置参数适合工作负载
- 定期运行VACUUM和ANALYZE
- 监控慢查询并优化索引

### 缓存优化

- 配置Redis内存限制
- 设置合理的TTL值
- 监控缓存命中率

### 应用优化

- 启用Gunicorn的worker进程
- 配置连接池大小
- 启用HTTP缓存头

## 故障排除

### 常见问题

1. **服务启动失败**
   - 检查端口是否被占用
   - 检查环境变量配置
   - 查看容器日志

2. **数据库连接失败**
   - 检查数据库服务状态
   - 验证连接字符串
   - 检查防火墙设置

3. **微信登录失败**
   - 检查微信配置参数
   - 验证域名白名单
   - 检查网络连接

### 调试工具

```bash
# 进入容器调试
docker-compose exec app bash

# 查看容器状态
docker-compose ps

# 查看资源使用
docker stats
```

## 安全建议

1. **定期更新**
   - 保持Docker镜像更新
   - 定期更新依赖包

2. **访问控制**
   - 配置防火墙规则
   - 使用HTTPS
   - 限制管理接口访问

3. **数据安全**
   - 定期备份数据
   - 加密敏感数据
   - 监控异常访问

## 扩展部署

### 水平扩展

```bash
# 扩展应用实例
docker-compose up -d --scale app=3

# 配置负载均衡
# 修改nginx配置支持多实例
```

### 高可用部署

- 使用外部数据库集群
- 配置Redis集群
- 使用容器编排平台(Kubernetes)

## 联系支持

如有部署问题，请联系技术支持团队。
