# 无人自助系统后端

基于FastAPI的无人自助系统后端，支持微信小程序对接。

## 功能特性

- ✅ 用户管理（注册、登录、微信登录）
- ✅ 门店管理（多门店支持）
- ✅ 设备管理（智能锁、摄像头等）
- ✅ 订单管理（预约、支付、退款）
- ✅ 商品管理（房间、服务、套餐）
- ✅ 优惠券系统
- ✅ 预约系统
- ✅ 支付集成（微信支付、支付宝）
- ✅ 人脸识别
- ✅ 消息通知
- ✅ 异步任务处理
- ✅ 监控和日志

## 技术栈

- **Web框架**: FastAPI
- **数据库**: PostgreSQL 14 / MySQL 8.0
- **缓存**: Redis
- **消息队列**: Celery + Redis
- **ORM**: SQLAlchemy 2.0
- **认证**: JWT
- **部署**: Docker + Docker Compose
- **监控**: Prometheus + Grafana

## 快速开始

### 1. 环境准备

确保已安装：
- Docker & Docker Compose
- Python 3.11+
- PostgreSQL 14+ 或 MySQL 8.0+

### 2. 克隆项目

```bash
git clone <repository-url>
cd backend
```

### 3. 环境配置

复制环境配置文件：
```bash
cp .env.example .env
```

编辑 `.env` 文件，配置数据库、Redis、微信等参数。

### 4. Docker启动

```bash
# 启动所有服务
docker-compose up -d

# 查看日志
docker-compose logs -f
```

### 5. 本地开发

#### 5.1 创建虚拟环境

```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows
```

#### 5.2 安装依赖

```bash
pip install -r requirements.txt
```

#### 5.3 数据库迁移

```bash
# 初始化Alembic（首次）
alembic init alembic

# 生成迁移文件
alembic revision --autogenerate -m "Initial migration"

# 执行迁移
alembic upgrade head
```

#### 5.4 启动服务

```bash
# 启动API服务
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# 启动Celery Worker
celery -A app.tasks.celery_app worker --loglevel=info

# 启动Celery Beat
celery -A app.tasks.celery_app beat --loglevel=info
```

## API文档

启动服务后，访问：
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## 项目结构

```
backend/
├── app/
│   ├── api/              # API路由
│   │   └── v1/
│   │       └── endpoints/
│   ├── core/             # 核心配置
│   ├── models/           # 数据库模型
│   ├── schemas/          # Pydantic模型
│   ├── services/         # 业务逻辑
│   ├── tasks/            # 异步任务
│   └── utils/            # 工具函数
├── alembic/              # 数据库迁移
├── docker/               # Docker配置
├── tests/                # 测试文件
├── requirements.txt      # 依赖列表
├── Dockerfile           # Docker镜像
└── docker-compose.yml   # Docker编排
```

## 数据库设计

### 核心表结构

- **users**: 用户表
- **user_profiles**: 用户资料表
- **stores**: 门店表
- **store_configs**: 门店配置表
- **devices**: 设备表
- **orders**: 订单表
- **products**: 商品表
- **coupons**: 优惠券表
- **bookings**: 预约表
- **payments**: 支付记录表
- **notifications**: 通知表
- **face_records**: 人脸识别记录表

## 微信小程序对接

### 1. 配置小程序信息

在 `.env` 文件中配置：
```bash
WECHAT_APP_ID=your_wechat_app_id
WECHAT_APP_SECRET=your_wechat_app_secret
WECHAT_MCH_ID=your_merchant_id
WECHAT_MCH_KEY=your_merchant_key
```

### 2. API端点

- 用户注册: `POST /api/v1/auth/register`
- 用户登录: `POST /api/v1/auth/login`
- 微信登录: `POST /api/v1/auth/wechat/login`
- 获取用户信息: `GET /api/v1/auth/me`

## 部署

### 生产环境部署

1. 配置生产环境变量
2. 使用Docker Compose启动
3. 配置Nginx反向代理
4. 配置SSL证书
5. 配置监控告警

### 环境变量说明

| 变量名 | 说明 | 示例 |
|--------|------|------|
| DATABASE_URL | 数据库连接URL | postgresql://user:pass@localhost/db |
| REDIS_URL | Redis连接URL | redis://localhost:6379/0 |
| SECRET_KEY | JWT密钥 | your_secret_key |
| WECHAT_APP_ID | 微信小程序AppID | wx1234567890abcdef |
| WECHAT_APP_SECRET | 微信小程序密钥 | your_app_secret |

## 监控和日志

### 监控指标

- API响应时间
- 数据库查询性能
- Redis缓存命中率
- 系统资源使用率

### 日志配置

日志文件位于 `logs/` 目录：
- `app.log`: 应用日志
- `error.log`: 错误日志
- `access.log`: 访问日志

## 开发规范

### 代码风格

- 使用Black格式化代码
- 使用isort排序导入
- 使用mypy进行类型检查

### 提交规范

- 使用语义化版本号
- 提交信息格式: `type(scope): description`

## 贡献指南

1. Fork项目
2. 创建功能分支
3. 提交更改
4. 发起Pull Request

## 许可证

MIT License
