#!/bin/bash
# 开发环境启动脚本

set -e

echo "🚀 启动无人自助系统后端服务..."

# 检查环境变量文件
if [ ! -f .env ]; then
    echo "⚠️  未找到 .env 文件，使用 .env.example 作为模板"
    cp .env.example .env
    echo "请编辑 .env 文件配置必要的环境变量"
fi

# 检查Docker环境
if ! command -v docker &> /dev/null; then
    echo "❌ Docker 未安装，请先安装 Docker"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose 未安装，请先安装 Docker Compose"
    exit 1
fi

# 启动基础设施服务
echo "📦 启动基础设施服务 (PostgreSQL, Redis, RabbitMQ)..."
docker-compose up -d postgres redis rabbitmq

# 等待服务启动
echo "⏳ 等待数据库启动..."
sleep 10

# 运行数据库迁移
echo "🗄️  运行数据库迁移..."
alembic upgrade head

# 启动应用服务
echo "🎯 启动应用服务..."
docker-compose up -d app celery_worker celery_beat

# 启动监控服务
echo "📊 启动监控服务..."
docker-compose up -d prometheus grafana nginx

echo "✅ 服务启动完成！"
echo ""
echo "📋 服务状态:"
docker-compose ps

echo ""
echo "🔗 访问地址:"
echo "  - API文档: http://localhost/docs"
echo "  - 管理后台: http://localhost/admin"
echo "  - 监控面板: http://localhost/grafana"
echo "  - Prometheus: http://localhost:9090"
echo ""
echo "📖 常用命令:"
echo "  - 查看日志: docker-compose logs -f app"
echo "  - 停止服务: docker-compose down"
echo "  - 重启服务: docker-compose restart"
