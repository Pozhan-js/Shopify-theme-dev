#!/usr/bin/env python3
"""数据库初始化脚本"""
import asyncio
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from app.core.database import async_engine, Base
from app.core.config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def init_db() -> None:
    """初始化数据库"""
    try:
        logger.info("开始初始化数据库...")
        
        # 创建所有表
        async with async_engine.begin() as conn:
            logger.info("创建数据库表...")
            await conn.run_sync(Base.metadata.create_all)
            logger.info("数据库表创建完成")
        
        # 初始化基础数据
        async with AsyncSession(async_engine) as session:
            logger.info("初始化基础数据...")
            
            # 检查是否已存在管理员用户
            from app.models.user import User
            from sqlalchemy import select
            
            result = await session.execute(
                select(User).where(User.role == "admin")
            )
            admin_user = result.scalar_one_or_none()
            
            if not admin_user:
                logger.info("创建管理员用户...")
                # 这里可以添加管理员用户创建逻辑
                
            await session.commit()
            logger.info("基础数据初始化完成")
            
    except Exception as e:
        logger.error(f"数据库初始化失败: {e}")
        raise
    finally:
        await async_engine.dispose()


if __name__ == "__main__":
    asyncio.run(init_db())
