#!/bin/bash
# 启动脚本

set -e

echo "🚀 启动无人自助系统后端..."

# 检查环境变量
if [ ! -f .env ]; then
    echo "❌ 未找到 .env 文件，请复制 .env.example 并配置"
    exit 1
fi

# 加载环境变量
source .env

# 检查Docker是否安装
if ! command -v docker &> /dev/null; then
    echo "❌ Docker 未安装，请先安装 Docker"
    exit 1
fi

# 检查Docker Compose是否安装
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose 未安装，请先安装 Docker Compose"
    exit 1
fi

# 创建必要的目录
mkdir -p logs uploads static

# 设置权限
chmod -R 755 uploads logs

# 启动服务
echo "📦 启动 Docker 容器..."
docker-compose up -d

# 等待服务启动
echo "⏳ 等待服务启动..."
sleep 10

# 检查服务状态
echo "🔍 检查服务状态..."
docker-compose ps

# 显示访问地址
echo ""
echo "✅ 服务启动成功！"
echo ""
echo "📋 访问地址："
echo "  - API文档: http://localhost:8000/docs"
echo "  - ReDoc: http://localhost:8000/redoc"
echo "  - 健康检查: http://localhost:8000/health"
echo ""
echo "📊 监控面板："
echo "  - Prometheus: http://localhost:9090"
echo "  - Grafana: http://localhost:3000 (admin/admin)"
echo ""
echo "🗄️ 数据库："
echo "  - PostgreSQL: localhost:5432"
echo "  - Redis: localhost:6379"
echo ""
echo "📋 常用命令："
echo "  - 查看日志: docker-compose logs -f"
echo "  - 停止服务: docker-compose down"
echo "  - 重启服务: docker-compose restart"
