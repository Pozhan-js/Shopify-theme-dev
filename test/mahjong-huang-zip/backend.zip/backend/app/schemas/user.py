"""用户Pydantic模型"""
from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, Field, EmailStr

from .common import BaseSchema


class UserBase(BaseSchema):
    """用户基础模型"""
    
    username: str = Field(..., min_length=3, max_length=50, description="用户名")
    email: Optional[EmailStr] = Field(default=None, description="邮箱")
    phone: Optional[str] = Field(default=None, regex=r"^1[3-9]\d{9}$", description="手机号")
    
    # 微信信息
    openid: Optional[str] = Field(default=None, description="微信openid")
    unionid: Optional[str] = Field(default=None, description="微信unionid")
    nickname: Optional[str] = Field(default=None, max_length=100, description="微信昵称")
    avatar_url: Optional[str] = Field(default=None, max_length=500, description="头像URL")


class UserCreate(UserBase):
    """创建用户模型"""
    
    password: Optional[str] = Field(default=None, min_length=6, max_length=50, description="密码")
    tenant_id: str = Field(..., description="租户ID")


class UserUpdate(BaseSchema):
    """更新用户模型"""
    
    username: Optional[str] = Field(default=None, min_length=3, max_length=50, description="用户名")
    email: Optional[EmailStr] = Field(default=None, description="邮箱")
    phone: Optional[str] = Field(default=None, regex=r"^1[3-9]\d{9}$", description="手机号")
    nickname: Optional[str] = Field(default=None, max_length=100, description="微信昵称")
    avatar_url: Optional[str] = Field(default=None, max_length=500, description="头像URL")
    is_active: Optional[bool] = Field(default=None, description="是否激活")


class UserInDB(UserBase):
    """用户数据库模型"""
    
    id: int = Field(..., description="用户ID")
    is_active: bool = Field(default=True, description="是否激活")
    is_verified: bool = Field(default=False, description="是否验证")
    is_superuser: bool = Field(default=False, description="是否超级用户")
    tenant_id: str = Field(..., description="租户ID")
    created_at: datetime = Field(..., description="创建时间")
    updated_at: datetime = Field(..., description="更新时间")
    last_login_at: Optional[datetime] = Field(default=None, description="最后登录时间")
    
    class Config:
        from_attributes = True


class UserProfileBase(BaseSchema):
    """用户资料基础模型"""
    
    real_name: Optional[str] = Field(default=None, max_length=50, description="真实姓名")
    id_card: Optional[str] = Field(default=None, regex=r"^\d{17}[\dXx]$", description="身份证号")
    gender: Optional[str] = Field(default=None, description="性别")
    birth_date: Optional[datetime] = Field(default=None, description="出生日期")
    
    # 联系信息
    emergency_contact: Optional[str] = Field(default=None, max_length=50, description="紧急联系人")
    emergency_phone: Optional[str] = Field(default=None, regex=r"^1[3-9]\d{9}$", description="紧急联系电话")
    
    # 地址信息
    province: Optional[str] = Field(default=None, max_length=50, description="省份")
    city: Optional[str] = Field(default=None, max_length=50, description="城市")
    district: Optional[str] = Field(default=None, max_length=50, description="区县")
    address: Optional[str] = Field(default=None, max_length=500, description="详细地址")
    
    # 会员信息
    member_level: int = Field(default=0, ge=0, description="会员等级")
    member_expires_at: Optional[datetime] = Field(default=None, description="会员到期时间")
    
    # 积分信息
    points: int = Field(default=0, ge=0, description="当前积分")
    total_points: int = Field(default=0, ge=0, description="总积分")
    
    # 备注
    remark: Optional[str] = Field(default=None, description="备注")


class UserProfileCreate(UserProfileBase):
    """创建用户资料模型"""
    
    user_id: int = Field(..., description="用户ID")


class UserProfileUpdate(BaseSchema):
    """更新用户资料模型"""
    
    real_name: Optional[str] = Field(default=None, max_length=50, description="真实姓名")
    id_card: Optional[str] = Field(default=None, regex=r"^\d{17}[\dXx]$", description="身份证号")
    gender: Optional[str] = Field(default=None, description="性别")
    birth_date: Optional[datetime] = Field(default=None, description="出生日期")
    emergency_contact: Optional[str] = Field(default=None, max_length=50, description="紧急联系人")
    emergency_phone: Optional[str] = Field(default=None, regex=r"^1[3-9]\d{9}$", description="紧急联系电话")
    province: Optional[str] = Field(default=None, max_length=50, description="省份")
    city: Optional[str] = Field(default=None, max_length=50, description="城市")
    district: Optional[str] = Field(default=None, max_length=50, description="区县")
    address: Optional[str] = Field(default=None, max_length=500, description="详细地址")
    member_level: Optional[int] = Field(default=None, ge=0, description="会员等级")
    member_expires_at: Optional[datetime] = Field(default=None, description="会员到期时间")
    points: Optional[int] = Field(default=None, ge=0, description="当前积分")
    total_points: Optional[int] = Field(default=None, ge=0, description="总积分")
    remark: Optional[str] = Field(default=None, description="备注")


class UserProfileInDB(UserProfileBase):
    """用户资料数据库模型"""
    
    id: int = Field(..., description="资料ID")
    user_id: int = Field(..., description="用户ID")
    created_at: datetime = Field(..., description="创建时间")
    updated_at: datetime = Field(..., description="更新时间")
    
    class Config:
        from_attributes = True


class UserWithProfile(UserInDB):
    """用户完整信息模型"""
    
    profile: Optional[UserProfileInDB] = Field(default=None, description="用户资料")


class UserLogin(BaseSchema):
    """用户登录模型"""
    
    username: Optional[str] = Field(default=None, description="用户名")
    phone: Optional[str] = Field(default=None, description="手机号")
    email: Optional[EmailStr] = Field(default=None, description="邮箱")
    password: str = Field(..., min_length=6, description="密码")
    tenant_id: str = Field(..., description="租户ID")


class UserRegister(BaseSchema):
    """用户注册模型"""
    
    username: str = Field(..., min_length=3, max_length=50, description="用户名")
    phone: Optional[str] = Field(default=None, regex=r"^1[3-9]\d{9}$", description="手机号")
    email: Optional[EmailStr] = Field(default=None, description="邮箱")
    password: str = Field(..., min_length=6, max_length=50, description="密码")
    tenant_id: str = Field(..., description="租户ID")


class WechatLogin(BaseSchema):
    """微信登录模型"""
    
    code: str = Field(..., description="微信登录code")
    tenant_id: str = Field(..., description="租户ID")


class Token(BaseSchema):
    """Token模型"""
    
    access_token: str = Field(..., description="访问令牌")
    refresh_token: str = Field(..., description="刷新令牌")
    token_type: str = Field(default="bearer", description="令牌类型")
    expires_in: int = Field(..., description="过期时间（秒）")


class TokenData(BaseSchema):
    """Token数据模型"""
    
    user_id: Optional[int] = Field(default=None, description="用户ID")
    username: Optional[str] = Field(default=None, description="用户名")
    tenant_id: Optional[str] = Field(default=None, description="租户ID")
