"""通用Pydantic模型"""
from typing import Any, Dict, Generic, List, Optional, TypeVar
from datetime import datetime

from pydantic import BaseModel, Field


class BaseSchema(BaseModel):
    """基础模型"""
    
    class Config:
        from_attributes = True
        use_enum_values = True


class PaginationParams(BaseSchema):
    """分页参数"""
    
    page: int = Field(default=1, ge=1, description="页码")
    page_size: int = Field(default=10, ge=1, le=100, description="每页数量")
    sort_by: Optional[str] = Field(default=None, description="排序字段")
    sort_order: str = Field(default="desc", regex="^(asc|desc)$", description="排序方式")


class PaginationResponse(BaseSchema):
    """分页响应"""
    
    items: List[Any] = Field(default_factory=list, description="数据列表")
    total: int = Field(default=0, description="总数量")
    page: int = Field(default=1, description="当前页码")
    page_size: int = Field(default=10, description="每页数量")
    pages: int = Field(default=0, description="总页数")


class DateRangeParams(BaseSchema):
    """日期范围参数"""
    
    start_date: Optional[datetime] = Field(default=None, description="开始日期")
    end_date: Optional[datetime] = Field(default=None, description="结束日期")


class TenantParams(BaseSchema):
    """租户参数"""
    
    tenant_id: str = Field(..., description="租户ID")


class Response(BaseSchema):
    """通用响应"""
    
    code: int = Field(default=200, description="响应码")
    message: str = Field(default="success", description="响应消息")
    data: Optional[Any] = Field(default=None, description="响应数据")


class ErrorResponse(BaseSchema):
    """错误响应"""
    
    code: int = Field(default=400, description="错误码")
    message: str = Field(..., description="错误消息")
    detail: Optional[str] = Field(default=None, description="详细错误信息")


class SuccessResponse(BaseSchema):
    """成功响应"""
    
    code: int = Field(default=200, description="响应码")
    message: str = Field(default="操作成功", description="响应消息")
    data: Optional[Any] = Field(default=None, description="响应数据")


# 泛型类型定义
T = TypeVar("T")


class PaginatedResponse(BaseSchema, Generic[T]):
    """分页响应（泛型）"""
    
    items: List[T] = Field(default_factory=list, description="数据列表")
    total: int = Field(default=0, description="总数量")
    page: int = Field(default=1, description="当前页码")
    page_size: int = Field(default=10, description="每页数量")
    pages: int = Field(default=0, description="总页数")


class ListResponse(BaseSchema, Generic[T]):
    """列表响应（泛型）"""
    
    items: List[T] = Field(default_factory=list, description="数据列表")
    total: int = Field(default=0, description="总数量")


class IDResponse(BaseSchema):
    """ID响应"""
    
    id: int = Field(..., description="记录ID")


class StatusResponse(BaseSchema):
    """状态响应"""
    
    status: bool = Field(..., description="状态")
    message: str = Field(default="", description="消息")


class CountResponse(BaseSchema):
    """计数响应"""
    
    count: int = Field(..., description="数量")
