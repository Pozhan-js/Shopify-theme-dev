"""API依赖项"""
from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from .endpoints.auth import get_current_active_user
from ..core.database import get_db
from ..models.user import User


# 导出常用依赖
get_current_user = get_current_active_user
get_database = get_db
