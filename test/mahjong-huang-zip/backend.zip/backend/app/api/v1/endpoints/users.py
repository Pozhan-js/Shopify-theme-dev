"""用户管理API"""
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from ....core.database import get_db
from ....models.user import User
from ....schemas.user import UserCreate, UserInDB, UserUpdate, UserWithProfile
from ....services.user_service import UserService
from ...deps import get_current_active_user

router = APIRouter()


@router.get("/", response_model=List[UserInDB])
async def get_users(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    tenant_id: str = Query(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取用户列表"""
    user_service = UserService(db)
    users = await user_service.get_users_by_tenant(tenant_id, skip, limit)
    return users


@router.post("/", response_model=UserInDB)
async def create_user(
    user_data: UserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """创建用户"""
    user_service = UserService(db)
    
    # 检查用户名是否存在
    if await user_service.get_user_by_username(user_data.username, user_data.tenant_id):
        raise HTTPException(status_code=400, detail="用户名已存在")
    
    # 检查手机号是否存在
    if user_data.phone and await user_service.get_user_by_phone(user_data.phone, user_data.tenant_id):
        raise HTTPException(status_code=400, detail="手机号已存在")
    
    user = await user_service.create_user(user_data)
    return user


@router.get("/{user_id}", response_model=UserWithProfile)
async def get_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取用户详情"""
    user_service = UserService(db)
    user = await user_service.get_user_with_profile(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    return user


@router.put("/{user_id}", response_model=UserInDB)
async def update_user(
    user_id: int,
    user_data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """更新用户"""
    user_service = UserService(db)
    user = await user_service.update_user(user_id, user_data)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    return user


@router.delete("/{user_id}")
async def delete_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """删除用户"""
    user_service = UserService(db)
    success = await user_service.delete_user(user_id)
    if not success:
        raise HTTPException(status_code=404, detail="用户不存在")
    return {"message": "用户删除成功"}
