"""商品管理API"""
from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_products():
    """获取商品列表"""
    return {"message": "商品列表API"}


@router.post("/")
async def create_product():
    """创建商品"""
    return {"message": "创建商品API"}


@router.get("/{product_id}")
async def get_product(product_id: int):
    """获取商品详情"""
    return {"message": f"商品详情API: {product_id}"}


@router.put("/{product_id}")
async def update_product(product_id: int):
    """更新商品"""
    return {"message": f"更新商品API: {product_id}"}


@router.delete("/{product_id}")
async def delete_product(product_id: int):
    """删除商品"""
    return {"message": f"删除商品API: {product_id}"}


@router.get("/{product_id}/inventory")
async def get_product_inventory(product_id: int):
    """获取商品库存"""
    return {"message": f"商品库存API: {product_id}"}


@router.put("/{product_id}/inventory")
async def update_product_inventory(product_id: int):
    """更新商品库存"""
    return {"message": f"更新商品库存API: {product_id}"}
