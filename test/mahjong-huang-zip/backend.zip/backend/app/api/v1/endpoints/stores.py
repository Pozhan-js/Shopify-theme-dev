"""门店管理API"""
from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_stores():
    """获取门店列表"""
    return {"message": "门店列表API"}


@router.post("/")
async def create_store():
    """创建门店"""
    return {"message": "创建门店API"}


@router.get("/{store_id}")
async def get_store(store_id: int):
    """获取门店详情"""
    return {"message": f"门店详情API: {store_id}"}


@router.put("/{store_id}")
async def update_store(store_id: int):
    """更新门店"""
    return {"message": f"更新门店API: {store_id}"}


@router.delete("/{store_id}")
async def delete_store(store_id: int):
    """删除门店"""
    return {"message": f"删除门店API: {store_id}"}
