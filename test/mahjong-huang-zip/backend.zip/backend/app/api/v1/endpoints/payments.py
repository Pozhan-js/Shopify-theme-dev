"""支付管理API"""
from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_payments():
    """获取支付记录列表"""
    return {"message": "支付记录列表API"}


@router.post("/")
async def create_payment():
    """创建支付记录"""
    return {"message": "创建支付记录API"}


@router.get("/{payment_id}")
async def get_payment(payment_id: int):
    """获取支付详情"""
    return {"message": f"支付详情API: {payment_id}"}


@router.post("/wechat/prepay")
async def wechat_prepay():
    """微信支付预支付"""
    return {"message": "微信支付预支付API"}


@router.post("/wechat/notify")
async def wechat_notify():
    """微信支付回调"""
    return {"message": "微信支付回调API"}


@router.post("/alipay/prepay")
async def alipay_prepay():
    """支付宝预支付"""
    return {"message": "支付宝预支付API"}


@router.post("/alipay/notify")
async def alipay_notify():
    """支付宝回调"""
    return {"message": "支付宝回调API"}


@router.post("/{payment_id}/refund")
async def refund_payment(payment_id: int):
    """退款"""
    return {"message": f"退款API: {payment_id}"}


@router.get("/user/{user_id}")
async def get_user_payments(user_id: int):
    """获取用户支付记录"""
    return {"message": f"用户支付记录API: {user_id}"}
