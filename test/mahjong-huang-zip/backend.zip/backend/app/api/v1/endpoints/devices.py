"""设备管理API"""
from fastapi import APIRouter

router = APIRouter()


@router.get("/")
async def get_devices():
    """获取设备列表"""
    return {"message": "设备列表API"}


@router.post("/")
async def create_device():
    """创建设备"""
    return {"message": "创建设备API"}


@router.get("/{device_id}")
async def get_device(device_id: int):
    """获取设备详情"""
    return {"message": f"设备详情API: {device_id}"}


@router.put("/{device_id}")
async def update_device(device_id: int):
    """更新设备"""
    return {"message": f"更新设备API: {device_id}"}


@router.delete("/{device_id}")
async def delete_device(device_id: int):
    """删除设备"""
    return {"message": f"删除设备API: {device_id}"}


@router.post("/{device_id}/unlock")
async def unlock_device(device_id: int):
    """解锁设备"""
    return {"message": f"解锁设备API: {device_id}"}


@router.post("/{device_id}/lock")
async def lock_device(device_id: int):
    """锁定设备"""
    return {"message": f"锁定设备API: {device_id}"}


@router.get("/{device_id}/status")
async def get_device_status(device_id: int):
    """获取设备状态"""
    return {"message": f"设备状态API: {device_id}"}
