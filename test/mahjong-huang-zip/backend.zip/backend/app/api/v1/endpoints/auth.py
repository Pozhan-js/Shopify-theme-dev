"""认证相关API"""
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.ext.asyncio import AsyncSession

from ....core.config import settings
from ....core.database import get_db
from ....models.user import User
from ....schemas.user import Token, TokenData, UserCreate, UserLogin, UserRegister, WechatLogin
from ....services.user_service import UserService

# 密码加密上下文
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# OAuth2配置
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """验证密码"""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """获取密码哈希"""
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """创建访问令牌"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.access_token_expire_minutes)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)
    return encoded_jwt


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> User:
    """获取当前用户"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        username: str = payload.get("sub")
        tenant_id: str = payload.get("tenant_id")
        if username is None or tenant_id is None:
            raise credentials_exception
        token_data = TokenData(username=username, tenant_id=tenant_id)
    except JWTError:
        raise credentials_exception
    
    user_service = UserService(db)
    user = await user_service.get_user_by_username(token_data.username, token_data.tenant_id)
    if user is None:
        raise credentials_exception
    return user


async def get_current_active_user(current_user: User = Depends(get_current_user)) -> User:
    """获取当前激活用户"""
    if not current_user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user


router = APIRouter()


@router.post("/register", response_model=Token)
async def register(
    user_data: UserRegister,
    db: AsyncSession = Depends(get_db)
):
    """用户注册"""
    user_service = UserService(db)
    
    # 检查用户名是否存在
    if await user_service.get_user_by_username(user_data.username, user_data.tenant_id):
        raise HTTPException(
            status_code=400,
            detail="Username already registered"
        )
    
    # 检查手机号是否存在
    if user_data.phone and await user_service.get_user_by_phone(user_data.phone, user_data.tenant_id):
        raise HTTPException(
            status_code=400,
            detail="Phone already registered"
        )
    
    # 创建用户
    user = await user_service.create_user(user_data)
    
    # 创建访问令牌
    access_token = create_access_token(
        data={"sub": user.username, "tenant_id": user.tenant_id}
    )
    
    return {
        "access_token": access_token,
        "refresh_token": access_token,  # 简化处理，实际应该分开
        "token_type": "bearer",
        "expires_in": settings.access_token_expire_minutes * 60
    }


@router.post("/login", response_model=Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db)
):
    """用户登录"""
    user_service = UserService(db)
    
    # 获取用户
    user = await user_service.get_user_by_username(form_data.username, form_data.client_id or "default")
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # 验证密码
    if not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # 更新最后登录时间
    await user_service.update_last_login(user.id)
    
    # 创建访问令牌
    access_token = create_access_token(
        data={"sub": user.username, "tenant_id": user.tenant_id}
    )
    
    return {
        "access_token": access_token,
        "refresh_token": access_token,  # 简化处理，实际应该分开
        "token_type": "bearer",
        "expires_in": settings.access_token_expire_minutes * 60
    }


@router.post("/wechat/login", response_model=Token)
async def wechat_login(
    login_data: WechatLogin,
    db: AsyncSession = Depends(get_db)
):
    """微信登录"""
    user_service = UserService(db)
    
    # 这里应该调用微信API获取openid
    # 简化处理，直接使用code作为openid
    openid = login_data.code
    
    # 查找或创建用户
    user = await user_service.get_user_by_openid(openid, login_data.tenant_id)
    if not user:
        # 创建新用户
        user_data = UserCreate(
            username=f"wx_{openid[:8]}",
            openid=openid,
            tenant_id=login_data.tenant_id
        )
        user = await user_service.create_user(user_data)
    
    # 创建访问令牌
    access_token = create_access_token(
        data={"sub": user.username, "tenant_id": user.tenant_id}
    )
    
    return {
        "access_token": access_token,
        "refresh_token": access_token,
        "token_type": "bearer",
        "expires_in": settings.access_token_expire_minutes * 60
    }


@router.get("/me")
async def get_current_user_info(
    current_user: User = Depends(get_current_active_user)
):
    """获取当前用户信息"""
    return current_user


@router.post("/logout")
async def logout(
    current_user: User = Depends(get_current_active_user)
):
    """用户登出"""
    # 这里可以实现令牌失效逻辑
    return {"message": "Successfully logged out"}
