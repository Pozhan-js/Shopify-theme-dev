"""API端点模块"""
from .auth import router as auth_router
from .users import router as users_router
from .stores import router as stores_router
from .devices import router as devices_router
from .orders import router as orders_router
from .products import router as products_router
from .coupons import router as coupons_router
from .bookings import router as bookings_router
from .payments import router as payments_router
from .notifications import router as notifications_router
from .face import router as face_router

__all__ = [
    "auth_router",
    "users_router",
    "stores_router",
    "devices_router",
    "orders_router",
    "products_router",
    "coupons_router",
    "bookings_router",
    "payments_router",
    "notifications_router",
    "face_router",
]
