"""API路由配置"""
from fastapi import APIRouter

from .endpoints import (
    auth,
    users,
    stores,
    devices,
    orders,
    products,
    coupons,
    bookings,
    payments,
    notifications,
    face,
)

api_router = APIRouter()

# 认证相关
api_router.include_router(auth.router, prefix="/auth", tags=["认证"])

# 用户相关
api_router.include_router(users.router, prefix="/users", tags=["用户"])

# 门店相关
api_router.include_router(stores.router, prefix="/stores", tags=["门店"])

# 设备相关
api_router.include_router(devices.router, prefix="/devices", tags=["设备"])

# 订单相关
api_router.include_router(orders.router, prefix="/orders", tags=["订单"])

# 商品相关
api_router.include_router(products.router, prefix="/products", tags=["商品"])

# 优惠券相关
api_router.include_router(coupons.router, prefix="/coupons", tags=["优惠券"])

# 预约相关
api_router.include_router(bookings.router, prefix="/bookings", tags=["预约"])

# 支付相关
api_router.include_router(payments.router, prefix="/payments", tags=["支付"])

# 通知相关
api_router.include_router(notifications.router, prefix="/notifications", tags=["通知"])

# 人脸识别相关
api_router.include_router(face.router, prefix="/face", tags=["人脸识别"])
