"""API路由总配置"""
from fastapi import APIRouter

from .member import member_router
from .product import product_router
from .v1.api import api_router

# 创建主API路由
main_router = APIRouter()

# 会员相关API - 匹配小程序接口
main_router.include_router(member_router, prefix="/member", tags=["会员"])

# 商品相关API - 匹配小程序接口
main_router.include_router(product_router, prefix="/product", tags=["商品"])

# RESTful API - 标准接口
main_router.include_router(api_router, prefix="/api/v1", tags=["标准API"])
