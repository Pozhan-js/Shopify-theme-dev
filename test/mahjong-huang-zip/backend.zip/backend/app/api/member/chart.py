"""图表统计API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/getOrderChart")
async def get_order_chart(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取订单图表数据"""
    return {
        "message": "获取订单图表数据",
        "start_date": start_date,
        "end_date": end_date,
        "store_id": store_id
    }


@router.get("/getRevenueChart")
async def get_revenue_chart(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取收入图表数据"""
    return {
        "message": "获取收入图表数据",
        "start_date": start_date,
        "end_date": end_date,
        "store_id": store_id
    }


@router.get("/getUserChart")
async def get_user_chart(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取用户图表数据"""
    return {
        "message": "获取用户图表数据",
        "start_date": start_date,
        "end_date": end_date,
        "store_id": store_id
    }


@router.get("/getDeviceChart")
async def get_device_chart(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备图表数据"""
    return {
        "message": "获取设备图表数据",
        "start_date": start_date,
        "end_date": end_date,
        "store_id": store_id
    }


@router.get("/getStoreChart")
async def get_store_chart(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    db: AsyncSession = Depends(get_db)
):
    """获取门店图表数据"""
    return {
        "message": "获取门店图表数据",
        "start_date": start_date,
        "end_date": end_date
    }


@router.get("/getCouponChart")
async def get_coupon_chart(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取优惠券图表数据"""
    return {
        "message": "获取优惠券图表数据",
        "start_date": start_date,
        "end_date": end_date,
        "store_id": store_id
    }


@router.get("/getCardChart")
async def get_card_chart(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取会员卡图表数据"""
    return {
        "message": "获取会员卡图表数据",
        "start_date": start_date,
        "end_date": end_date,
        "store_id": store_id
    }


@router.get("/getBookingChart")
async def get_booking_chart(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取预约图表数据"""
    return {
        "message": "获取预约图表数据",
        "start_date": start_date,
        "end_date": end_date,
        "store_id": store_id
    }


@router.get("/getRealTimeData")
async def get_real_time_data(
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取实时数据"""
    return {"message": "获取实时数据", "store_id": store_id}


@router.get("/getDashboardSummary")
async def get_dashboard_summary(
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取仪表盘汇总数据"""
    return {"message": "获取仪表盘汇总数据", "store_id": store_id}


@router.get("/getTopProducts")
async def get_top_products(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    store_id: int = Query(None, description="门店ID"),
    limit: int = Query(10, description="数量限制"),
    db: AsyncSession = Depends(get_db)
):
    """获取热销商品"""
    return {
        "message": "获取热销商品",
        "start_date": start_date,
        "end_date": end_date,
        "store_id": store_id,
        "limit": limit
    }


@router.get("/getTopUsers")
async def get_top_users(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    store_id: int = Query(None, description="门店ID"),
    limit: int = Query(10, description="数量限制"),
    db: AsyncSession = Depends(get_db)
):
    """获取活跃用户"""
    return {
        "message": "获取活跃用户",
        "start_date": start_date,
        "end_date": end_date,
        "store_id": store_id,
        "limit": limit
    }


@router.get("/getStoreComparison")
async def get_store_comparison(
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    db: AsyncSession = Depends(get_db)
):
    """获取门店对比数据"""
    return {
        "message": "获取门店对比数据",
        "start_date": start_date,
        "end_date": end_date
    }


@router.get("/getHourlyStats")
async def get_hourly_stats(
    date: str = Query(..., description="日期"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取小时统计数据"""
    return {
        "message": "获取小时统计数据",
        "date": date,
        "store_id": store_id
    }


@router.get("/getWeeklyStats")
async def get_weekly_stats(
    start_date: str = Query(..., description="开始日期"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取周统计数据"""
    return {
        "message": "获取周统计数据",
        "start_date": start_date,
        "store_id": store_id
    }


@router.get("/getMonthlyStats")
async def get_monthly_stats(
    year: int = Query(..., description="年份"),
    month: int = Query(..., description="月份"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取月统计数据"""
    return {
        "message": "获取月统计数据",
        "year": year,
        "month": month,
        "store_id": store_id
    }


@router.get("/getYearlyStats")
async def get_yearly_stats(
    year: int = Query(..., description="年份"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取年统计数据"""
    return {
        "message": "获取年统计数据",
        "year": year,
        "store_id": store_id
    }


@router.get("/exportChartData")
async def export_chart_data(
    chart_type: str = Query(..., description="图表类型"),
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    store_id: int = Query(None, description="门店ID"),
    format: str = Query("excel", description="导出格式"),
    db: AsyncSession = Depends(get_db)
):
    """导出图表数据"""
    return {
        "message": "导出图表数据",
        "chart_type": chart_type,
        "start_date": start_date,
        "end_date": end_date,
        "store_id": store_id,
        "format": format
    }
