"""优惠券API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/getCouponPage")
async def get_coupon_page(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    status: str = Query(None, description="状态"),
    db: AsyncSession = Depends(get_db)
):
    """获取优惠券分页"""
    return {"message": "获取优惠券分页", "page": page, "size": size, "status": status}


@router.get("/getById")
async def get_coupon_by_id(
    coupon_id: int = Query(..., description="优惠券ID"),
    db: AsyncSession = Depends(get_db)
):
    """根据ID获取优惠券"""
    return {"message": "根据ID获取优惠券", "coupon_id": coupon_id}


@router.post("/putCoupon")
async def put_coupon(
    id: int,
    db: AsyncSession = Depends(get_db)
):
    """领取优惠券"""
    return {"message": "领取优惠券", "id": id}


@router.get("/getAdminByCouponId")
async def get_admin_by_coupon_id(
    coupon_id: int = Query(..., description="优惠券ID"),
    db: AsyncSession = Depends(get_db)
):
    """管理员获取优惠券"""
    return {"message": "管理员获取优惠券", "coupon_id": coupon_id}


@router.post("/saveAdminByCouponId")
async def save_admin_by_coupon_id(
    coupon_id: int,
    num: int,
    end_time: str,
    active_name: str,
    db: AsyncSession = Depends(get_db)
):
    """管理员保存优惠券"""
    return {
        "message": "管理员保存优惠券",
        "coupon_id": coupon_id,
        "num": num,
        "end_time": end_time,
        "active_name": active_name
    }


@router.post("/stopActive")
async def stop_active(
    coupon_id: int,
    db: AsyncSession = Depends(get_db)
):
    """停止活动"""
    return {"message": "停止活动", "coupon_id": coupon_id}


@router.delete("/deleteCoupon")
async def delete_coupon(
    coupon_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除优惠券"""
    return {"message": "删除优惠券", "coupon_id": coupon_id}


@router.get("/getAdminCouponByAdmin")
async def get_admin_coupon_by_admin(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """管理员获取优惠券列表"""
    return {"message": "管理员获取优惠券列表", "page": page, "size": size}


@router.post("/giftCoupon")
async def gift_coupon(
    user_id: int,
    coupon_id: int,
    db: AsyncSession = Depends(get_db)
):
    """赠送优惠券"""
    return {"message": "赠送优惠券", "user_id": user_id, "coupon_id": coupon_id}


@router.get("/getCouponDetail/{coupon_id}")
async def get_coupon_detail(
    coupon_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取优惠券详情"""
    return {"message": "获取优惠券详情", "coupon_id": coupon_id}


@router.post("/saveCouponDetail")
async def save_coupon_detail(
    name: str,
    description: str,
    discount_type: str,
    discount_value: float,
    min_amount: float,
    start_time: str,
    end_time: str,
    db: AsyncSession = Depends(get_db)
):
    """保存优惠券详情"""
    return {
        "message": "保存优惠券详情",
        "name": name,
        "description": description,
        "discount_type": discount_type,
        "discount_value": discount_value,
        "min_amount": min_amount,
        "start_time": start_time,
        "end_time": end_time
    }


@router.post("/couponActive/saveAdminByCouponId")
async def save_admin_coupon(
    coupon_id: int,
    num: int,
    end_time: str,
    active_name: str,
    db: AsyncSession = Depends(get_db)
):
    """保存管理员优惠券"""
    return {
        "message": "保存管理员优惠券",
        "coupon_id": coupon_id,
        "num": num,
        "end_time": end_time,
        "active_name": active_name
    }


@router.get("/couponActive/getAdminByCouponId")
async def get_admin_coupon(
    coupon_id: int = Query(..., description="优惠券ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取管理员优惠券"""
    return {"message": "获取管理员优惠券", "coupon_id": coupon_id}


@router.post("/couponActive/putCoupon")
async def put_coupon_active(
    id: int,
    db: AsyncSession = Depends(get_db)
):
    """领取优惠券活动"""
    return {"message": "领取优惠券活动", "id": id}


@router.get("/couponActive/getById")
async def get_coupon_active_by_id(
    coupon_id: int = Query(..., description="优惠券ID"),
    db: AsyncSession = Depends(get_db)
):
    """根据ID获取优惠券活动"""
    return {"message": "根据ID获取优惠券活动", "coupon_id": coupon_id}


@router.post("/couponActive/stopActive")
async def stop_coupon_active(
    coupon_id: int,
    db: AsyncSession = Depends(get_db)
):
    """停止优惠券活动"""
    return {"message": "停止优惠券活动", "coupon_id": coupon_id}
