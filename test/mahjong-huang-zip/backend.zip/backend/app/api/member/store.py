"""门店API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/getPageList")
async def get_store_page_list(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    keyword: str = Query(None, description="搜索关键词"),
    db: AsyncSession = Depends(get_db)
):
    """获取门店分页列表"""
    return {"message": "获取门店分页列表", "page": page, "size": size, "keyword": keyword}


@router.get("/getDetail/{store_id}")
async def get_store_detail(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取门店详情"""
    return {"message": "获取门店详情", "store_id": store_id}


@router.post("/save")
async def save_store(
    name: str,
    address: str,
    phone: str,
    business_hours: str,
    db: AsyncSession = Depends(get_db)
):
    """保存门店信息"""
    return {
        "message": "保存门店信息",
        "name": name,
        "address": address,
        "phone": phone,
        "business_hours": business_hours
    }


@router.get("/getRoomInfoList/{store_id}")
async def get_room_info_list_by_store(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取门店房间列表"""
    return {"message": "获取门店房间列表", "store_id": store_id}


@router.get("/getRoomInfo/{room_id}")
async def get_room_detail(
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取房间详情"""
    return {"message": "获取房间详情", "room_id": room_id}


@router.post("/saveRoomDetail")
async def save_room_detail(
    room_id: int,
    name: str,
    description: str,
    price: float,
    db: AsyncSession = Depends(get_db)
):
    """保存房间详情"""
    return {
        "message": "保存房间详情",
        "room_id": room_id,
        "name": name,
        "description": description,
        "price": price
    }


@router.post("/openStoreDoor/{store_id}")
async def open_store_door_by_store(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """打开门店门"""
    return {"message": "打开门店门", "store_id": store_id}


@router.post("/openRoomDoor/{room_id}")
async def open_room_door_by_store(
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """打开房间门"""
    return {"message": "打开房间门", "room_id": room_id}


@router.post("/closeRoomDoor/{room_id}")
async def close_room_door(
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """关闭房间门"""
    return {"message": "关闭房间门", "room_id": room_id}


@router.get("/getLockPwd")
async def get_lock_password(
    room_id: int = Query(..., description="房间ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取门锁密码"""
    return {"message": "获取门锁密码", "room_id": room_id}


@router.post("/disableRoom/{room_id}")
async def disable_room(
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """禁用房间"""
    return {"message": "禁用房间", "room_id": room_id}


@router.delete("/deleteRoomInfo/{room_id}")
async def delete_room_info(
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除房间信息"""
    return {"message": "删除房间信息", "room_id": room_id}


@router.post("/resetQrcode")
async def reset_qrcode(
    store_id: int = Query(..., description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """重置二维码"""
    return {"message": "重置二维码", "store_id": store_id}


@router.post("/setDouyinId")
async def set_douyin_id(
    store_id: int,
    dy_id: str,
    db: AsyncSession = Depends(get_db)
):
    """设置抖音ID"""
    return {"message": "设置抖音ID", "store_id": store_id, "dy_id": dy_id}


@router.post("/runYunlaba")
async def run_yunlaba(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """运行云喇叭"""
    return {"message": "运行云喇叭", "store_id": store_id}


@router.post("/clearAndFinish/{room_id}")
async def clear_and_finish(
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """清理并完成"""
    return {"message": "清理并完成", "room_id": room_id}


@router.post("/finishRoomOrder/{room_id}")
async def finish_room_order(
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """完成房间订单"""
    return {"message": "完成房间订单", "room_id": room_id}


@router.post("/controlKT")
async def control_kt(
    room_id: int,
    action: str,
    db: AsyncSession = Depends(get_db)
):
    """控制空调"""
    return {"message": "控制空调", "room_id": room_id, "action": action}


@router.get("/getStoreListByAdmin")
async def get_store_list_by_admin(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """管理员获取门店列表"""
    return {"message": "管理员获取门店列表", "page": page, "size": size}


@router.get("/getRoomList/{store_id}")
async def get_room_list(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取房间列表"""
    return {"message": "获取房间列表", "store_id": store_id}


@router.get("/getGroupPayAuthUrl")
async def get_group_pay_auth_url(
    store_id: int = Query(..., description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取团购支付授权URL"""
    return {"message": "获取团购支付授权URL", "store_id": store_id}


@router.get("/getPrePayConfig/{room_id}")
async def get_pre_pay_config(
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取预支付配置"""
    return {"message": "获取预支付配置", "room_id": room_id}


@router.post("/setPrePayConfig")
async def set_pre_pay_config(
    room_id: int,
    config: str,
    db: AsyncSession = Depends(get_db)
):
    """设置预支付配置"""
    return {"message": "设置预支付配置", "room_id": room_id, "config": config}


@router.get("/getStoreSoundInfo/{store_id}")
async def get_store_sound_info(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取门店声音信息"""
    return {"message": "获取门店声音信息", "store_id": store_id}


@router.post("/saveStoreSoundInfo")
async def save_store_sound_info(
    store_id: int,
    sound_config: str,
    db: AsyncSession = Depends(get_db)
):
    """保存门店声音信息"""
    return {"message": "保存门店声音信息", "store_id": store_id, "sound_config": sound_config}


@router.get("/getTemplateList")
async def get_template_list(
    store_id: int = Query(..., description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取模板列表"""
    return {"message": "获取模板列表", "store_id": store_id}


@router.post("/setTemplate")
async def set_template(
    store_id: int,
    template_id: int,
    db: AsyncSession = Depends(get_db)
):
    """设置模板"""
    return {"message": "设置模板", "store_id": store_id, "template_id": template_id}


@router.get("/getVipConfig/{store_id}")
async def get_vip_config(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取VIP配置"""
    return {"message": "获取VIP配置", "store_id": store_id}


@router.post("/saveVipConfig")
async def save_vip_config(
    store_id: int,
    config: str,
    db: AsyncSession = Depends(get_db)
):
    """保存VIP配置"""
    return {"message": "保存VIP配置", "store_id": store_id, "config": config}


@router.delete("/deleteVipConfig/{id}")
async def delete_vip_config(
    id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除VIP配置"""
    return {"message": "删除VIP配置", "id": id}


@router.get("/getDiscountRulesPage")
async def get_discount_rules_page(
    store_id: int = Query(..., description="门店ID"),
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取折扣规则分页"""
    return {"message": "获取折扣规则分页", "store_id": store_id, "page": page, "size": size}


@router.get("/getDiscountRuleDetail/{discount_id}")
async def get_discount_rule_detail(
    discount_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取折扣规则详情"""
    return {"message": "获取折扣规则详情", "discount_id": discount_id}


@router.post("/saveDiscountRuleDetail")
async def save_discount_rule_detail(
    store_id: int,
    rule: str,
    db: AsyncSession = Depends(get_db)
):
    """保存折扣规则详情"""
    return {"message": "保存折扣规则详情", "store_id": store_id, "rule": rule}


@router.post("/changeDiscountRulesStatus/{discount_id}")
async def change_discount_rules_status(
    discount_id: int,
    status: str,
    db: AsyncSession = Depends(get_db)
):
    """更改折扣规则状态"""
    return {"message": "更改折扣规则状态", "discount_id": discount_id, "status": status}


@router.get("/getQrConfig")
async def get_qr_config(
    sn: str = Query(..., description="设备SN"),
    db: AsyncSession = Depends(get_db)
):
    """获取二维码配置"""
    return {"message": "获取二维码配置", "sn": sn}


@router.post("/setQrConfig")
async def set_qr_config(
    sn: str,
    hour: int,
    price: float,
    db: AsyncSession = Depends(get_db)
):
    """设置二维码配置"""
    return {"message": "设置二维码配置", "sn": sn, "hour": hour, "price": price}
