"""会员相关API模块"""
from fastapi import APIRouter

from .auth import router as auth_router
from .user import router as user_router
from .index import router as index_router
from .order import router as order_router
from .store import router as store_router
from .coupon import router as coupon_router
from .card import router as card_router
from .manager import router as manager_router
from .chart import router as chart_router
from .clear import router as clear_router
from .device import router as device_router

# 创建会员API路由
member_router = APIRouter()

# 认证相关
member_router.include_router(auth_router, prefix="/auth", tags=["会员认证"])

# 用户相关
member_router.include_router(user_router, prefix="/user", tags=["会员用户"])

# 首页相关
member_router.include_router(index_router, prefix="/index", tags=["首页"])

# 订单相关
member_router.include_router(order_router, prefix="/order", tags=["订单"])

# 门店相关
member_router.include_router(store_router, prefix="/store", tags=["门店"])

# 优惠券相关
member_router.include_router(coupon_router, prefix="/coupon", tags=["优惠券"])

# 会员卡相关
member_router.include_router(card_router, prefix="/card", tags=["会员卡"])

# 管理员相关
member_router.include_router(manager_router, prefix="/manager", tags=["管理员"])

# 图表统计相关
member_router.include_router(chart_router, prefix="/chart", tags=["图表统计"])

# 清洁任务相关
member_router.include_router(clear_router, prefix="/clear", tags=["清洁任务"])

# 设备管理相关
member_router.include_router(device_router, prefix="/device", tags=["设备管理"])
