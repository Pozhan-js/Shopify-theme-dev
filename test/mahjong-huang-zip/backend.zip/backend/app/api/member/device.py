"""设备管理API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/getDevicePage")
async def get_device_page(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    device_type: str = Query(None, description="设备类型"),
    status: str = Query(None, description="状态"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备分页"""
    return {
        "message": "获取设备分页",
        "page": page,
        "size": size,
        "device_type": device_type,
        "status": status,
        "store_id": store_id
    }


@router.get("/getById")
async def get_device_by_id(
    device_id: int = Query(..., description="设备ID"),
    db: AsyncSession = Depends(get_db)
):
    """根据ID获取设备"""
    return {"message": "根据ID获取设备", "device_id": device_id}


@router.post("/saveDevice")
async def save_device(
    name: str,
    device_type: str,
    model: str,
    serial_number: str,
    store_id: int,
    room_id: int,
    ip_address: str,
    port: int,
    status: str,
    description: str,
    db: AsyncSession = Depends(get_db)
):
    """保存设备"""
    return {
        "message": "保存设备",
        "name": name,
        "device_type": device_type,
        "model": model,
        "serial_number": serial_number,
        "store_id": store_id,
        "room_id": room_id,
        "ip_address": ip_address,
        "port": port,
        "status": status,
        "description": description
    }


@router.post("/updateDevice")
async def update_device(
    device_id: int,
    name: str,
    device_type: str,
    model: str,
    serial_number: str,
    store_id: int,
    room_id: int,
    ip_address: str,
    port: int,
    status: str,
    description: str,
    db: AsyncSession = Depends(get_db)
):
    """更新设备"""
    return {
        "message": "更新设备",
        "device_id": device_id,
        "name": name,
        "device_type": device_type,
        "model": model,
        "serial_number": serial_number,
        "store_id": store_id,
        "room_id": room_id,
        "ip_address": ip_address,
        "port": port,
        "status": status,
        "description": description
    }


@router.delete("/deleteDevice")
async def delete_device(
    device_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除设备"""
    return {"message": "删除设备", "device_id": device_id}


@router.post("/controlDevice")
async def control_device(
    device_id: int,
    action: str,
    parameters: str,
    db: AsyncSession = Depends(get_db)
):
    """控制设备"""
    return {
        "message": "控制设备",
        "device_id": device_id,
        "action": action,
        "parameters": parameters
    }


@router.get("/getDeviceStatus")
async def get_device_status(
    device_id: int = Query(..., description="设备ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备状态"""
    return {"message": "获取设备状态", "device_id": device_id}


@router.post("/updateDeviceStatus")
async def update_device_status(
    device_id: int,
    status: str,
    db: AsyncSession = Depends(get_db)
):
    """更新设备状态"""
    return {"message": "更新设备状态", "device_id": device_id, "status": status}


@router.get("/getDeviceLogs")
async def get_device_logs(
    device_id: int = Query(..., description="设备ID"),
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备日志"""
    return {
        "message": "获取设备日志",
        "device_id": device_id,
        "page": page,
        "size": size
    }


@router.get("/getDeviceStats")
async def get_device_stats(
    store_id: int = Query(None, description="门店ID"),
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备统计"""
    return {
        "message": "获取设备统计",
        "store_id": store_id,
        "start_date": start_date,
        "end_date": end_date
    }


@router.post("/restartDevice")
async def restart_device(
    device_id: int,
    db: AsyncSession = Depends(get_db)
):
    """重启设备"""
    return {"message": "重启设备", "device_id": device_id}


@router.post("/resetDevice")
async def reset_device(
    device_id: int,
    db: AsyncSession = Depends(get_db)
):
    """重置设备"""
    return {"message": "重置设备", "device_id": device_id}


@router.get("/getDeviceTypes")
async def get_device_types(
    db: AsyncSession = Depends(get_db)
):
    """获取设备类型"""
    return {"message": "获取设备类型"}


@router.get("/getDeviceModels")
async def get_device_models(
    device_type: str = Query(..., description="设备类型"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备型号"""
    return {"message": "获取设备型号", "device_type": device_type}


@router.get("/getRoomDevices")
async def get_room_devices(
    room_id: int = Query(..., description="房间ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取房间设备"""
    return {"message": "获取房间设备", "room_id": room_id}


@router.post("/bindDeviceToRoom")
async def bind_device_to_room(
    device_id: int,
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """绑定设备到房间"""
    return {"message": "绑定设备到房间", "device_id": device_id, "room_id": room_id}


@router.post("/unbindDeviceFromRoom")
async def unbind_device_from_room(
    device_id: int,
    db: AsyncSession = Depends(get_db)
):
    """解绑设备从房间"""
    return {"message": "解绑设备从房间", "device_id": device_id}


@router.get("/getDeviceAlarms")
async def get_device_alarms(
    device_id: int = Query(..., description="设备ID"),
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备告警"""
    return {
        "message": "获取设备告警",
        "device_id": device_id,
        "page": page,
        "size": size
    }


@router.post("/handleDeviceAlarm")
async def handle_device_alarm(
    alarm_id: int,
    handle_type: str,
    notes: str,
    db: AsyncSession = Depends(get_db)
):
    """处理设备告警"""
    return {
        "message": "处理设备告警",
        "alarm_id": alarm_id,
        "handle_type": handle_type,
        "notes": notes
    }


@router.get("/getDeviceMaintenance")
async def get_device_maintenance(
    device_id: int = Query(..., description="设备ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备维护信息"""
    return {"message": "获取设备维护信息", "device_id": device_id}


@router.post("/scheduleDeviceMaintenance")
async def schedule_device_maintenance(
    device_id: int,
    maintenance_type: str,
    scheduled_date: str,
    description: str,
    db: AsyncSession = Depends(get_db)
):
    """安排设备维护"""
    return {
        "message": "安排设备维护",
        "device_id": device_id,
        "maintenance_type": maintenance_type,
        "scheduled_date": scheduled_date,
        "description": description
    }


@router.get("/getDeviceNetworkStatus")
async def get_device_network_status(
    device_id: int = Query(..., description="设备ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备网络状态"""
    return {"message": "获取设备网络状态", "device_id": device_id}


@router.post("/testDeviceConnection")
async def test_device_connection(
    device_id: int,
    db: AsyncSession = Depends(get_db)
):
    """测试设备连接"""
    return {"message": "测试设备连接", "device_id": device_id}


@router.get("/getDeviceFirmware")
async def get_device_firmware(
    device_id: int = Query(..., description="设备ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备固件信息"""
    return {"message": "获取设备固件信息", "device_id": device_id}


@router.post("/updateDeviceFirmware")
async def update_device_firmware(
    device_id: int,
    firmware_version: str,
    db: AsyncSession = Depends(get_db)
):
    """更新设备固件"""
    return {
        "message": "更新设备固件",
        "device_id": device_id,
        "firmware_version": firmware_version
    }


@router.get("/getDeviceConfig")
async def get_device_config(
    device_id: int = Query(..., description="设备ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备配置"""
    return {"message": "获取设备配置", "device_id": device_id}


@router.post("/updateDeviceConfig")
async def update_device_config(
    device_id: int,
    config: str,
    db: AsyncSession = Depends(get_db)
):
    """更新设备配置"""
    return {"message": "更新设备配置", "device_id": device_id, "config": config}


@router.get("/getDeviceRealtimeData")
async def get_device_realtime_data(
    device_id: int = Query(..., description="设备ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备实时数据"""
    return {"message": "获取设备实时数据", "device_id": device_id}


@router.post("/batchControlDevices")
async def batch_control_devices(
    device_ids: str,
    action: str,
    parameters: str,
    db: AsyncSession = Depends(get_db)
):
    """批量控制设备"""
    return {
        "message": "批量控制设备",
        "device_ids": device_ids,
        "action": action,
        "parameters": parameters
    }


@router.get("/getDeviceEnergyConsumption")
async def get_device_energy_consumption(
    device_id: int = Query(..., description="设备ID"),
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    db: AsyncSession = Depends(get_db)
):
    """获取设备能耗"""
    return {
        "message": "获取设备能耗",
        "device_id": device_id,
        "start_date": start_date,
        "end_date": end_date
    }
