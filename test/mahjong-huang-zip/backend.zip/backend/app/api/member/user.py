"""会员用户API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/get")
async def get_user_info(db: AsyncSession = Depends(get_db)):
    """获取用户信息"""
    return {"message": "获取用户信息"}


@router.post("/update-mobile")
async def update_mobile(
    mobile: str,
    db: AsyncSession = Depends(get_db)
):
    """更新手机号"""
    return {"message": "更新手机号", "mobile": mobile}


@router.post("/updateNickname")
async def update_nickname(
    nickname: str,
    db: AsyncSession = Depends(get_db)
):
    """更新昵称"""
    return {"message": "更新昵称", "nickname": nickname}


@router.post("/updateAvatar")
async def update_avatar(
    avatarUrl: str,
    db: AsyncSession = Depends(get_db)
):
    """更新头像"""
    return {"message": "更新头像", "avatarUrl": avatarUrl}


@router.get("/getCouponPage")
async def get_coupon_page(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取优惠券分页"""
    return {"message": "获取优惠券分页", "page": page, "size": size}


@router.get("/getMoneyBillPage")
async def get_money_bill_page(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取资金账单分页"""
    return {"message": "获取资金账单分页", "page": page, "size": size}


@router.get("/getGiftBalanceList")
async def get_gift_balance_list(db: AsyncSession = Depends(get_db)):
    """获取礼品余额列表"""
    return {"message": "获取礼品余额列表"}


@router.get("/getStoreBalance/{store_id}")
async def get_store_balance(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取门店余额"""
    return {"message": "获取门店余额", "store_id": store_id}


@router.post("/preRechargeBalance")
async def pre_recharge_balance(
    amount: float,
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """预充值余额"""
    return {"message": "预充值余额", "amount": amount, "store_id": store_id}


@router.post("/rechargeBalance")
async def recharge_balance(
    amount: float,
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """充值余额"""
    return {"message": "充值余额", "amount": amount, "store_id": store_id}


@router.get("/getMyCardPage")
async def get_my_card_page(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取我的卡包分页"""
    return {"message": "获取我的卡包分页", "page": page, "size": size}


@router.post("/saveFranchiseInfo")
async def save_franchise_info(
    name: str,
    phone: str,
    content: str,
    db: AsyncSession = Depends(get_db)
):
    """保存加盟信息"""
    return {"message": "保存加盟信息", "name": name, "phone": phone, "content": content}


@router.get("/getFranchiseInfo")
async def get_franchise_info(db: AsyncSession = Depends(get_db)):
    """获取加盟信息"""
    return {"message": "获取加盟信息"}
