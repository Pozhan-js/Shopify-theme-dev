"""订单API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/getOrderPage")
async def get_order_page(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    status: str = Query(None, description="订单状态"),
    db: AsyncSession = Depends(get_db)
):
    """获取订单分页"""
    return {"message": "获取订单分页", "page": page, "size": size, "status": status}


@router.get("/getOrderInfo")
async def get_order_info(
    order_id: int = Query(None, description="订单ID"),
    order_key: str = Query(None, description="订单key"),
    db: AsyncSession = Depends(get_db)
):
    """获取订单信息"""
    return {"message": "获取订单信息", "order_id": order_id, "order_key": order_key}


@router.get("/getOrderInfoByNo")
async def get_order_info_by_no(
    order_no: str = Query(..., description="订单号"),
    order_key: str = Query(None, description="订单key"),
    db: AsyncSession = Depends(get_db)
):
    """根据订单号获取订单信息"""
    return {"message": "根据订单号获取订单信息", "order_no": order_no, "order_key": order_key}


@router.post("/cancelOrder/{order_id}")
async def cancel_order(
    order_id: int,
    db: AsyncSession = Depends(get_db)
):
    """取消订单"""
    return {"message": "取消订单", "order_id": order_id}


@router.post("/startOrder/{order_id}")
async def start_order(
    order_id: int,
    db: AsyncSession = Depends(get_db)
):
    """开始订单"""
    return {"message": "开始订单", "order_id": order_id}


@router.post("/closeOrder/{order_id}")
async def close_order(
    order_id: int,
    db: AsyncSession = Depends(get_db)
):
    """关闭订单"""
    return {"message": "关闭订单", "order_id": order_id}


@router.post("/preOrder")
async def pre_order(
    room_id: int,
    start_time: str,
    end_time: str,
    db: AsyncSession = Depends(get_db)
):
    """预下单"""
    return {
        "message": "预下单",
        "room_id": room_id,
        "start_time": start_time,
        "end_time": end_time
    }


@router.post("/lockWxOrder")
async def lock_wx_order(
    order_id: int,
    db: AsyncSession = Depends(get_db)
):
    """锁定微信订单"""
    return {"message": "锁定微信订单", "order_id": order_id}


@router.post("/renew")
async def renew_order(
    order_id: int,
    duration: int,
    db: AsyncSession = Depends(get_db)
):
    """续费订单"""
    return {"message": "续费订单", "order_id": order_id, "duration": duration}


@router.post("/openStoreDoor")
async def open_store_door(
    order_key: str,
    db: AsyncSession = Depends(get_db)
):
    """打开门店门"""
    return {"message": "打开门店门", "order_key": order_key}


@router.post("/openRoomDoor")
async def open_room_door(
    order_key: str,
    db: AsyncSession = Depends(get_db)
):
    """打开房间门"""
    return {"message": "打开房间门", "order_key": order_key}


@router.get("/getLockPwd")
async def get_lock_pwd(
    order_key: str,
    db: AsyncSession = Depends(get_db)
):
    """获取门锁密码"""
    return {"message": "获取门锁密码", "order_key": order_key}


@router.post("/controlKT")
async def control_kt(
    room_id: int,
    action: str,
    db: AsyncSession = Depends(get_db)
):
    """控制空调"""
    return {"message": "控制空调", "room_id": room_id, "action": action}


@router.post("/changeRoom/{order_id}/{room_id}")
async def change_room(
    order_id: int,
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """更换房间"""
    return {"message": "更换房间", "order_id": order_id, "room_id": room_id}


@router.post("/preGroupNo")
async def pre_group_no(
    order_id: int,
    db: AsyncSession = Depends(get_db)
):
    """预生成团购号"""
    return {"message": "预生成团购号", "order_id": order_id}


@router.post("/save")
async def save_order(
    room_id: int,
    start_time: str,
    end_time: str,
    coupon_id: int = None,
    db: AsyncSession = Depends(get_db)
):
    """保存订单"""
    return {
        "message": "保存订单",
        "room_id": room_id,
        "start_time": start_time,
        "end_time": end_time,
        "coupon_id": coupon_id
    }


@router.get("/getDiscountRules/{store_id}")
async def get_discount_rules(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取折扣规则"""
    return {"message": "获取折扣规则", "store_id": store_id}
