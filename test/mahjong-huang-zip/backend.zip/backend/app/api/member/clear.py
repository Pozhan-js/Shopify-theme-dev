"""清洁任务API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/getClearTaskPage")
async def get_clear_task_page(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    status: str = Query(None, description="状态"),
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取清洁任务分页"""
    return {
        "message": "获取清洁任务分页",
        "page": page,
        "size": size,
        "status": status,
        "store_id": store_id
    }


@router.get("/getById")
async def get_clear_task_by_id(
    task_id: int = Query(..., description="任务ID"),
    db: AsyncSession = Depends(get_db)
):
    """根据ID获取清洁任务"""
    return {"message": "根据ID获取清洁任务", "task_id": task_id}


@router.post("/createClearTask")
async def create_clear_task(
    store_id: int,
    room_id: int,
    task_type: str,
    priority: str,
    description: str,
    scheduled_time: str,
    assigned_to: int,
    db: AsyncSession = Depends(get_db)
):
    """创建清洁任务"""
    return {
        "message": "创建清洁任务",
        "store_id": store_id,
        "room_id": room_id,
        "task_type": task_type,
        "priority": priority,
        "description": description,
        "scheduled_time": scheduled_time,
        "assigned_to": assigned_to
    }


@router.post("/updateClearTask")
async def update_clear_task(
    task_id: int,
    store_id: int,
    room_id: int,
    task_type: str,
    priority: str,
    description: str,
    scheduled_time: str,
    assigned_to: int,
    db: AsyncSession = Depends(get_db)
):
    """更新清洁任务"""
    return {
        "message": "更新清洁任务",
        "task_id": task_id,
        "store_id": store_id,
        "room_id": room_id,
        "task_type": task_type,
        "priority": priority,
        "description": description,
        "scheduled_time": scheduled_time,
        "assigned_to": assigned_to
    }


@router.post("/assignClearTask")
async def assign_clear_task(
    task_id: int,
    assigned_to: int,
    db: AsyncSession = Depends(get_db)
):
    """分配清洁任务"""
    return {"message": "分配清洁任务", "task_id": task_id, "assigned_to": assigned_to}


@router.post("/startClearTask")
async def start_clear_task(
    task_id: int,
    started_by: int,
    db: AsyncSession = Depends(get_db)
):
    """开始清洁任务"""
    return {"message": "开始清洁任务", "task_id": task_id, "started_by": started_by}


@router.post("/completeClearTask")
async def complete_clear_task(
    task_id: int,
    completed_by: int,
    notes: str,
    images: str,
    db: AsyncSession = Depends(get_db)
):
    """完成清洁任务"""
    return {
        "message": "完成清洁任务",
        "task_id": task_id,
        "completed_by": completed_by,
        "notes": notes,
        "images": images
    }


@router.post("/cancelClearTask")
async def cancel_clear_task(
    task_id: int,
    reason: str,
    cancelled_by: int,
    db: AsyncSession = Depends(get_db)
):
    """取消清洁任务"""
    return {
        "message": "取消清洁任务",
        "task_id": task_id,
        "reason": reason,
        "cancelled_by": cancelled_by
    }


@router.delete("/deleteClearTask")
async def delete_clear_task(
    task_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除清洁任务"""
    return {"message": "删除清洁任务", "task_id": task_id}


@router.get("/getClearTaskStats")
async def get_clear_task_stats(
    store_id: int = Query(None, description="门店ID"),
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    db: AsyncSession = Depends(get_db)
):
    """获取清洁任务统计"""
    return {
        "message": "获取清洁任务统计",
        "store_id": store_id,
        "start_date": start_date,
        "end_date": end_date
    }


@router.get("/getClearStaff")
async def get_clear_staff(
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取清洁人员列表"""
    return {"message": "获取清洁人员列表", "store_id": store_id}


@router.get("/getClearTaskTypes")
async def get_clear_task_types(
    db: AsyncSession = Depends(get_db)
):
    """获取清洁任务类型"""
    return {"message": "获取清洁任务类型"}


@router.get("/getClearTaskPriorities")
async def get_clear_task_priorities(
    db: AsyncSession = Depends(get_db)
):
    """获取清洁任务优先级"""
    return {"message": "获取清洁任务优先级"}


@router.get("/getRoomClearHistory")
async def get_room_clear_history(
    room_id: int = Query(..., description="房间ID"),
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取房间清洁历史"""
    return {
        "message": "获取房间清洁历史",
        "room_id": room_id,
        "page": page,
        "size": size
    }


@router.post("/scheduleAutoClear")
async def schedule_auto_clear(
    store_id: int,
    room_id: int,
    frequency: str,
    scheduled_time: str,
    task_type: str,
    db: AsyncSession = Depends(get_db)
):
    """设置自动清洁计划"""
    return {
        "message": "设置自动清洁计划",
        "store_id": store_id,
        "room_id": room_id,
        "frequency": frequency,
        "scheduled_time": scheduled_time,
        "task_type": task_type
    }


@router.get("/getAutoClearSchedule")
async def get_auto_clear_schedule(
    store_id: int = Query(None, description="门店ID"),
    room_id: int = Query(None, description="房间ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取自动清洁计划"""
    return {
        "message": "获取自动清洁计划",
        "store_id": store_id,
        "room_id": room_id
    }


@router.post("/updateAutoClearSchedule")
async def update_auto_clear_schedule(
    schedule_id: int,
    frequency: str,
    scheduled_time: str,
    task_type: str,
    db: AsyncSession = Depends(get_db)
):
    """更新自动清洁计划"""
    return {
        "message": "更新自动清洁计划",
        "schedule_id": schedule_id,
        "frequency": frequency,
        "scheduled_time": scheduled_time,
        "task_type": task_type
    }


@router.delete("/deleteAutoClearSchedule")
async def delete_auto_clear_schedule(
    schedule_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除自动清洁计划"""
    return {"message": "删除自动清洁计划", "schedule_id": schedule_id}


@router.get("/getClearTaskReminders")
async def get_clear_task_reminders(
    store_id: int = Query(None, description="门店ID"),
    days_ahead: int = Query(7, description="提前天数"),
    db: AsyncSession = Depends(get_db)
):
    """获取清洁任务提醒"""
    return {
        "message": "获取清洁任务提醒",
        "store_id": store_id,
        "days_ahead": days_ahead
    }


@router.post("/sendClearTaskNotification")
async def send_clear_task_notification(
    task_id: int,
    notification_type: str,
    recipients: str,
    db: AsyncSession = Depends(get_db)
):
    """发送清洁任务通知"""
    return {
        "message": "发送清洁任务通知",
        "task_id": task_id,
        "notification_type": notification_type,
        "recipients": recipients
    }


@router.get("/getClearTaskReport")
async def get_clear_task_report(
    store_id: int = Query(None, description="门店ID"),
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    format: str = Query("pdf", description="报告格式"),
    db: AsyncSession = Depends(get_db)
):
    """获取清洁任务报告"""
    return {
        "message": "获取清洁任务报告",
        "store_id": store_id,
        "start_date": start_date,
        "end_date": end_date,
        "format": format
    }


@router.get("/getClearTaskEfficiency")
async def get_clear_task_efficiency(
    store_id: int = Query(None, description="门店ID"),
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    db: AsyncSession = Depends(get_db)
):
    """获取清洁任务效率"""
    return {
        "message": "获取清洁任务效率",
        "store_id": store_id,
        "start_date": start_date,
        "end_date": end_date
    }


@router.get("/getClearTaskQuality")
async def get_clear_task_quality(
    store_id: int = Query(None, description="门店ID"),
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    db: AsyncSession = Depends(get_db)
):
    """获取清洁任务质量"""
    return {
        "message": "获取清洁任务质量",
        "store_id": store_id,
        "start_date": start_date,
        "end_date": end_date
    }
