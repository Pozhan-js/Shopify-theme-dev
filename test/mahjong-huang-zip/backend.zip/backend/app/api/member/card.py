"""会员卡API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/getCardPage")
async def get_card_page(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    status: str = Query(None, description="状态"),
    db: AsyncSession = Depends(get_db)
):
    """获取会员卡分页"""
    return {"message": "获取会员卡分页", "page": page, "size": size, "status": status}


@router.get("/getById")
async def get_card_by_id(
    card_id: int = Query(..., description="会员卡ID"),
    db: AsyncSession = Depends(get_db)
):
    """根据ID获取会员卡"""
    return {"message": "根据ID获取会员卡", "card_id": card_id}


@router.post("/putCard")
async def put_card(
    id: int,
    db: AsyncSession = Depends(get_db)
):
    """领取会员卡"""
    return {"message": "领取会员卡", "id": id}


@router.get("/getAdminByCardId")
async def get_admin_by_card_id(
    card_id: int = Query(..., description="会员卡ID"),
    db: AsyncSession = Depends(get_db)
):
    """管理员获取会员卡"""
    return {"message": "管理员获取会员卡", "card_id": card_id}


@router.post("/saveAdminByCardId")
async def save_admin_by_card_id(
    card_id: int,
    num: int,
    end_time: str,
    active_name: str,
    db: AsyncSession = Depends(get_db)
):
    """管理员保存会员卡"""
    return {
        "message": "管理员保存会员卡",
        "card_id": card_id,
        "num": num,
        "end_time": end_time,
        "active_name": active_name
    }


@router.post("/stopActive")
async def stop_active(
    card_id: int,
    db: AsyncSession = Depends(get_db)
):
    """停止活动"""
    return {"message": "停止活动", "card_id": card_id}


@router.delete("/deleteCard")
async def delete_card(
    card_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除会员卡"""
    return {"message": "删除会员卡", "card_id": card_id}


@router.get("/getAdminCardByAdmin")
async def get_admin_card_by_admin(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """管理员获取会员卡列表"""
    return {"message": "管理员获取会员卡列表", "page": page, "size": size}


@router.post("/giftCard")
async def gift_card(
    user_id: int,
    card_id: int,
    db: AsyncSession = Depends(get_db)
):
    """赠送会员卡"""
    return {"message": "赠送会员卡", "user_id": user_id, "card_id": card_id}


@router.get("/getCardDetail/{card_id}")
async def get_card_detail(
    card_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取会员卡详情"""
    return {"message": "获取会员卡详情", "card_id": card_id}


@router.post("/saveCardDetail")
async def save_card_detail(
    name: str,
    description: str,
    price: float,
    duration: int,
    benefits: str,
    start_time: str,
    end_time: str,
    db: AsyncSession = Depends(get_db)
):
    """保存会员卡详情"""
    return {
        "message": "保存会员卡详情",
        "name": name,
        "description": description,
        "price": price,
        "duration": duration,
        "benefits": benefits,
        "start_time": start_time,
        "end_time": end_time
    }


@router.post("/cardActive/saveAdminByCardId")
async def save_admin_card(
    card_id: int,
    num: int,
    end_time: str,
    active_name: str,
    db: AsyncSession = Depends(get_db)
):
    """保存管理员会员卡"""
    return {
        "message": "保存管理员会员卡",
        "card_id": card_id,
        "num": num,
        "end_time": end_time,
        "active_name": active_name
    }


@router.get("/cardActive/getAdminByCardId")
async def get_admin_card(
    card_id: int = Query(..., description="会员卡ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取管理员会员卡"""
    return {"message": "获取管理员会员卡", "card_id": card_id}


@router.post("/cardActive/putCard")
async def put_card_active(
    id: int,
    db: AsyncSession = Depends(get_db)
):
    """领取会员卡活动"""
    return {"message": "领取会员卡活动", "id": id}


@router.get("/cardActive/getById")
async def get_card_active_by_id(
    card_id: int = Query(..., description="会员卡ID"),
    db: AsyncSession = Depends(get_db)
):
    """根据ID获取会员卡活动"""
    return {"message": "根据ID获取会员卡活动", "card_id": card_id}


@router.post("/cardActive/stopActive")
async def stop_card_active(
    card_id: int,
    db: AsyncSession = Depends(get_db)
):
    """停止会员卡活动"""
    return {"message": "停止会员卡活动", "card_id": card_id}
