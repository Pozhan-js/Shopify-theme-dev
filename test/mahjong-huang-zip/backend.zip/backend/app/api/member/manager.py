"""管理员操作API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/getManagerPage")
async def get_manager_page(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    keyword: str = Query(None, description="搜索关键词"),
    db: AsyncSession = Depends(get_db)
):
    """获取管理员分页"""
    return {"message": "获取管理员分页", "page": page, "size": size, "keyword": keyword}


@router.get("/getById")
async def get_manager_by_id(
    manager_id: int = Query(..., description="管理员ID"),
    db: AsyncSession = Depends(get_db)
):
    """根据ID获取管理员"""
    return {"message": "根据ID获取管理员", "manager_id": manager_id}


@router.post("/saveManager")
async def save_manager(
    name: str,
    phone: str,
    email: str,
    role: str,
    store_ids: str,
    db: AsyncSession = Depends(get_db)
):
    """保存管理员"""
    return {
        "message": "保存管理员",
        "name": name,
        "phone": phone,
        "email": email,
        "role": role,
        "store_ids": store_ids
    }


@router.post("/updateManager")
async def update_manager(
    manager_id: int,
    name: str,
    phone: str,
    email: str,
    role: str,
    store_ids: str,
    db: AsyncSession = Depends(get_db)
):
    """更新管理员"""
    return {
        "message": "更新管理员",
        "manager_id": manager_id,
        "name": name,
        "phone": phone,
        "email": email,
        "role": role,
        "store_ids": store_ids
    }


@router.delete("/deleteManager")
async def delete_manager(
    manager_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除管理员"""
    return {"message": "删除管理员", "manager_id": manager_id}


@router.post("/resetPassword")
async def reset_password(
    manager_id: int,
    new_password: str,
    db: AsyncSession = Depends(get_db)
):
    """重置管理员密码"""
    return {"message": "重置管理员密码", "manager_id": manager_id, "new_password": new_password}


@router.get("/getManagerStores")
async def get_manager_stores(
    manager_id: int = Query(..., description="管理员ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取管理员管理的门店"""
    return {"message": "获取管理员管理的门店", "manager_id": manager_id}


@router.post("/assignStores")
async def assign_stores(
    manager_id: int,
    store_ids: str,
    db: AsyncSession = Depends(get_db)
):
    """分配门店给管理员"""
    return {"message": "分配门店给管理员", "manager_id": manager_id, "store_ids": store_ids}


@router.get("/getManagerRoles")
async def get_manager_roles(
    db: AsyncSession = Depends(get_db)
):
    """获取管理员角色列表"""
    return {"message": "获取管理员角色列表"}


@router.post("/toggleManagerStatus")
async def toggle_manager_status(
    manager_id: int,
    status: int,
    db: AsyncSession = Depends(get_db)
):
    """切换管理员状态"""
    return {"message": "切换管理员状态", "manager_id": manager_id, "status": status}


@router.get("/getManagerPermissions")
async def get_manager_permissions(
    manager_id: int = Query(..., description="管理员ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取管理员权限"""
    return {"message": "获取管理员权限", "manager_id": manager_id}


@router.post("/updateManagerPermissions")
async def update_manager_permissions(
    manager_id: int,
    permissions: str,
    db: AsyncSession = Depends(get_db)
):
    """更新管理员权限"""
    return {"message": "更新管理员权限", "manager_id": manager_id, "permissions": permissions}


@router.get("/getManagerLogs")
async def get_manager_logs(
    manager_id: int = Query(..., description="管理员ID"),
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取管理员操作日志"""
    return {"message": "获取管理员操作日志", "manager_id": manager_id, "page": page, "size": size}


@router.post("/loginAsManager")
async def login_as_manager(
    username: str,
    password: str,
    db: AsyncSession = Depends(get_db)
):
    """管理员登录"""
    return {"message": "管理员登录", "username": username, "password": password}


@router.post("/logoutManager")
async def logout_manager(
    manager_id: int,
    db: AsyncSession = Depends(get_db)
):
    """管理员登出"""
    return {"message": "管理员登出", "manager_id": manager_id}


@router.get("/getCurrentManager")
async def get_current_manager(
    db: AsyncSession = Depends(get_db)
):
    """获取当前登录的管理员信息"""
    return {"message": "获取当前登录的管理员信息"}


@router.post("/changeManagerPassword")
async def change_manager_password(
    old_password: str,
    new_password: str,
    db: AsyncSession = Depends(get_db)
):
    """修改管理员密码"""
    return {"message": "修改管理员密码", "old_password": old_password, "new_password": new_password}


@router.get("/getManagerDashboard")
async def get_manager_dashboard(
    manager_id: int = Query(..., description="管理员ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取管理员仪表盘数据"""
    return {"message": "获取管理员仪表盘数据", "manager_id": manager_id}


@router.get("/getManagerStats")
async def get_manager_stats(
    manager_id: int = Query(..., description="管理员ID"),
    start_date: str = Query(..., description="开始日期"),
    end_date: str = Query(..., description="结束日期"),
    db: AsyncSession = Depends(get_db)
):
    """获取管理员统计数据"""
    return {
        "message": "获取管理员统计数据",
        "manager_id": manager_id,
        "start_date": start_date,
        "end_date": end_date
    }
