"""会员认证API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional

from app.core.database import get_db
from app.models.user import User
from app.services.user_service import UserService

router = APIRouter()


@router.post("/wxLoginByCode")
async def wx_login_by_code(code: str, db: AsyncSession = Depends(get_db)):
    """微信登录 - 通过code"""
    return {"message": "微信登录接口", "code": code}


@router.post("/weixin-mini-app-login")
async def weixin_mini_app_login(
    code: str,
    encrypted_data: str,
    iv: str,
    db: AsyncSession = Depends(get_db)
):
    """微信小程序登录"""
    return {
        "message": "微信小程序登录",
        "code": code,
        "encrypted_data": encrypted_data,
        "iv": iv
    }


@router.post("/login")
async def member_login(
    username: str,
    password: str,
    db: AsyncSession = Depends(get_db)
):
    """会员登录"""
    return {"message": "会员登录", "username": username}


@router.post("/logout")
async def member_logout(
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    """会员登出"""
    return {"message": "登出成功"}
