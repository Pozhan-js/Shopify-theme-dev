"""首页API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/getCityList")
async def get_city_list(db: AsyncSession = Depends(get_db)):
    """获取城市列表"""
    return {"message": "获取城市列表"}


@router.get("/getStoreList")
async def get_store_list(
    city_name: str = Query(None, description="城市名称"),
    db: AsyncSession = Depends(get_db)
):
    """获取门店列表"""
    return {"message": "获取门店列表", "city_name": city_name}


@router.get("/getRoomInfoList")
async def get_room_info_list(
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取房间信息列表"""
    return {"message": "获取房间信息列表", "store_id": store_id}


@router.get("/getRoomInfo/{room_id}")
async def get_room_info(
    room_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取房间信息详情"""
    return {"message": "获取房间信息详情", "room_id": room_id}


@router.get("/getStoreInfo/{store_id}")
async def get_store_info(
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取门店信息详情"""
    return {"message": "获取门店信息详情", "store_id": store_id}


@router.get("/getBannerList")
async def get_banner_list(db: AsyncSession = Depends(get_db)):
    """获取轮播图列表"""
    return {"message": "获取轮播图列表"}


@router.get("/getGamePage")
async def get_game_page(
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取游戏分页"""
    return {"message": "获取游戏分页", "page": page, "size": size}


@router.post("/join/{game_id}")
async def join_game(
    game_id: int,
    user_id: int,
    db: AsyncSession = Depends(get_db)
):
    """加入游戏"""
    return {"message": "加入游戏", "game_id": game_id, "user_id": user_id}


@router.delete("/deleteUser/{game_id}/{user_id}")
async def delete_user_from_game(
    game_id: int,
    user_id: int,
    db: AsyncSession = Depends(get_db)
):
    """从游戏中删除用户"""
    return {"message": "删除用户", "game_id": game_id, "user_id": user_id}


@router.get("/getSysInfo")
async def get_sys_info(db: AsyncSession = Depends(get_db)):
    """获取系统信息"""
    return {"message": "获取系统信息"}
