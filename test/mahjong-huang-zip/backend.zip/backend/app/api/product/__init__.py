"""商品相关API模块"""
from fastapi import APIRouter

from .product import router as product_router
from .category import router as category_router
from .order import router as product_order_router

# 创建商品API路由
product_router = APIRouter()

# 商品相关
product_router.include_router(product_router, prefix="/store-product", tags=["商品"])

# 分类相关
product_router.include_router(category_router, prefix="/category", tags=["商品分类"])

# 订单相关
product_router.include_router(product_order_router, prefix="/order", tags=["商品订单"])
