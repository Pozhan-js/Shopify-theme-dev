"""商品分类API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/list")
async def get_category_list(
    store_id: int = Query(None, description="门店ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取分类列表"""
    return {"message": "获取分类列表", "store_id": store_id}


@router.post("/create")
async def create_category(
    name: str,
    store_id: int,
    sort: int = 0,
    db: AsyncSession = Depends(get_db)
):
    """创建分类"""
    return {"message": "创建分类", "name": name, "store_id": store_id, "sort": sort}


@router.put("/update")
async def update_category(
    id: int,
    name: str,
    sort: int,
    db: AsyncSession = Depends(get_db)
):
    """更新分类"""
    return {"message": "更新分类", "id": id, "name": name, "sort": sort}


@router.delete("/delete/{category_id}")
async def delete_category(
    category_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除分类"""
    return {"message": "删除分类", "category_id": category_id}
