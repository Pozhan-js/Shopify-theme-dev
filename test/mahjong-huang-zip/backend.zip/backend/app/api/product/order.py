"""商品订单API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/page")
async def get_product_order_page(
    store_id: int = Query(..., description="门店ID"),
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    status: str = Query(None, description="订单状态"),
    db: AsyncSession = Depends(get_db)
):
    """获取商品订单分页"""
    return {
        "message": "获取商品订单分页",
        "store_id": store_id,
        "page": page,
        "size": size,
        "status": status
    }


@router.get("/manage/page")
async def get_product_order_manage_page(
    store_id: int = Query(..., description="门店ID"),
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取商品订单管理分页"""
    return {
        "message": "获取商品订单管理分页",
        "store_id": store_id,
        "page": page,
        "size": size
    }


@router.get("/info/{order_id}")
async def get_product_order_info(
    order_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取商品订单详情"""
    return {"message": "获取商品订单详情", "order_id": order_id}


@router.post("/create")
async def create_product_order(
    product_id: int,
    quantity: int,
    store_id: int,
    db: AsyncSession = Depends(get_db)
):
    """创建商品订单"""
    return {
        "message": "创建商品订单",
        "product_id": product_id,
        "quantity": quantity,
        "store_id": store_id
    }


@router.post("/pay/{order_id}")
async def pay_product_order(
    order_id: int,
    db: AsyncSession = Depends(get_db)
):
    """支付商品订单"""
    return {"message": "支付商品订单", "order_id": order_id}


@router.post("/cancel/{order_id}")
async def cancel_product_order(
    order_id: int,
    db: AsyncSession = Depends(get_db)
):
    """取消商品订单"""
    return {"message": "取消商品订单", "order_id": order_id}


@router.post("/finish/{order_id}")
async def finish_product_order(
    order_id: int,
    db: AsyncSession = Depends(get_db)
):
    """完成商品订单"""
    return {"message": "完成商品订单", "order_id": order_id}


@router.get("/getstore")
async def get_store_by_product_order(
    product_id: int = Query(..., description="商品ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取商品订单所属门店"""
    return {"message": "获取商品订单所属门店", "product_id": product_id}


@router.post("/phone/{order_id}")
async def phone_product_order(
    order_id: int,
    phone: str,
    db: AsyncSession = Depends(get_db)
):
    """商品订单电话"""
    return {"message": "商品订单电话", "order_id": order_id, "phone": phone}
