"""商品API - 匹配小程序接口"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db

router = APIRouter()


@router.get("/products")
async def get_products(
    store_id: int = Query(..., description="门店ID"),
    category_id: int = Query(None, description="分类ID"),
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    db: AsyncSession = Depends(get_db)
):
    """获取商品列表"""
    return {
        "message": "获取商品列表",
        "store_id": store_id,
        "category_id": category_id,
        "page": page,
        "size": size
    }


@router.get("/page")
async def get_product_page(
    store_id: int = Query(..., description="门店ID"),
    page: int = Query(1, description="页码"),
    size: int = Query(10, description="每页数量"),
    keyword: str = Query(None, description="搜索关键词"),
    db: AsyncSession = Depends(get_db)
):
    """获取商品分页"""
    return {
        "message": "获取商品分页",
        "store_id": store_id,
        "page": page,
        "size": size,
        "keyword": keyword
    }


@router.get("/info/{product_id}")
async def get_product_info(
    product_id: int,
    db: AsyncSession = Depends(get_db)
):
    """获取商品详情"""
    return {"message": "获取商品详情", "product_id": product_id}


@router.post("/create")
async def create_product(
    name: str,
    price: float,
    store_id: int,
    category_id: int,
    description: str = None,
    db: AsyncSession = Depends(get_db)
):
    """创建商品"""
    return {
        "message": "创建商品",
        "name": name,
        "price": price,
        "store_id": store_id,
        "category_id": category_id,
        "description": description
    }


@router.put("/update/{product_id}")
async def update_product(
    product_id: int,
    name: str,
    price: float,
    description: str = None,
    db: AsyncSession = Depends(get_db)
):
    """更新商品"""
    return {
        "message": "更新商品",
        "product_id": product_id,
        "name": name,
        "price": price,
        "description": description
    }


@router.delete("/delete/{product_id}")
async def delete_product(
    product_id: int,
    db: AsyncSession = Depends(get_db)
):
    """删除商品"""
    return {"message": "删除商品", "product_id": product_id}


@router.post("/sale/{product_id}")
async def sale_product(
    product_id: int,
    status: str,
    db: AsyncSession = Depends(get_db)
):
    """商品上下架"""
    return {"message": "商品上下架", "product_id": product_id, "status": status}


@router.get("/getstore")
async def get_store_by_product(
    product_id: int = Query(..., description="商品ID"),
    db: AsyncSession = Depends(get_db)
):
    """获取商品所属门店"""
    return {"message": "获取商品所属门店", "product_id": product_id}
