"""数据库基础模型"""
from datetime import datetime
from typing import Any, Dict

from sqlalchemy import Column, DateTime, Integer, func
from sqlalchemy.ext.declarative import as_declarative, declared_attr


@as_declarative()
class Base:
    """所有模型的基类"""
    
    id: Any
    __name__: str
    
    # 自动生成表名
    @declared_attr
    def __tablename__(cls) -> str:
        return cls.__name__.lower()
    
    # 创建时间
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # 更新时间
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    
    # 删除时间（软删除）
    deleted_at = Column(DateTime(timezone=True), nullable=True)
    
    # 版本号（乐观锁）
    version = Column(Integer, default=1, nullable=False)
    
    def to_dict(self) -> Dict[str, Any]:
        """将模型转换为字典"""
        return {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }
    
    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}(id={self.id})>"
