"""订单模型"""
from datetime import datetime
from enum import Enum
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, Float, JSON, ForeignKey, Enum as SQLEnum
from sqlalchemy.orm import relationship

from .base import Base


class OrderStatus(str, Enum):
    """订单状态枚举"""
    PENDING = "pending"  # 待支付
    PAID = "paid"  # 已支付
    IN_USE = "in_use"  # 使用中
    COMPLETED = "completed"  # 已完成
    CANCELLED = "cancelled"  # 已取消
    REFUNDED = "refunded"  # 已退款
    EXPIRED = "expired"  # 已过期


class OrderType(str, Enum):
    """订单类型枚举"""
    HOURLY = "hourly"  # 按小时
    DAILY = "daily"  # 按天
    CUSTOM = "custom"  # 自定义


class Order(Base):
    """订单主表"""
    
    __tablename__ = "orders"
    
    # 订单信息
    order_no = Column(String(32), unique=True, index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    store_id = Column(Integer, ForeignKey("stores.id"), nullable=False)
    
    # 订单类型
    order_type = Column(SQLEnum(OrderType), default=OrderType.HOURLY)
    
    # 时间信息
    start_time = Column(DateTime(timezone=True), nullable=False)
    end_time = Column(DateTime(timezone=True), nullable=False)
    actual_start_time = Column(DateTime(timezone=True), nullable=True)
    actual_end_time = Column(DateTime(timezone=True), nullable=True)
    
    # 金额信息
    original_amount = Column(Float, nullable=False)  # 原价
    discount_amount = Column(Float, default=0)  # 优惠金额
    actual_amount = Column(Float, nullable=False)  # 实付金额
    refund_amount = Column(Float, default=0)  # 退款金额
    
    # 状态信息
    status = Column(SQLEnum(OrderStatus), default=OrderStatus.PENDING)
    
    # 设备信息
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=True)
    room_id = Column(String(50), nullable=True)
    
    # 支付信息
    payment_method = Column(String(20), nullable=True)  # wechat, alipay
    payment_time = Column(DateTime(timezone=True), nullable=True)
    transaction_id = Column(String(100), nullable=True)
    
    # 备注信息
    remark = Column(Text, nullable=True)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    user = relationship("User", back_populates="orders")
    store = relationship("Store", back_populates="orders")
    device = relationship("Device")
    items = relationship("OrderItem", back_populates="order")


class OrderItem(Base):
    """订单明细表"""
    
    __tablename__ = "order_items"
    
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False)
    
    # 商品信息
    product_id = Column(Integer, ForeignKey("products.id"), nullable=True)
    product_name = Column(String(200), nullable=False)
    product_price = Column(Float, nullable=False)
    quantity = Column(Integer, default=1)
    
    # 优惠信息
    coupon_id = Column(Integer, ForeignKey("coupons.id"), nullable=True)
    discount_amount = Column(Float, default=0)
    
    # 小计
    subtotal = Column(Float, nullable=False)
    
    # 关系
    order = relationship("Order", back_populates="items")
    product = relationship("Product")
    coupon = relationship("Coupon")
