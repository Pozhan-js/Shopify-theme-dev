"""门店模型"""
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, Float, JSON, ForeignKey
from sqlalchemy.orm import relationship

from .base import Base


class Store(Base):
    """门店信息表"""
    
    __tablename__ = "stores"
    
    # 基本信息
    name = Column(String(100), nullable=False)
    code = Column(String(50), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    
    # 联系信息
    phone = Column(String(20), nullable=True)
    email = Column(String(100), nullable=True)
    
    # 地址信息
    province = Column(String(50), nullable=True)
    city = Column(String(50), nullable=True)
    district = Column(String(50), nullable=True)
    address = Column(String(500), nullable=True)
    longitude = Column(Float, nullable=True)
    latitude = Column(Float, nullable=True)
    
    # 营业时间
    business_hours = Column(JSON, default={
        "monday": {"open": "09:00", "close": "22:00"},
        "tuesday": {"open": "09:00", "close": "22:00"},
        "wednesday": {"open": "09:00", "close": "22:00"},
        "thursday": {"open": "09:00", "close": "22:00"},
        "friday": {"open": "09:00", "close": "22:00"},
        "saturday": {"open": "09:00", "close": "22:00"},
        "sunday": {"open": "09:00", "close": "22:00"}
    })
    
    # 状态
    is_active = Column(Boolean, default=True)
    is_24h = Column(Boolean, default=False)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    config = relationship("StoreConfig", back_populates="store", uselist=False)
    devices = relationship("Device", back_populates="store")
    products = relationship("Product", back_populates="store")
    orders = relationship("Order", back_populates="store")
    bookings = relationship("Booking", back_populates="store")


class StoreConfig(Base):
    """门店配置表"""
    
    __tablename__ = "store_configs"
    
    store_id = Column(Integer, ForeignKey("stores.id"), unique=True, nullable=False)
    
    # 支付配置
    payment_config = Column(JSON, default={
        "wechat_pay": {"enabled": True, "mch_id": ""},
        "alipay": {"enabled": False, "app_id": ""}
    })
    
    # 通知配置
    notification_config = Column(JSON, default={
        "sms": {"enabled": True, "provider": "aliyun"},
        "email": {"enabled": False, "provider": "smtp"},
        "wechat": {"enabled": True, "template_ids": {}}
    })
    
    # 设备配置
    device_config = Column(JSON, default={
        "lock_brand": "ttlock",
        "camera_brand": "hikvision",
        "auto_open": True,
        "auto_close_delay": 300
    })
    
    # 预约配置
    booking_config = Column(JSON, default={
        "advance_days": 7,
        "max_booking_hours": 24,
        "min_booking_hours": 1,
        "cancel_hours": 2
    })
    
    # 价格配置
    pricing_config = Column(JSON, default={
        "base_price": 0,
        "hourly_price": 0,
        "daily_price": 0,
        "vip_discount": 0.9,
        "coupon_enabled": True
    })
    
    # 自定义设置
    custom_settings = Column(JSON, default={})
    
    # 关系
    store = relationship("Store", back_populates="config")
