"""预约模型"""
from datetime import datetime
from enum import Enum
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, Float, JSON, ForeignKey
from sqlalchemy.orm import relationship

from .base import Base


class BookingStatus(str, Enum):
    """预约状态枚举"""
    PENDING = "pending"  # 待确认
    CONFIRMED = "confirmed"  # 已确认
    CHECKED_IN = "checked_in"  # 已入住
    COMPLETED = "completed"  # 已完成
    CANCELLED = "cancelled"  # 已取消
    NO_SHOW = "no_show"  # 未到店
    EXPIRED = "expired"  # 已过期


class BookingSource(str, Enum):
    """预约来源枚举"""
    WECHAT = "wechat"  # 微信小程序
    APP = "app"  # APP
    WEB = "web"  # 网站
    PHONE = "phone"  # 电话
    WALK_IN = "walk_in"  # 到店


class Booking(Base):
    """预约表"""
    
    __tablename__ = "bookings"
    
    # 基本信息
    booking_no = Column(String(32), unique=True, index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    store_id = Column(Integer, ForeignKey("stores.id"), nullable=False)
    
    # 预约信息
    product_id = Column(Integer, ForeignKey("products.id"), nullable=True)
    room_id = Column(String(50), nullable=True)
    
    # 时间信息
    scheduled_start_time = Column(DateTime(timezone=True), nullable=False)
    scheduled_end_time = Column(DateTime(timezone=True), nullable=False)
    actual_start_time = Column(DateTime(timezone=True), nullable=True)
    actual_end_time = Column(DateTime(timezone=True), nullable=True)
    
    # 人数信息
    adult_count = Column(Integer, default=1)
    child_count = Column(Integer, default=0)
    
    # 联系信息
    contact_name = Column(String(50), nullable=False)
    contact_phone = Column(String(20), nullable=False)
    
    # 来源
    source = Column(String(20), default=BookingSource.WECHAT)
    
    # 状态
    status = Column(String(20), default=BookingStatus.PENDING)
    
    # 金额信息
    estimated_amount = Column(Float, nullable=False)
    actual_amount = Column(Float, nullable=True)
    
    # 备注
    remark = Column(Text, nullable=True)
    special_requests = Column(JSON, default=[])
    
    # 签到信息
    check_in_code = Column(String(20), nullable=True)
    check_in_time = Column(DateTime(timezone=True), nullable=True)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    user = relationship("User", back_populates="bookings")
    store = relationship("Store", back_populates="bookings")
    product = relationship("Product")
