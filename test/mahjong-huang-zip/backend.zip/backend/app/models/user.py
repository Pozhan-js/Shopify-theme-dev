"""用户模型"""
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, ForeignKey, Enum
from sqlalchemy.orm import relationship

from .base import Base


class User(Base):
    """用户基础信息表"""
    
    __tablename__ = "users"
    
    # 基本信息
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=True)
    phone = Column(String(20), unique=True, index=True, nullable=True)
    
    # 微信信息
    openid = Column(String(100), unique=True, index=True, nullable=True)
    unionid = Column(String(100), unique=True, index=True, nullable=True)
    nickname = Column(String(100), nullable=True)
    avatar_url = Column(String(500), nullable=True)
    
    # 认证信息
    hashed_password = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    is_superuser = Column(Boolean, default=False)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 最后登录时间
    last_login_at = Column(DateTime(timezone=True), nullable=True)
    
    # 关系
    profile = relationship("UserProfile", back_populates="user", uselist=False)
    orders = relationship("Order", back_populates="user")
    bookings = relationship("Booking", back_populates="user")
    notifications = relationship("Notification", back_populates="user")
    user_coupons = relationship("UserCoupon", back_populates="user")
    face_records = relationship("FaceRecord", back_populates="user")


class UserProfile(Base):
    """用户详细信息表"""
    
    __tablename__ = "user_profiles"
    
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    
    # 个人信息
    real_name = Column(String(50), nullable=True)
    id_card = Column(String(18), nullable=True)
    gender = Column(String(10), nullable=True)
    birth_date = Column(DateTime, nullable=True)
    
    # 联系信息
    emergency_contact = Column(String(50), nullable=True)
    emergency_phone = Column(String(20), nullable=True)
    
    # 地址信息
    province = Column(String(50), nullable=True)
    city = Column(String(50), nullable=True)
    district = Column(String(50), nullable=True)
    address = Column(String(500), nullable=True)
    
    # 会员信息
    member_level = Column(Integer, default=0)
    member_expires_at = Column(DateTime, nullable=True)
    
    # 积分信息
    points = Column(Integer, default=0)
    total_points = Column(Integer, default=0)
    
    # 备注
    remark = Column(Text, nullable=True)
    
    # 关系
    user = relationship("User", back_populates="profile")
