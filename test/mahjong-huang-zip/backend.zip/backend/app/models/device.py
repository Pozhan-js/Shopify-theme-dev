"""设备模型"""
from datetime import datetime
from enum import Enum
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, Float, JSON, ForeignKey, Enum as SQLEnum
from sqlalchemy.orm import relationship

from .base import Base


class DeviceType(str, Enum):
    """设备类型枚举"""
    LOCK = "lock"
    CAMERA = "camera"
    SENSOR = "sensor"
    GATEWAY = "gateway"
    CONTROLLER = "controller"


class DeviceStatus(str, Enum):
    """设备状态枚举"""
    ONLINE = "online"
    OFFLINE = "offline"
    MAINTENANCE = "maintenance"
    ERROR = "error"
    DISABLED = "disabled"


class Device(Base):
    """设备信息表"""
    
    __tablename__ = "devices"
    
    # 基本信息
    name = Column(String(100), nullable=False)
    code = Column(String(50), unique=True, index=True, nullable=False)
    type = Column(SQLEnum(DeviceType), nullable=False)
    brand = Column(String(50), nullable=True)
    model = Column(String(100), nullable=True)
    
    # 设备标识
    device_id = Column(String(100), unique=True, index=True, nullable=False)
    mac_address = Column(String(17), unique=True, index=True, nullable=True)
    serial_number = Column(String(100), unique=True, nullable=True)
    
    # 位置信息
    store_id = Column(Integer, ForeignKey("stores.id"), nullable=False)
    room_id = Column(String(50), nullable=True)
    position = Column(String(200), nullable=True)
    
    # 网络配置
    ip_address = Column(String(45), nullable=True)
    gateway = Column(String(45), nullable=True)
    wifi_ssid = Column(String(100), nullable=True)
    
    # 状态信息
    status = Column(SQLEnum(DeviceStatus), default=DeviceStatus.OFFLINE)
    battery_level = Column(Integer, nullable=True)  # 电池电量百分比
    signal_strength = Column(Integer, nullable=True)  # 信号强度
    
    # 配置信息
    config = Column(JSON, default={})
    capabilities = Column(JSON, default=[])
    
    # 固件信息
    firmware_version = Column(String(50), nullable=True)
    last_update = Column(DateTime(timezone=True), nullable=True)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    store = relationship("Store", back_populates="devices")
    logs = relationship("DeviceLog", back_populates="device")


class DeviceStatus(Base):
    """设备状态历史表"""
    
    __tablename__ = "device_statuses"
    
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    
    # 状态信息
    status = Column(SQLEnum(DeviceStatus), nullable=False)
    battery_level = Column(Integer, nullable=True)
    signal_strength = Column(Integer, nullable=True)
    
    # 额外数据
    data = Column(JSON, default={})
    
    # 记录时间
    recorded_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # 关系
    device = relationship("Device")


class DeviceLog(Base):
    """设备日志表"""
    
    __tablename__ = "device_logs"
    
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    
    # 日志信息
    level = Column(String(20), nullable=False)  # DEBUG, INFO, WARN, ERROR
    message = Column(Text, nullable=False)
    action = Column(String(50), nullable=True)  # 操作类型
    result = Column(String(50), nullable=True)  # 操作结果
    
    # 详细数据
    request_data = Column(JSON, default={})
    response_data = Column(JSON, default={})
    error_info = Column(Text, nullable=True)
    
    # 操作者信息
    operator_type = Column(String(20), nullable=True)  # user, system, admin
    operator_id = Column(Integer, nullable=True)
    
    # 关系
    device = relationship("Device", back_populates="logs")
