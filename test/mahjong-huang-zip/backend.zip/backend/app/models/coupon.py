"""优惠券模型"""
from datetime import datetime
from enum import Enum
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, Float, JSON, ForeignKey
from sqlalchemy.orm import relationship

from .base import Base


class CouponType(str, Enum):
    """优惠券类型枚举"""
    DISCOUNT = "discount"  # 折扣券
    CASH = "cash"  # 现金券
    FREE = "free"  # 免费券


class CouponStatus(str, Enum):
    """优惠券状态枚举"""
    ACTIVE = "active"  # 有效
    INACTIVE = "inactive"  # 无效
    EXPIRED = "expired"  # 已过期
    USED = "used"  # 已使用


class CouponScope(str, Enum):
    """优惠券适用范围枚举"""
    ALL = "all"  # 全场通用
    CATEGORY = "category"  # 指定分类
    PRODUCT = "product"  # 指定商品
    STORE = "store"  # 指定门店


class Coupon(Base):
    """优惠券表"""
    
    __tablename__ = "coupons"
    
    # 基本信息
    name = Column(String(100), nullable=False)
    code = Column(String(50), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    
    # 优惠券类型
    type = Column(String(20), default=CouponType.DISCOUNT)
    
    # 优惠内容
    discount_value = Column(Float, nullable=False)  # 折扣值或金额
    discount_type = Column(String(20), default="percentage")  # percentage, fixed
    
    # 使用条件
    min_amount = Column(Float, default=0)  # 最低消费金额
    max_discount = Column(Float, nullable=True)  # 最大优惠金额
    
    # 适用范围
    scope = Column(String(20), default=CouponScope.ALL)
    scope_values = Column(JSON, default=[])  # 适用的具体值
    
    # 有效期
    start_date = Column(DateTime(timezone=True), nullable=False)
    end_date = Column(DateTime(timezone=True), nullable=False)
    
    # 发放数量
    total_quantity = Column(Integer, nullable=True)  # 总数量（null表示不限）
    used_quantity = Column(Integer, default=0)  # 已使用数量
    per_user_limit = Column(Integer, default=1)  # 每人限领
    
    # 状态
    status = Column(String(20), default=CouponStatus.ACTIVE)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    user_coupons = relationship("UserCoupon", back_populates="coupon")


class UserCoupon(Base):
    """用户优惠券表"""
    
    __tablename__ = "user_coupons"
    
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    coupon_id = Column(Integer, ForeignKey("coupons.id"), nullable=False)
    
    # 领取信息
    received_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # 使用信息
    used_at = Column(DateTime(timezone=True), nullable=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=True)
    
    # 状态
    status = Column(String(20), default=CouponStatus.ACTIVE)
    
    # 过期时间
    expires_at = Column(DateTime(timezone=True), nullable=False)
    
    # 关系
    user = relationship("User", back_populates="user_coupons")
    coupon = relationship("Coupon", back_populates="user_coupons")
    order = relationship("Order")
