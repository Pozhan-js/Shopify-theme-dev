"""支付模型"""
from datetime import datetime
from enum import Enum
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, Float, JSON, ForeignKey
from sqlalchemy.orm import relationship

from .base import Base


class PaymentMethod(str, Enum):
    """支付方式枚举"""
    WECHAT = "wechat"  # 微信支付
    ALIPAY = "alipay"  # 支付宝
    UNIONPAY = "unionpay"  # 银联
    CASH = "cash"  # 现金
    BALANCE = "balance"  # 余额


class PaymentStatus(str, Enum):
    """支付状态枚举"""
    PENDING = "pending"  # 待支付
    PROCESSING = "processing"  # 处理中
    SUCCESS = "success"  # 支付成功
    FAILED = "failed"  # 支付失败
    CANCELLED = "cancelled"  # 已取消
    REFUNDED = "refunded"  # 已退款
    PARTIAL_REFUND = "partial_refund"  # 部分退款


class PaymentType(str, Enum):
    """支付类型枚举"""
    ORDER = "order"  # 订单支付
    BOOKING = "booking"  # 预约支付
    RECHARGE = "recharge"  # 充值
    REFUND = "refund"  # 退款


class Payment(Base):
    """支付记录表"""
    
    __tablename__ = "payments"
    
    # 基本信息
    payment_no = Column(String(32), unique=True, index=True, nullable=False)
    order_no = Column(String(32), nullable=True)  # 关联订单号
    
    # 支付信息
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String(3), default="CNY")
    
    # 支付类型
    type = Column(String(20), default=PaymentType.ORDER)
    method = Column(String(20), nullable=False)
    
    # 状态
    status = Column(String(20), default=PaymentStatus.PENDING)
    
    # 第三方信息
    transaction_id = Column(String(100), nullable=True)  # 第三方交易号
    prepay_id = Column(String(100), nullable=True)  # 预支付ID
    
    # 支付时间
    paid_at = Column(DateTime(timezone=True), nullable=True)
    expired_at = Column(DateTime(timezone=True), nullable=True)
    
    # 退款信息
    refund_amount = Column(Float, default=0)
    refund_reason = Column(Text, nullable=True)
    refunded_at = Column(DateTime(timezone=True), nullable=True)
    
    # 手续费
    fee_amount = Column(Float, default=0)
    fee_rate = Column(Float, default=0)
    
    # 客户端信息
    client_ip = Column(String(45), nullable=True)
    user_agent = Column(String(500), nullable=True)
    
    # 回调信息
    notify_data = Column(JSON, default={})
    callback_data = Column(JSON, default={})
    
    # 错误信息
    error_code = Column(String(50), nullable=True)
    error_message = Column(Text, nullable=True)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    refunds = relationship("PaymentRefund", back_populates="payment")


class PaymentRefund(Base):
    """退款记录表"""
    
    __tablename__ = "payment_refunds"
    
    # 基本信息
    refund_no = Column(String(32), unique=True, index=True, nullable=False)
    payment_id = Column(Integer, ForeignKey("payments.id"), nullable=False)
    
    # 退款信息
    amount = Column(Float, nullable=False)
    reason = Column(Text, nullable=False)
    
    # 第三方信息
    refund_id = Column(String(100), nullable=True)  # 第三方退款号
    
    # 状态
    status = Column(String(20), default=PaymentStatus.PENDING)
    
    # 时间
    processed_at = Column(DateTime(timezone=True), nullable=True)
    
    # 错误信息
    error_code = Column(String(50), nullable=True)
    error_message = Column(Text, nullable=True)
    
    # 操作者
    operator_type = Column(String(20), nullable=True)  # user, admin, system
    operator_id = Column(Integer, nullable=True)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    payment = relationship("Payment", back_populates="refunds")
