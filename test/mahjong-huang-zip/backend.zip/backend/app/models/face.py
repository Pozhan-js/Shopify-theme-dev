"""人脸识别模型"""
from datetime import datetime
from enum import Enum
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, Float, JSON, ForeignKey
from sqlalchemy.orm import relationship

from .base import Base


class FaceRecordType(str, Enum):
    """人脸记录类型枚举"""
    CHECK_IN = "check_in"  # 入住
    CHECK_OUT = "check_out"  # 退房
    ACCESS = "access"  # 门禁
    VISITOR = "visitor"  # 访客


class FaceRecordStatus(str, Enum):
    """人脸记录状态枚举"""
    SUCCESS = "success"  # 成功
    FAILED = "failed"  # 失败
    PENDING = "pending"  # 待处理


class FaceRecord(Base):
    """人脸记录表"""
    
    __tablename__ = "face_records"
    
    # 基本信息
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    store_id = Column(Integer, ForeignKey("stores.id"), nullable=False)
    
    # 记录类型
    type = Column(String(20), default=FaceRecordType.ACCESS)
    
    # 设备信息
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=True)
    device_code = Column(String(50), nullable=True)
    
    # 人脸信息
    face_id = Column(String(100), nullable=True)
    face_data = Column(JSON, default={})
    confidence = Column(Float, nullable=True)  # 置信度
    
    # 图片信息
    image_url = Column(String(500), nullable=True)
    image_path = Column(String(500), nullable=True)
    
    # 位置信息
    location = Column(String(200), nullable=True)
    longitude = Column(Float, nullable=True)
    latitude = Column(Float, nullable=True)
    
    # 状态
    status = Column(String(20), default=FaceRecordStatus.SUCCESS)
    
    # 识别结果
    result = Column(JSON, default={})
    error_message = Column(Text, nullable=True)
    
    # 时间
    recorded_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    user = relationship("User", back_populates="face_records")


class FaceBlacklist(Base):
    """人脸黑名单表"""
    
    __tablename__ = "face_blacklists"
    
    # 基本信息
    name = Column(String(100), nullable=False)
    id_card = Column(String(18), nullable=True)
    phone = Column(String(20), nullable=True)
    
    # 人脸信息
    face_id = Column(String(100), unique=True, index=True, nullable=False)
    face_data = Column(JSON, default={})
    
    # 图片信息
    image_url = Column(String(500), nullable=True)
    image_path = Column(String(500), nullable=True)
    
    # 原因
    reason = Column(Text, nullable=True)
    remark = Column(Text, nullable=True)
    
    # 状态
    is_active = Column(Boolean, default=True)
    
    # 创建信息
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
