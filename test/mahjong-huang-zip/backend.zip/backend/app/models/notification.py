"""通知模型"""
from datetime import datetime
from enum import Enum
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, JSON, ForeignKey
from sqlalchemy.orm import relationship

from .base import Base


class NotificationType(str, Enum):
    """通知类型枚举"""
    SYSTEM = "system"  # 系统通知
    ORDER = "order"  # 订单通知
    BOOKING = "booking"  # 预约通知
    PAYMENT = "payment"  # 支付通知
    DEVICE = "device"  # 设备通知
    PROMOTION = "promotion"  # 促销通知


class NotificationChannel(str, Enum):
    """通知渠道枚举"""
    WECHAT = "wechat"  # 微信
    SMS = "sms"  # 短信
    EMAIL = "email"  # 邮件
    PUSH = "push"  # APP推送
    IN_APP = "in_app"  # 应用内


class NotificationStatus(str, Enum):
    """通知状态枚举"""
    PENDING = "pending"  # 待发送
    SENT = "sent"  # 已发送
    FAILED = "failed"  # 发送失败
    READ = "read"  # 已读


class Notification(Base):
    """通知表"""
    
    __tablename__ = "notifications"
    
    # 基本信息
    title = Column(String(200), nullable=False)
    content = Column(Text, nullable=False)
    summary = Column(String(500), nullable=True)
    
    # 通知类型
    type = Column(String(20), default=NotificationType.SYSTEM)
    channel = Column(String(20), default=NotificationChannel.WECHAT)
    
    # 接收者
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    
    # 关联业务
    business_type = Column(String(50), nullable=True)  # order, booking, payment
    business_id = Column(Integer, nullable=True)
    
    # 额外数据
    extra_data = Column(JSON, default={})
    
    # 发送状态
    status = Column(String(20), default=NotificationStatus.PENDING)
    
    # 发送时间
    scheduled_time = Column(DateTime(timezone=True), nullable=True)
    sent_time = Column(DateTime(timezone=True), nullable=True)
    read_time = Column(DateTime(timezone=True), nullable=True)
    
    # 失败信息
    error_message = Column(Text, nullable=True)
    retry_count = Column(Integer, default=0)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    user = relationship("User", back_populates="notifications")
