"""商品模型"""
from datetime import datetime
from enum import Enum
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text, Float, JSON, ForeignKey
from sqlalchemy.orm import relationship

from .base import Base


class ProductStatus(str, Enum):
    """商品状态枚举"""
    ACTIVE = "active"  # 上架
    INACTIVE = "inactive"  # 下架
    OUT_OF_STOCK = "out_of_stock"  # 缺货


class ProductType(str, Enum):
    """商品类型枚举"""
    ROOM = "room"  # 房间
    SERVICE = "service"  # 服务
    PACKAGE = "package"  # 套餐
    ADDON = "addon"  # 附加服务


class Product(Base):
    """商品信息表"""
    
    __tablename__ = "products"
    
    # 基本信息
    name = Column(String(200), nullable=False)
    code = Column(String(50), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    
    # 商品类型
    type = Column(String(20), default=ProductType.ROOM)
    category_id = Column(Integer, ForeignKey("product_categories.id"), nullable=True)
    
    # 所属门店
    store_id = Column(Integer, ForeignKey("stores.id"), nullable=False)
    
    # 价格信息
    price = Column(Float, nullable=False)
    original_price = Column(Float, nullable=True)
    cost_price = Column(Float, nullable=True)
    
    # 库存信息
    stock = Column(Integer, default=0)
    min_stock = Column(Integer, default=0)
    
    # 规格信息
    specifications = Column(JSON, default={})
    attributes = Column(JSON, default={})
    
    # 状态
    status = Column(String(20), default=ProductStatus.ACTIVE)
    sort_order = Column(Integer, default=0)
    
    # 使用信息
    max_people = Column(Integer, default=1)
    area = Column(Float, nullable=True)  # 面积（平方米）
    
    # 设备关联
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=True)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    store = relationship("Store", back_populates="products")
    category = relationship("ProductCategory")
    images = relationship("ProductImage", back_populates="product")
    order_items = relationship("OrderItem", back_populates="product")


class ProductCategory(Base):
    """商品分类表"""
    
    __tablename__ = "product_categories"
    
    # 基本信息
    name = Column(String(100), nullable=False)
    code = Column(String(50), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    
    # 层级信息
    parent_id = Column(Integer, ForeignKey("product_categories.id"), nullable=True)
    level = Column(Integer, default=1)
    path = Column(String(500), nullable=True)
    
    # 排序
    sort_order = Column(Integer, default=0)
    
    # 状态
    is_active = Column(Boolean, default=True)
    
    # 图标
    icon = Column(String(500), nullable=True)
    
    # 租户信息
    tenant_id = Column(String(50), index=True, nullable=False)
    
    # 关系
    children = relationship("ProductCategory")
    products = relationship("Product", back_populates="category")


class ProductImage(Base):
    """商品图片表"""
    
    __tablename__ = "product_images"
    
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    
    # 图片信息
    url = Column(String(500), nullable=False)
    thumbnail_url = Column(String(500), nullable=True)
    alt_text = Column(String(200), nullable=True)
    
    # 图片属性
    width = Column(Integer, nullable=True)
    height = Column(Integer, nullable=True)
    size = Column(Integer, nullable=True)  # 文件大小（字节）
    
    # 排序
    sort_order = Column(Integer, default=0)
    
    # 状态
    is_primary = Column(Boolean, default=False)
    
    # 关系
    product = relationship("Product", back_populates="images")
