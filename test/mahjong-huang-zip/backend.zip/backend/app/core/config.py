"""应用配置模块"""
from typing import List, Optional
from pydantic import BaseSettings, validator
import os


class Settings(BaseSettings):
    """应用配置类"""
    
    # 应用基本信息
    app_name: str = "无人自助系统"
    app_version: str = "1.0.0"
    debug: bool = False
    environment: str = "development"
    
    # 服务器配置
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4
    
    # 数据库配置
    database_url: str = "postgresql://user:password@localhost:5432/self_service_db"
    db_host: str = "localhost"
    db_port: int = 5432
    db_user: str = "self_service"
    db_password: str = "password"
    db_name: str = "self_service_db"
    
    # Redis配置
    redis_url: str = "redis://localhost:6379/0"
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_password: Optional[str] = None
    redis_db: int = 0
    
    # JWT配置
    secret_key: str = "your_super_secret_key_here"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 1440
    refresh_token_expire_days: int = 7
    
    # 微信小程序配置
    wechat_app_id: str = ""
    wechat_app_secret: str = ""
    wechat_mch_id: str = ""
    wechat_mch_key: str = ""
    
    # 文件上传配置
    upload_dir: str = "/app/uploads"
    max_file_size: int = 10485760  # 10MB
    allowed_extensions: List[str] = ["jpg", "jpeg", "png", "gif", "pdf"]
    
    # 日志配置
    log_level: str = "INFO"
    log_file: str = "/app/logs/app.log"
    log_rotation: str = "1 day"
    
    # 监控配置
    prometheus_port: int = 9090
    grafana_port: int = 3000
    sentry_dsn: Optional[str] = None
    
    # 消息队列配置
    celery_broker_url: str = "redis://localhost:6379/1"
    celery_result_backend: str = "redis://localhost:6379/2"
    celery_task_serializer: str = "json"
    celery_accept_content: List[str] = ["json"]
    celery_result_serializer: str = "json"
    celery_timezone: str = "Asia/Shanghai"
    
    # 邮件配置
    smtp_server: str = "smtp.gmail.com"
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    from_email: str = "noreply@yourdomain.com"
    
    # 支付配置
    alipay_app_id: str = ""
    alipay_private_key: str = ""
    alipay_public_key: str = ""
    
    # 设备配置
    lock_api_key: str = ""
    lock_api_secret: str = ""
    lock_base_url: str = "https://api.ttlock.com"
    
    # 地图配置
    baidu_map_ak: str = ""
    tencent_map_key: str = ""
    
    @validator("allowed_extensions", pre=True)
    def parse_allowed_extensions(cls, v):
        if isinstance(v, str):
            return [ext.strip() for ext in v.split(",")]
        return v
    
    @validator("celery_accept_content", pre=True)
    def parse_accept_content(cls, v):
        if isinstance(v, str):
            return [item.strip() for item in v.strip("[]").split(",")]
        return v
    
    class Config:
        env_file = ".env"
        case_sensitive = False


# 创建配置实例
settings = Settings()
