"""数据库连接配置"""
from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from .config import settings


# 数据库连接配置
DATABASE_URL = settings.database_url

# 创建异步引擎
if "postgresql" in DATABASE_URL:
    # PostgreSQL 异步连接
    async_engine = create_async_engine(
        DATABASE_URL,
        pool_pre_ping=True,
        pool_recycle=3600,
        pool_size=20,
        max_overflow=30,
        echo=settings.debug,
    )
elif "mysql" in DATABASE_URL:
    # MySQL 异步连接
    async_engine = create_async_engine(
        DATABASE_URL,
        pool_pre_ping=True,
        pool_recycle=3600,
        pool_size=20,
        max_overflow=30,
        echo=settings.debug,
    )
else:
    # SQLite 异步连接（开发环境）
    async_engine = create_async_engine(
        DATABASE_URL,
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
        echo=settings.debug,
    )

# 创建异步会话工厂
AsyncSessionLocal = sessionmaker(
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


# 同步引擎（用于 Alembic 迁移）
sync_engine = create_engine(
    DATABASE_URL.replace("postgresql+asyncpg", "postgresql"),
    pool_pre_ping=True,
    pool_recycle=3600,
    pool_size=20,
    max_overflow=30,
    echo=settings.debug,
)


async def get_db() -> AsyncSession:
    """获取数据库会话"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


async def get_db_context():
    """获取数据库会话上下文"""
    async with AsyncSessionLocal() as session:
        return session
