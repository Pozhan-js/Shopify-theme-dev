"""用户服务"""
from datetime import datetime
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models.user import User, UserProfile
from ..schemas.user import UserCreate, UserProfileCreate, UserProfileUpdate, UserUpdate


class UserService:
    """用户服务类"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create_user(self, user_data: UserCreate) -> User:
        """创建用户"""
        from passlib.context import CryptContext
        
        pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        
        # 创建用户
        user = User(
            username=user_data.username,
            email=user_data.email,
            phone=user_data.phone,
            openid=user_data.openid,
            unionid=user_data.unionid,
            nickname=user_data.nickname,
            avatar_url=user_data.avatar_url,
            hashed_password=pwd_context.hash(user_data.password) if user_data.password else None,
            tenant_id=user_data.tenant_id,
        )
        
        self.db.add(user)
        await self.db.commit()
        await self.db.refresh(user)
        
        # 创建用户资料
        profile = UserProfile(user_id=user.id)
        self.db.add(profile)
        await self.db.commit()
        
        return user
    
    async def get_user_by_id(self, user_id: int) -> Optional[User]:
        """根据ID获取用户"""
        result = await self.db.execute(select(User).where(User.id == user_id))
        return result.scalar_one_or_none()
    
    async def get_user_by_username(self, username: str, tenant_id: str) -> Optional[User]:
        """根据用户名获取用户"""
        result = await self.db.execute(
            select(User).where(
                User.username == username,
                User.tenant_id == tenant_id,
                User.deleted_at.is_(None)
            )
        )
        return result.scalar_one_or_none()
    
    async def get_user_by_phone(self, phone: str, tenant_id: str) -> Optional[User]:
        """根据手机号获取用户"""
        result = await self.db.execute(
            select(User).where(
                User.phone == phone,
                User.tenant_id == tenant_id,
                User.deleted_at.is_(None)
            )
        )
        return result.scalar_one_or_none()
    
    async def get_user_by_openid(self, openid: str, tenant_id: str) -> Optional[User]:
        """根据openid获取用户"""
        result = await self.db.execute(
            select(User).where(
                User.openid == openid,
                User.tenant_id == tenant_id,
                User.deleted_at.is_(None)
            )
        )
        return result.scalar_one_or_none()
    
    async def update_user(self, user_id: int, user_data: UserUpdate) -> Optional[User]:
        """更新用户"""
        user = await self.get_user_by_id(user_id)
        if not user:
            return None
        
        update_data = user_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(user, field, value)
        
        user.updated_at = datetime.utcnow()
        await self.db.commit()
        await self.db.refresh(user)
        
        return user
    
    async def update_last_login(self, user_id: int) -> bool:
        """更新最后登录时间"""
        user = await self.get_user_by_id(user_id)
        if not user:
            return False
        
        user.last_login_at = datetime.utcnow()
        await self.db.commit()
        return True
    
    async def delete_user(self, user_id: int) -> bool:
        """删除用户（软删除）"""
        user = await self.get_user_by_id(user_id)
        if not user:
            return False
        
        user.deleted_at = datetime.utcnow()
        await self.db.commit()
        return True
    
    async def get_user_profile(self, user_id: int) -> Optional[UserProfile]:
        """获取用户资料"""
        result = await self.db.execute(
            select(UserProfile).where(UserProfile.user_id == user_id)
        )
        return result.scalar_one_or_none()
    
    async def create_user_profile(self, profile_data: UserProfileCreate) -> UserProfile:
        """创建用户资料"""
        profile = UserProfile(**profile_data.dict())
        self.db.add(profile)
        await self.db.commit()
        await self.db.refresh(profile)
        return profile
    
    async def update_user_profile(
        self, user_id: int, profile_data: UserProfileUpdate
    ) -> Optional[UserProfile]:
        """更新用户资料"""
        profile = await self.get_user_profile(user_id)
        if not profile:
            return None
        
        update_data = profile_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(profile, field, value)
        
        await self.db.commit()
        await self.db.refresh(profile)
        
        return profile
    
    async def get_user_with_profile(self, user_id: int) -> Optional[User]:
        """获取用户及资料"""
        result = await self.db.execute(
            select(User).where(User.id == user_id).outerjoin(UserProfile)
        )
        return result.scalar_one_or_none()
    
    async def get_users_by_tenant(
        self, tenant_id: str, skip: int = 0, limit: int = 100
    ) -> list[User]:
        """获取租户下的用户列表"""
        result = await self.db.execute(
            select(User)
            .where(User.tenant_id == tenant_id, User.deleted_at.is_(None))
            .offset(skip)
            .limit(limit)
            .order_by(User.created_at.desc())
        )
        return result.scalars().all()
    
    async def get_user_count_by_tenant(self, tenant_id: str) -> int:
        """获取租户下的用户数量"""
        result = await self.db.execute(
            select(User)
            .where(User.tenant_id == tenant_id, User.deleted_at.is_(None))
            .count()
        )
        return result.scalar()
