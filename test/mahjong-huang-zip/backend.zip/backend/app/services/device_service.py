"""设备服务"""
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_

from app.models.device import Device
from app.schemas.device import DeviceCreate, DeviceUpdate


class DeviceService:
    """设备服务类"""
    
    @staticmethod
    async def create_device(db: AsyncSession, device_data: DeviceCreate) -> Device:
        """创建设备"""
        device = Device(**device_data.dict())
        db.add(device)
        await db.commit()
        await db.refresh(device)
        return device
    
    @staticmethod
    async def get_device(db: AsyncSession, device_id: int) -> Optional[Device]:
        """获取设备详情"""
        result = await db.execute(select(Device).where(Device.id == device_id))
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_devices(
        db: AsyncSession,
        skip: int = 0,
        limit: int = 100,
        store_id: Optional[int] = None,
        status: Optional[str] = None
    ) -> List[Device]:
        """获取设备列表"""
        query = select(Device).offset(skip).limit(limit)
        
        if store_id:
            query = query.where(Device.store_id == store_id)
        if status:
            query = query.where(Device.status == status)
        
        result = await db.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def update_device(
        db: AsyncSession,
        device_id: int,
        device_data: DeviceUpdate
    ) -> Optional[Device]:
        """更新设备"""
        device = await DeviceService.get_device(db, device_id)
        if not device:
            return None
        
        for field, value in device_data.dict(exclude_unset=True).items():
            setattr(device, field, value)
        
        await db.commit()
        await db.refresh(device)
        return device
    
    @staticmethod
    async def delete_device(db: AsyncSession, device_id: int) -> bool:
        """删除设备"""
        device = await DeviceService.get_device(db, device_id)
        if not device:
            return False
        
        await db.delete(device)
        await db.commit()
        return True
    
    @staticmethod
    async def unlock_device(db: AsyncSession, device_id: int) -> bool:
        """解锁设备"""
        device = await DeviceService.get_device(db, device_id)
        if not device:
            return False
        
        device.status = "unlocked"
        await db.commit()
        return True
    
    @staticmethod
    async def lock_device(db: AsyncSession, device_id: int) -> bool:
        """锁定设备"""
        device = await DeviceService.get_device(db, device_id)
        if not device:
            return False
        
        device.status = "locked"
        await db.commit()
        return True
