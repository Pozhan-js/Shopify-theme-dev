"""门店服务"""
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_

from app.models.store import Store
from app.schemas.store import StoreCreate, StoreUpdate


class StoreService:
    """门店服务类"""
    
    @staticmethod
    async def create_store(db: AsyncSession, store_data: StoreCreate) -> Store:
        """创建门店"""
        store = Store(**store_data.dict())
        db.add(store)
        await db.commit()
        await db.refresh(store)
        return store
    
    @staticmethod
    async def get_store(db: AsyncSession, store_id: int) -> Optional[Store]:
        """获取门店详情"""
        result = await db.execute(select(Store).where(Store.id == store_id))
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_stores(
        db: AsyncSession,
        skip: int = 0,
        limit: int = 100,
        status: Optional[str] = None
    ) -> List[Store]:
        """获取门店列表"""
        query = select(Store).offset(skip).limit(limit)
        
        if status:
            query = query.where(Store.status == status)
        
        result = await db.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def update_store(
        db: AsyncSession,
        store_id: int,
        store_data: StoreUpdate
    ) -> Optional[Store]:
        """更新门店"""
        store = await StoreService.get_store(db, store_id)
        if not store:
            return None
        
        for field, value in store_data.dict(exclude_unset=True).items():
            setattr(store, field, value)
        
        await db.commit()
        await db.refresh(store)
        return store
    
    @staticmethod
    async def delete_store(db: AsyncSession, store_id: int) -> bool:
        """删除门店"""
        store = await StoreService.get_store(db, store_id)
        if not store:
            return False
        
        await db.delete(store)
        await db.commit()
        return True
