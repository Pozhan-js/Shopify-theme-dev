"""任务模块"""
from .celery_app import celery_app
from .tasks import *

__all__ = ["celery_app"]
