"""通用任务"""
from loguru import logger

from .celery_app import celery_app


@celery_app.task(bind=True, max_retries=3)
def debug_task(self):
    """调试任务"""
    logger.info(f"Request: {self.request!r}")
    return {"status": "success", "message": "Debug task completed"}


@celery_app.task
def send_email(to_email: str, subject: str, body: str):
    """发送邮件"""
    try:
        # 这里实现邮件发送逻辑
        logger.info(f"Sending email to {to_email}: {subject}")
        # 实际应该使用邮件服务
        return {"status": "success", "message": f"Email sent to {to_email}"}
    except Exception as e:
        logger.error(f"Failed to send email: {e}")
        raise


@celery_app.task
def send_sms(phone: str, message: str):
    """发送短信"""
    try:
        # 这里实现短信发送逻辑
        logger.info(f"Sending SMS to {phone}: {message}")
        # 实际应该使用短信服务
        return {"status": "success", "message": f"SMS sent to {phone}"}
    except Exception as e:
        logger.error(f"Failed to send SMS: {e}")
        raise


@celery_app.task
def process_image(image_path: str, thumbnail_size: tuple = (200, 200)):
    """处理图片"""
    try:
        from PIL import Image
        
        # 打开图片
        with Image.open(image_path) as img:
            # 创建缩略图
            img.thumbnail(thumbnail_size)
            
            # 保存缩略图
            thumbnail_path = image_path.replace(".", "_thumb.")
            img.save(thumbnail_path)
            
            logger.info(f"Image processed: {thumbnail_path}")
            return {"status": "success", "thumbnail_path": thumbnail_path}
            
    except Exception as e:
        logger.error(f"Failed to process image: {e}")
        raise


@celery_app.task
def cleanup_old_files(directory: str, days: int = 7):
    """清理旧文件"""
    import os
    import time
    
    try:
        current_time = time.time()
        cutoff_time = current_time - (days * 24 * 60 * 60)
        
        deleted_count = 0
        for filename in os.listdir(directory):
            file_path = os.path.join(directory, filename)
            if os.path.isfile(file_path):
                file_time = os.path.getmtime(file_path)
                if file_time < cutoff_time:
                    os.remove(file_path)
                    deleted_count += 1
        
        logger.info(f"Cleaned up {deleted_count} old files from {directory}")
        return {"status": "success", "deleted_count": deleted_count}
        
    except Exception as e:
        logger.error(f"Failed to cleanup files: {e}")
        raise
