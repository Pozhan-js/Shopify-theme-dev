"""Celery应用配置"""
from celery import Celery
from celery.schedules import crontab

from ..core.config import settings

# 创建Celery应用
celery_app = Celery(
    "self_service",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=[
        "app.tasks.tasks",
        "app.tasks.notification_tasks",
        "app.tasks.device_tasks",
        "app.tasks.order_tasks",
    ],
)

# 配置Celery
celery_app.conf.update(
    task_serializer=settings.celery_task_serializer,
    accept_content=settings.celery_accept_content,
    result_serializer=settings.celery_result_serializer,
    timezone=settings.celery_timezone,
    enable_utc=True,
    task_track_started=True,
    task_time_limit=30 * 60,  # 30分钟
    task_soft_time_limit=25 * 60,  # 25分钟
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=1000,
)

# 定时任务配置
celery_app.conf.beat_schedule = {
    # 检查过期订单
    "check-expired-orders": {
        "task": "app.tasks.order_tasks.check_expired_orders",
        "schedule": crontab(minute="*/10"),  # 每10分钟
    },
    
    # 检查过期预约
    "check-expired-bookings": {
        "task": "app.tasks.order_tasks.check_expired_bookings",
        "schedule": crontab(minute="*/5"),  # 每5分钟
    },
    
    # 设备状态检查
    "check-device-status": {
        "task": "app.tasks.device_tasks.check_device_status",
        "schedule": crontab(minute="*/1"),  # 每分钟
    },
    
    # 清理过期通知
    "cleanup-notifications": {
        "task": "app.tasks.notification_tasks.cleanup_notifications",
        "schedule": crontab(hour=2, minute=0),  # 每天凌晨2点
    },
    
    # 生成每日报表
    "generate-daily-report": {
        "task": "app.tasks.report_tasks.generate_daily_report",
        "schedule": crontab(hour=3, minute=0),  # 每天凌晨3点
    },
}

# 任务路由
celery_app.conf.task_routes = {
    "app.tasks.notification_tasks.*": {"queue": "notifications"},
    "app.tasks.device_tasks.*": {"queue": "devices"},
    "app.tasks.order_tasks.*": {"queue": "orders"},
    "app.tasks.report_tasks.*": {"queue": "reports"},
}
