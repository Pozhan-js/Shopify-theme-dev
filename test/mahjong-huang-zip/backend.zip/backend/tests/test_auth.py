"""认证测试"""
import pytest
from httpx import AsyncClient


class TestAuth:
    """认证测试类"""
    
    def test_register_user(self, client, test_user_data):
        """测试用户注册"""
        response = client.post(
            "/api/v1/auth/register",
            json=test_user_data
        )
        assert response.status_code == 200
        data = response.json()
        assert data["username"] == test_user_data["username"]
        assert "id" in data
        assert "password" not in data
    
    def test_login_user(self, client, test_user_data):
        """测试用户登录"""
        # 先注册用户
        client.post("/api/v1/auth/register", json=test_user_data)
        
        # 测试登录
        login_data = {
            "username": test_user_data["username"],
            "password": test_user_data["password"]
        }
        response = client.post("/api/v1/auth/login", json=login_data)
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"
    
    def test_wechat_login(self, client):
        """测试微信登录"""
        wechat_data = {
            "code": "test_wechat_code",
            "encrypted_data": "test_encrypted_data",
            "iv": "test_iv"
        }
        response = client.post("/api/v1/auth/wechat/login", json=wechat_data)
        # 由于微信登录需要真实的微信code，这里只测试接口存在
        assert response.status_code in [200, 400, 422]
    
    def test_refresh_token(self, client, test_user_data):
        """测试刷新token"""
        # 先注册用户并登录
        client.post("/api/v1/auth/register", json=test_user_data)
        login_response = client.post(
            "/api/v1/auth/login",
            json={
                "username": test_user_data["username"],
                "password": test_user_data["password"]
            }
        )
        token = login_response.json()["access_token"]
        
        # 测试刷新token
        response = client.post(
            "/api/v1/auth/refresh",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
