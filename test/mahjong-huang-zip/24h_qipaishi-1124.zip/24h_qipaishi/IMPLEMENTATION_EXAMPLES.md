# 24h_qipaishi 接口实现示例

## 🎯 重点接口实现示例

### 1. member_order_info 接口实现

#### 1.1 数据模型设计

**订单信息表结构**
```sql
CREATE TABLE `member_order_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no` varchar(32) NOT NULL COMMENT '订单号',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `store_id` bigint NOT NULL COMMENT '门店ID',
  `room_id` bigint DEFAULT NULL COMMENT '房间ID',
  `order_type` tinyint NOT NULL DEFAULT '1' COMMENT '订单类型：1-房间订单 2-产品订单',
  `order_status` tinyint NOT NULL DEFAULT '1' COMMENT '订单状态：1-待支付 2-已支付 3-进行中 4-已完成 5-已取消',
  `pay_status` tinyint NOT NULL DEFAULT '1' COMMENT '支付状态：1-未支付 2-已支付 3-退款中 4-已退款',
  `total_amount` decimal(10,2) NOT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10,2) NOT NULL COMMENT '实际支付金额',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT '优惠金额',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `duration` int DEFAULT NULL COMMENT '使用时长（分钟）',
  `contact_name` varchar(50) DEFAULT NULL COMMENT '联系人姓名',
  `contact_phone` varchar(20) DEFAULT NULL COMMENT '联系人电话',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_store_id` (`store_id`),
  KEY `idx_room_id` (`room_id`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员订单信息表';
```

#### 1.2 FastAPI 实现代码

**models/member_order.py**
```python
from sqlalchemy import Column, BigInteger, String, DateTime, Decimal, Integer, Text, Boolean
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class MemberOrderInfo(Base):
    __tablename__ = "member_order_info"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True, comment='订单ID')
    order_no = Column(String(32), nullable=False, unique=True, comment='订单号')
    user_id = Column(BigInteger, nullable=False, index=True, comment='用户ID')
    store_id = Column(BigInteger, nullable=False, index=True, comment='门店ID')
    room_id = Column(BigInteger, nullable=True, index=True, comment='房间ID')
    order_type = Column(Integer, nullable=False, default=1, comment='订单类型')
    order_status = Column(Integer, nullable=False, default=1, comment='订单状态')
    pay_status = Column(Integer, nullable=False, default=1, comment='支付状态')
    total_amount = Column(Decimal(10, 2), nullable=False, comment='订单总金额')
    pay_amount = Column(Decimal(10, 2), nullable=False, comment='实际支付金额')
    discount_amount = Column(Decimal(10, 2), default=0.00, comment='优惠金额')
    start_time = Column(DateTime, nullable=True, comment='开始时间')
    end_time = Column(DateTime, nullable=True, comment='结束时间')
    duration = Column(Integer, nullable=True, comment='使用时长（分钟）')
    contact_name = Column(String(50), nullable=True, comment='联系人姓名')
    contact_phone = Column(String(20), nullable=True, comment='联系人电话')
    remark = Column(String(500), nullable=True, comment='备注')
    create_time = Column(DateTime, nullable=False, default=datetime.utcnow, comment='创建时间')
    update_time = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow, comment='更新时间')
    deleted = Column(Boolean, nullable=False, default=False, comment='是否删除')
```

**schemas/member_order.py**
```python
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from decimal import Decimal

class MemberOrderInfoResponse(BaseModel):
    id: int = Field(..., description="订单ID")
    order_no: str = Field(..., description="订单号")
    user_id: int = Field(..., description="用户ID")
    store_id: int = Field(..., description="门店ID")
    room_id: Optional[int] = Field(None, description="房间ID")
    order_type: int = Field(..., description="订单类型")
    order_status: int = Field(..., description="订单状态")
    pay_status: int = Field(..., description="支付状态")
    total_amount: Decimal = Field(..., description="订单总金额")
    pay_amount: Decimal = Field(..., description="实际支付金额")
    discount_amount: Decimal = Field(..., description="优惠金额")
    start_time: Optional[datetime] = Field(None, description="开始时间")
    end_time: Optional[datetime] = Field(None, description="结束时间")
    duration: Optional[int] = Field(None, description="使用时长（分钟）")
    contact_name: Optional[str] = Field(None, description="联系人姓名")
    contact_phone: Optional[str] = Field(None, description="联系人电话")
    remark: Optional[str] = Field(None, description="备注")
    create_time: datetime = Field(..., description="创建时间")

    class Config:
        orm_mode = True

class MemberOrderInfoCreate(BaseModel):
    store_id: int = Field(..., description="门店ID")
    room_id: Optional[int] = Field(None, description="房间ID")
    order_type: int = Field(default=1, description="订单类型")
    total_amount: Decimal = Field(..., description="订单总金额")
    start_time: Optional[datetime] = Field(None, description="开始时间")
    end_time: Optional[datetime] = Field(None, description="结束时间")
    contact_name: Optional[str] = Field(None, description="联系人姓名")
    contact_phone: Optional[str] = Field(None, description="联系人电话")
    remark: Optional[str] = Field(None, description="备注")

class MemberOrderInfoUpdate(BaseModel):
    order_status: Optional[int] = Field(None, description="订单状态")
    pay_status: Optional[int] = Field(None, description="支付状态")
    start_time: Optional[datetime] = Field(None, description="开始时间")
    end_time: Optional[datetime] = Field(None, description="结束时间")
    remark: Optional[str] = Field(None, description="备注")
```

**api/member/order.py**
```python
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_, desc
from typing import Optional, List
from datetime import datetime

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.member_order import MemberOrderInfo
from app.schemas.member_order import MemberOrderInfoResponse, MemberOrderInfoCreate, MemberOrderInfoUpdate
from app.utils.order_no import generate_order_no

router = APIRouter(prefix="/member/order", tags=["会员订单"])

@router.get("/getOrderInfo", response_model=List[MemberOrderInfoResponse])
async def get_order_info(
    user_id: Optional[int] = Query(None, description="用户ID"),
    store_id: Optional[int] = Query(None, description="门店ID"),
    room_id: Optional[int] = Query(None, description="房间ID"),
    order_status: Optional[int] = Query(None, description="订单状态"),
    pay_status: Optional[int] = Query(None, description="支付状态"),
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(10, ge=1, le=100, description="每页条数"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """获取订单信息列表"""
    query = db.query(MemberOrderInfo).filter(MemberOrderInfo.deleted == False)
    
    # 权限控制：普通用户只能查看自己的订单
    if current_user.get("user_type") == 1:  # 普通用户
        query = query.filter(MemberOrderInfo.user_id == current_user["id"])
    elif user_id:
        query = query.filter(MemberOrderInfo.user_id == user_id)
    
    if store_id:
        query = query.filter(MemberOrderInfo.store_id == store_id)
    if room_id:
        query = query.filter(MemberOrderInfo.room_id == room_id)
    if order_status:
        query = query.filter(MemberOrderInfo.order_status == order_status)
    if pay_status:
        query = query.filter(MemberOrderInfo.pay_status == pay_status)
    
    total = query.count()
    orders = query.order_by(desc(MemberOrderInfo.create_time)).offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": [MemberOrderInfoResponse.from_orm(order) for order in orders],
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/getOrderInfoByNo", response_model=MemberOrderInfoResponse)
async def get_order_info_by_no(
    order_no: str = Query(..., description="订单号"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """根据订单号获取订单详情"""
    order = db.query(MemberOrderInfo).filter(
        and_(
            MemberOrderInfo.order_no == order_no,
            MemberOrderInfo.deleted == False
        )
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    # 权限检查
    if current_user.get("user_type") == 1 and order.user_id != current_user["id"]:
        raise HTTPException(status_code=403, detail="无权查看他人订单")
    
    return MemberOrderInfoResponse.from_orm(order)

@router.post("/save", response_model=MemberOrderInfoResponse)
async def create_order(
    order_data: MemberOrderInfoCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """创建订单"""
    # 生成订单号
    order_no = generate_order_no()
    
    # 计算时长
    duration = None
    if order_data.start_time and order_data.end_time:
        duration = int((order_data.end_time - order_data.start_time).total_seconds() / 60)
    
    new_order = MemberOrderInfo(
        order_no=order_no,
        user_id=current_user["id"],
        store_id=order_data.store_id,
        room_id=order_data.room_id,
        order_type=order_data.order_type,
        total_amount=order_data.total_amount,
        pay_amount=order_data.total_amount,  # 初始支付金额等于总金额
        start_time=order_data.start_time,
        end_time=order_data.end_time,
        duration=duration,
        contact_name=order_data.contact_name,
        contact_phone=order_data.contact_phone,
        remark=order_data.remark
    )
    
    db.add(new_order)
    db.commit()
    db.refresh(new_order)
    
    return MemberOrderInfoResponse.from_orm(new_order)

@router.put("/update/{order_id}", response_model=MemberOrderInfoResponse)
async def update_order(
    order_id: int,
    order_data: MemberOrderInfoUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """更新订单"""
    order = db.query(MemberOrderInfo).filter(
        and_(
            MemberOrderInfo.id == order_id,
            MemberOrderInfo.deleted == False
        )
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    # 权限检查
    if current_user.get("user_type") == 1 and order.user_id != current_user["id"]:
        raise HTTPException(status_code=403, detail="无权修改他人订单")
    
    # 更新字段
    update_data = order_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(order, field, value)
    
    # 重新计算时长
    if order.start_time and order.end_time:
        order.duration = int((order.end_time - order.start_time).total_seconds() / 60)
    
    db.commit()
    db.refresh(order)
    
    return MemberOrderInfoResponse.from_orm(order)

@router.delete("/delete/{order_id}")
async def delete_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """删除订单（软删除）"""
    order = db.query(MemberOrderInfo).filter(
        and_(
            MemberOrderInfo.id == order_id,
            MemberOrderInfo.deleted == False
        )
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    # 权限检查
    if current_user.get("user_type") == 1 and order.user_id != current_user["id"]:
        raise HTTPException(status_code=403, detail="无权删除他人订单")
    
    order.deleted = True
    db.commit()
    
    return {"message": "订单删除成功"}
```

### 2. 用户认证接口实现示例

**api/member/auth.py**
```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.member_user import MemberUser
from app.schemas.member_auth import LoginRequest, LoginResponse
from app.core.security import create_access_token, verify_password

router = APIRouter(prefix="/member/auth", tags=["用户认证"])

@router.post("/wxLoginByCode")
async def wx_login_by_code(code: str, db: Session = Depends(get_db)):
    """微信code登录"""
    # 调用微信接口获取openid和session_key
    # 这里需要实现微信登录逻辑
    pass

@router.post("/weixin-mini-app-login", response_model=LoginResponse)
async def weixin_mini_app_login(
    login_data: dict,
    db: Session = Depends(get_db)
):
    """微信小程序登录"""
    # 实现微信小程序登录逻辑
    pass

@router.post("/login", response_model=LoginResponse)
async def login(
    login_request: LoginRequest,
    db: Session = Depends(get_db)
):
    """用户登录"""
    user = db.query(MemberUser).filter(
        MemberUser.username == login_request.username,
        MemberUser.deleted == False
    ).first()
    
    if not user or not verify_password(login_request.password, user.password):
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    
    access_token = create_access_token(data={"sub": str(user.id)})
    
    return LoginResponse(
        access_token=access_token,
        token_type="bearer",
        user_id=user.id,
        username=user.username
    )

@router.post("/logout")
async def logout(current_user: dict = Depends(get_current_user)):
    """用户退出登录"""
    # 在实际应用中，可能需要将token加入黑名单
    return {"message": "退出登录成功"}
```

### 3. 门店信息接口实现示例

**api/member/index.py**
```python
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_
from typing import Optional, List

from app.core.database import get_db
from app.models.store_info import StoreInfo
from app.schemas.store_info import StoreInfoResponse

router = APIRouter(prefix="/member/index", tags=["门店信息"])

@router.get("/getStoreList")
async def get_store_list(
    city_name: Optional[str] = Query(None, description="城市名称"),
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(10, ge=1, le=100, description="每页条数"),
    db: Session = Depends(get_db)
):
    """获取门店列表"""
    query = db.query(StoreInfo).filter(StoreInfo.status == 1, StoreInfo.deleted == False)
    
    if city_name:
        query = query.filter(StoreInfo.city_name == city_name)
    
    total = query.count()
    stores = query.offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": [StoreInfoResponse.from_orm(store) for store in stores],
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/getStoreInfo/{store_id}")
async def get_store_info(
    store_id: int,
    db: Session = Depends(get_db)
):
    """获取门店详情"""
    store = db.query(StoreInfo).filter(
        and_(
            StoreInfo.id == store_id,
            StoreInfo.status == 1,
            StoreInfo.deleted == False
        )
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店不存在")
    
    return StoreInfoResponse.from_orm(store)

@router.get("/getCityList")
async def get_city_list(db: Session = Depends(get_db)):
    """获取城市列表"""
    cities = db.query(StoreInfo.city_name).filter(
        StoreInfo.status == 1,
        StoreInfo.deleted == False
    ).distinct().all()
    
    return [city[0] for city in cities]

@router.get("/getBannerList")
async def get_banner_list(db: Session = Depends(get_db)):
    """获取轮播图列表"""
    # 实现轮播图获取逻辑
    pass

@router.get("/getRoomInfoList/{store_id}")
async def get_room_info_list(
    store_id: int,
    db: Session = Depends(get_db)
):
    """获取门店房间列表"""
    # 实现房间列表获取逻辑
    pass
```

## 📋 接口测试示例

### 测试 member_order_info 接口
```bash
# 获取订单信息
curl -X GET "http://localhost:8000/member/order/getOrderInfo?page=1&page_size=10" \
  -H "Authorization: Bearer YOUR_TOKEN"

# 根据订单号获取订单
curl -X GET "http://localhost:8000/member/order/getOrderInfoByNo?orderNo=202411240001" \
  -H "Authorization: Bearer YOUR_TOKEN"

# 创建订单
curl -X POST "http://localhost:8000/member/order/save" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "store_id": 1,
    "room_id": 5,
    "total_amount": 88.00,
    "start_time": "2024-11-24 14:00:00",
    "end_time": "2024-11-24 16:00:00",
    "contact_name": "张三",
    "contact_phone": "13800138000"
  }'
```

## 🎯 下一步实施建议

1. **按模块分批实现**：建议按用户认证→门店信息→订单管理→其他功能的顺序
2. **数据库设计**：先设计核心表结构，再逐步完善
3. **权限控制**：实现基于角色的权限控制
4. **接口文档**：使用FastAPI自动生成Swagger文档
5. **测试覆盖**：为每个接口编写单元测试