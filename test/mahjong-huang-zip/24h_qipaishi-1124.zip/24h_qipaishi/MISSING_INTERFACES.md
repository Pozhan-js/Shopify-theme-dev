# 24h_qipaishi 缺失接口分析与实现指南

## 🔍 缺失接口分析

基于微信小程序代码分析，发现以下主要接口类别需要实现：

## 📋 核心缺失接口列表

### 1. 用户认证模块
```
- /member/auth/wxLoginByCode
- /member/auth/weixin-mini-app-login  
- /member/auth/login
- /member/auth/logout
```

### 2. 用户信息管理模块
```
- /member/user/get
- /member/user/update-mobile
- /member/user/updateNickname
- /member/user/updateAvatar
- /member/user/getStoreBalance/{storeId}
- /member/user/getGiftBalanceList
- /member/user/getMoneyBillPage
- /member/user/preRechargeBalance
- /member/user/rechargeBalance
- /member/user/getCouponPage
- /member/user/getGiftBalance/{storeId}
- /member/user/saveFranchiseInfo
- /member/user/getFranchiseInfo
```

### 3. 订单管理模块
```
- /member/order/getOrderInfo
- /member/order/getOrderInfoByNo
- /member/order/getOrderPage
- /member/order/preOrder
- /member/order/lockWxOrder
- /member/order/save
- /member/order/startOrder/{orderId}
- /member/order/cancelOrder/{orderId}
- /member/order/closeOrder/{orderId}
- /member/order/renew
- /member/order/getOrderByRoomId/{roomId}
- /member/order/preGroupNo
- /member/order/getDiscountRules/{storeId}
- /member/order/openRoomDoor
- /member/order/openStoreDoor
- /member/order/getLockPwd
- /member/order/controlKT
```

### 4. 门店管理模块
```
- /member/index/getStoreList
- /member/index/getStoreInfo/{storeId}
- /member/index/getCityList
- /member/index/getBannerList
- /member/index/getSysInfo
- /member/index/getRoomInfoList
- /member/index/getRoomInfoList/{storeId}
- /member/index/getRoomInfo/{roomId}
- /member/index/getRoomList/{storeId}
```

### 5. 游戏模块
```
- /member/game/getGamePage
- /member/game/join/{gameId}
- /member/game/deleteUser/{gameId}/{userId}
- /member/game/save
```

### 6. 套餐模块
```
- /member/pkg/getPkgPage
- /member/manager/submitOrder
- /member/pkg/admin/getAdminPkgPage
- /member/pkg/admin/enable/{pkgId}
- /member/pkg/admin/delete/{id}
- /member/pkg/admin/saveAdminPkg
```

### 7. 产品模块
```
- /product/store-product/products
- /product/store-product/page
- /product/store-product/info/{productId}
- /product/store-product/create
- /product/store-product/delete/{id}
- /product/store-product/sale
- /product/category/list
- /product/category/create
- /product/category/delete/{id}
- /product/category/update
```

### 8. 产品订单模块
```
- /product/order/create
- /product/order/info/{orderId}
- /product/order/page
- /product/order/manage/page
- /product/order/cancel
- /product/order/pay/{orderId}
- /product/order/finish/{orderId}
- /product/order/phone/{orderId}
- /product/order/getstore
```

### 9. 优惠券活动模块
```
- /member/couponActive/getById
- /member/couponActive/putCoupon
- /member/couponActive/saveAdminByCouponId
- /member/couponActive/getAdminByCouponId
- /member/couponActive/stopActive
```

### 10. 管理员接口模块
```
- /member/manager/getMemberPage
- /member/manager/giftCoupon
- /member/manager/recharge
- /member/manager/getUserCouponByAdmin
- /member/manager/revokeCoupon/{couponId}
- /member/manager/getOrderPage
- /member/manager/changeOrderUser
- /member/manager/changeOrder
- /member/manager/cancelOrder/{orderId}
- /member/manager/refundOrder/{orderId}
- /member/manager/renewByAdmin
- /member/manager/depositRefund/{orderId}
- /member/manager/getYDCancelAuthList/{storeId}
- /member/manager/auditYD
- /member/manager/getAdminUserPage
- /member/manager/saveAdminUser
- /member/manager/deleteAdminUser/{storeId}/{userId}
- /member/manager/getCouponPage
- /member/manager/getCouponDetail/{couponId}
- /member/manager/saveCouponDetail
- /member/manager/deleteCoupon
- /member/manager/getPayOrderPage
- /member/manager/refundPayOrder
- /member/manager/getClearUserPage
- /member/manager/saveClearUser
- /member/manager/deleteClearUser/{storeId}/{userId}
- /member/manager/getClearManagerPage
- /member/manager/cancelClear/{id}
- /member/manager/settlementClearUser
- /member/manager/complaintClearInfo
```

### 11. 门店配置模块
```
- /member/store/getDetail/{storeId}
- /member/store/save
- /member/store/getPageList
- /member/store/getStoreListByAdmin
- /member/store/getRoomInfoList/{storeId}
- /member/store/getRoomDetail/{roomId}
- /member/store/saveRoomDetail
- /member/store/disableRoom/{roomId}
- /member/store/deleteRoomInfo/{roomId}
- /member/store/openRoomDoor/{roomId}
- /member/store/closeRoomDoor/{roomId}
- /member/store/finishRoomOrder/{roomId}
- /member/store/clearAndFinish/{roomId}
- /member/store/getRoomList/{storeId}
- /member/store/addDevice
- /member/store/delDevice/{deviceId}
- /member/store/checkBall/{deviceId}
- /member/store/getLockList/{deviceId}
- /member/store/updateRoomLock
- /member/store/getQrConfig
- /member/store/setQrConfig
- /member/store/addLock
- /member/store/getStoreSoundInfo/{storeId}
- /member/store/saveStoreSoundInfo
- /member/store/getDiscountRulesPage
- /member/store/getDiscountRuleDetail/{discountId}
- /member/store/saveDiscountRuleDetail
- /member/store/changeDiscountRulesStatus/{discountId}
- /member/store/getVipConfig/{storeId}
- /member/store/saveVipConfig
- /member/store/deleteVipConfig/{id}
- /member/store/getTemplateList
- /member/store/setTemplate
- /member/store/getPrePayConfig/{roomId}
- /member/store/setPrePayConfig
- /member/store/resetQrcode
- /member/store/setDouyinId
- /member/store/runYunlaba
- /member/store/controlKT
- /member/store/openStoreDoor/{storeId}
```

### 12. 统计分析模块
```
- /member/chart/getRevenueChart
- /member/chart/getBusinessStatistics
- /member/chart/getRevenueStatistics
- /member/chart/getOrderStatistics
- /member/chart/getMemberStatistics
- /member/chart/getRoomUseStatistics
- /member/chart/getRoomUseHour
- /member/chart/getIncomeStatistics
- /member/chart/getRechargeStatistics
```

### 13. 保洁管理模块
```
- /member/clear/getChartData
- /member/clear/getClearBillPage
- /member/clear/getClearPage
- /member/clear/getDetail/{clearId}
- /member/clear/jiedan/{id}
- /member/clear/cancel/{id}
- /member/clear/start/{id}
- /member/clear/openStoreDoor/{id}
- /member/clear/openRoomDoor/{id}
- /member/clear/finish/{id}
```

### 14. 商户模块
```
- /member/merchant-account/getApplyUrl
```

### 15. 团购模块
```
- /member/store/getGroupPayAuthUrl
```

### 16. 预约模块
```
- /reserve/push/rule
```

### 17. 人脸识别模块
```
- /member/store/getFaceRecordPage
- /member/store/moveFaceByRecord
- /member/store/moveFaceById/{id}
- /member/store/getFaceBlacklistPage
```

## 🎯 优先级实现建议

### 高优先级（核心功能）
1. **用户认证接口** - 登录注册基础功能
2. **用户信息接口** - 个人中心数据
3. **门店信息接口** - 首页展示数据
4. **订单核心接口** - 下单、查询、支付

### 中优先级（业务功能）
1. **产品管理接口** - 商品展示和购买
2. **优惠券接口** - 营销活动
3. **套餐接口** - 套餐购买
4. **门禁控制接口** - 智能门禁

### 低优先级（管理功能）
1. **管理员接口** - 后台管理
2. **统计分析接口** - 数据报表
3. **保洁管理接口** - 保洁任务
4. **高级配置接口** - 系统设置

## 📁 数据库表设计建议

基于接口分析，需要以下核心数据表：

### 用户相关表
- `member_user` - 用户表
- `member_user_balance` - 用户余额表
- `member_user_coupon` - 用户优惠券表
- `member_franchise_info` - 加盟信息表

### 门店相关表
- `store_info` - 门店信息表
- `store_room` - 房间信息表
- `store_device` - 设备信息表
- `store_config` - 门店配置表

### 订单相关表
- `order_info` - 订单主表
- `order_item` - 订单明细表
- `order_payment` - 订单支付表

### 产品相关表
- `product_info` - 产品信息表
- `product_category` - 产品分类表
- `product_order` - 产品订单表

### 优惠券相关表
- `coupon_info` - 优惠券信息表
- `coupon_active` - 优惠券活动表
- `coupon_user` - 用户优惠券表

## 🚀 实施计划

### 第一阶段（核心功能）
1. 实现用户认证相关接口
2. 实现用户信息管理接口
3. 实现门店基础信息接口
4. 实现订单核心接口

### 第二阶段（业务扩展）
1. 实现产品管理接口
2. 实现优惠券接口
3. 实现套餐接口
4. 实现门禁控制接口

### 第三阶段（管理功能）
1. 实现管理员接口
2. 实现统计分析接口
3. 实现保洁管理接口
4. 实现高级配置接口

## 📋 接口实现检查清单

- [ ] 用户认证模块 (5个接口)
- [ ] 用户信息模块 (11个接口)
- [ ] 订单管理模块 (15个接口)
- [ ] 门店管理模块 (8个接口)
- [ ] 游戏模块 (4个接口)
- [ ] 套餐模块 (6个接口)
- [ ] 产品模块 (10个接口)
- [ ] 产品订单模块 (9个接口)
- [ ] 优惠券活动模块 (5个接口)
- [ ] 管理员模块 (25个接口)
- [ ] 门店配置模块 (30个接口)
- [ ] 统计分析模块 (9个接口)
- [ ] 保洁管理模块 (9个接口)
- [ ] 商户模块 (1个接口)
- [ ] 团购模块 (1个接口)
- [ ] 预约模块 (1个接口)
- [ ] 人脸识别模块 (4个接口)

**总计需要实现：152个接口**