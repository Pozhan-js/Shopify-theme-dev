# 24h_qipaishi 微信小程序完整API接口文档

## 项目概述
- **项目名称**: 24h_qipaishi 微信小程序
- **基础路径**: `/member/` 和 `/product/` 前缀的接口
- **认证方式**: 需要登录token
- **请求方式**: 主要使用GET和POST请求

## 📋 接口总览

### 1. 用户认证相关接口

#### 1.1 登录认证
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/auth/wxLoginByCode` | GET | 微信code登录 |
| `/member/auth/weixin-mini-app-login` | POST | 微信小程序登录 |
| `/member/auth/login` | POST | 普通登录 |
| `/member/auth/logout` | POST | 退出登录 |

#### 1.2 用户信息管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/user/get` | GET | 获取用户信息 |
| `/member/user/update-mobile` | POST | 更新手机号 |
| `/member/user/updateNickname` | POST | 更新昵称 |
| `/member/user/updateAvatar` | POST | 更新头像 |
| `/member/user/saveFranchiseInfo` | POST | 保存加盟信息 |
| `/member/user/getFranchiseInfo` | GET | 获取加盟信息 |

### 2. 门店管理接口

#### 2.1 门店基础信息
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/index/getStoreList` | GET | 获取门店列表 |
| `/member/index/getStoreList?cityName={cityName}` | GET | 按城市获取门店列表 |
| `/member/index/getStoreInfo/{storeId}` | GET | 获取门店详情 |
| `/member/index/getCityList` | GET | 获取城市列表 |
| `/member/index/getBannerList` | GET | 获取轮播图列表 |
| `/member/index/getSysInfo` | GET | 获取系统信息 |

#### 2.2 房间管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/index/getRoomInfoList` | GET | 获取房间列表 |
| `/member/index/getRoomInfoList/{storeId}` | GET | 按门店获取房间列表 |
| `/member/index/getRoomInfo/{roomId}` | GET | 获取房间详情 |
| `/member/index/getRoomList/{storeId}` | GET | 获取门店房间列表 |

### 3. 订单管理接口

#### 3.1 订单基础操作
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/order/getOrderInfo` | GET | 获取订单信息 |
| `/member/order/getOrderInfoByNo` | GET | 根据订单号获取订单信息 |
| `/member/order/getOrderPage` | GET | 获取订单分页列表 |
| `/member/order/preOrder` | POST | 预创建订单 |
| `/member/order/lockWxOrder` | POST | 锁定微信订单 |
| `/member/order/save` | POST | 保存订单 |
| `/member/order/startOrder/{orderId}` | POST | 开始订单 |
| `/member/order/cancelOrder/{orderId}` | POST | 取消订单 |
| `/member/order/closeOrder/{orderId}` | POST | 关闭订单 |
| `/member/order/renew` | POST | 续费订单 |
| `/member/order/getOrderByRoomId/{roomId}` | GET | 根据房间ID获取订单 |

#### 3.2 订单支付相关
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/order/preGroupNo` | POST | 预创建团购订单号 |
| `/member/order/getDiscountRules/{storeId}` | GET | 获取折扣规则 |

#### 3.3 门禁控制
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/order/openRoomDoor` | POST | 开房间门 |
| `/member/order/openStoreDoor` | POST | 开门店门 |
| `/member/order/getLockPwd` | GET | 获取门锁密码 |
| `/member/order/controlKT` | POST | 控制空调 |

### 4. 用户资产相关接口

#### 4.1 余额管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/user/getStoreBalance/{storeId}` | GET | 获取门店余额 |
| `/member/user/getGiftBalanceList` | GET | 获取礼品余额列表 |
| `/member/user/getMoneyBillPage` | GET | 获取资金账单分页 |
| `/member/user/preRechargeBalance` | POST | 预充值余额 |
| `/member/user/rechargeBalance` | POST | 充值余额 |

#### 4.2 优惠券管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/user/getCouponPage` | GET | 获取优惠券分页列表 |
| `/member/user/getGiftBalance/{storeId}` | GET | 获取礼品余额 |

### 5. 游戏相关接口

#### 5.1 游戏管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/game/getGamePage` | GET | 获取游戏分页列表 |
| `/member/game/join/{gameId}` | POST | 加入游戏 |
| `/member/game/deleteUser/{gameId}/{userId}` | DELETE | 删除游戏用户 |
| `/member/game/save` | POST | 保存游戏信息 |

### 6. 套餐管理接口

#### 6.1 套餐操作
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/pkg/getPkgPage` | GET | 获取套餐分页列表 |
| `/member/manager/submitOrder` | POST | 管理员提交订单 |

### 7. 产品订单接口

#### 7.1 产品管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/product/store-product/products` | GET | 获取产品列表 |
| `/product/store-product/page` | GET | 获取产品分页列表 |
| `/product/store-product/info/{productId}` | GET | 获取产品详情 |
| `/product/store-product/create` | POST | 创建产品 |
| `/product/store-product/delete/{id}` | DELETE | 删除产品 |
| `/product/store-product/sale` | POST | 产品上架/下架 |

#### 7.2 产品分类
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/product/category/list` | GET | 获取分类列表 |
| `/product/category/create` | POST | 创建分类 |
| `/product/category/delete/{id}` | DELETE | 删除分类 |
| `/product/category/update` | PUT | 更新分类 |

#### 7.3 产品订单
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/product/order/create` | POST | 创建产品订单 |
| `/product/order/info/{orderId}` | GET | 获取产品订单详情 |
| `/product/order/page` | GET | 获取产品订单分页列表 |
| `/product/order/manage/page` | GET | 管理端产品订单分页 |
| `/product/order/cancel` | POST | 取消产品订单 |
| `/product/order/pay/{orderId}` | POST | 支付产品订单 |
| `/product/order/finish/{orderId}` | POST | 完成产品订单 |
| `/product/order/phone/{orderId}` | POST | 产品订单电话通知 |
| `/product/order/getstore` | GET | 获取产品订单门店信息 |

### 8. 优惠券活动接口

#### 8.1 优惠券活动管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/couponActive/getById` | GET | 根据ID获取优惠券活动 |
| `/member/couponActive/putCoupon` | POST | 领取优惠券 |
| `/member/couponActive/saveAdminByCouponId` | POST | 管理员保存优惠券活动 |
| `/member/couponActive/getAdminByCouponId` | GET | 管理员获取优惠券活动 |
| `/member/couponActive/stopActive` | POST | 停止优惠券活动 |

### 9. 商户管理接口

#### 9.1 商户账户
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/merchant-account/getApplyUrl` | GET | 获取商户申请URL |

### 10. 管理员接口

#### 10.1 用户管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/manager/getMemberPage` | GET | 获取会员分页列表 |
| `/member/manager/giftCoupon` | POST | 赠送优惠券 |
| `/member/manager/recharge` | POST | 管理员充值 |
| `/member/manager/getUserCouponByAdmin` | GET | 管理员获取用户优惠券 |
| `/member/manager/revokeCoupon/{couponId}` | DELETE | 撤销用户优惠券 |

#### 10.2 订单管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/manager/getOrderPage` | GET | 管理员获取订单分页 |
| `/member/manager/changeOrderUser` | POST | 更改订单用户 |
| `/member/manager/changeOrder` | POST | 更改订单 |
| `/member/manager/cancelOrder/{orderId}` | POST | 管理员取消订单 |
| `/member/manager/refundOrder/{orderId}` | POST | 管理员退款订单 |
| `/member/manager/renewByAdmin` | POST | 管理员续费 |
| `/member/manager/depositRefund/{orderId}` | POST | 押金退款 |
| `/member/manager/getYDCancelAuthList/{storeId}` | GET | 获取预订取消权限列表 |
| `/member/manager/auditYD` | POST | 审核预订取消 |

#### 10.3 门店管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/manager/getAdminUserPage` | GET | 获取管理员用户分页 |
| `/member/manager/saveAdminUser` | POST | 保存管理员用户 |
| `/member/manager/deleteAdminUser/{storeId}/{userId}` | DELETE | 删除管理员用户 |
| `/member/store/getStoreListByAdmin` | GET | 管理员获取门店列表 |

#### 10.4 保洁管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/manager/getClearUserPage` | GET | 获取保洁用户分页 |
| `/member/manager/saveClearUser` | POST | 保存保洁用户 |
| `/member/manager/deleteClearUser/{storeId}/{userId}` | DELETE | 删除保洁用户 |
| `/member/manager/getClearManagerPage` | GET | 获取保洁管理分页 |
| `/member/manager/cancelClear/{id}` | POST | 取消保洁 |
| `/member/manager/settlementClearUser` | POST | 保洁用户结算 |
| `/member/manager/complaintClearInfo` | POST | 投诉保洁信息 |

#### 10.5 优惠券管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/manager/getCouponPage` | GET | 获取优惠券分页 |
| `/member/manager/getCouponDetail/{couponId}` | GET | 获取优惠券详情 |
| `/member/manager/saveCouponDetail` | POST | 保存优惠券详情 |
| `/member/manager/deleteCoupon` | DELETE | 删除优惠券 |
| `/member/manager/giftCoupon` | POST | 赠送优惠券 |

#### 10.6 支付订单管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/manager/getPayOrderPage` | GET | 获取支付订单分页 |
| `/member/manager/refundPayOrder` | POST | 退款支付订单 |

### 11. 门店配置接口

#### 11.1 门店设置
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/store/getDetail/{storeId}` | GET | 获取门店详情 |
| `/member/store/save` | POST | 保存门店信息 |
| `/member/store/getPageList` | GET | 获取门店分页列表 |
| `/member/store/getStoreListByAdmin` | GET | 管理员获取门店列表 |

#### 11.2 房间管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/store/getRoomInfoList/{storeId}` | GET | 获取门店房间列表 |
| `/member/store/getRoomDetail/{roomId}` | GET | 获取房间详情 |
| `/member/store/saveRoomDetail` | POST | 保存房间详情 |
| `/member/store/disableRoom/{roomId}` | POST | 禁用房间 |
| `/member/store/deleteRoomInfo/{roomId}` | DELETE | 删除房间信息 |
| `/member/store/openRoomDoor/{roomId}` | POST | 打开房间门 |
| `/member/store/closeRoomDoor/{roomId}` | POST | 关闭房间门 |
| `/member/store/finishRoomOrder/{roomId}` | POST | 完成房间订单 |
| `/member/store/clearAndFinish/{roomId}` | POST | 清理并完成房间订单 |

#### 11.3 设备管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/store/getRoomList/{storeId}` | GET | 获取门店房间列表 |
| `/member/device/getDevicePage` | GET | 获取设备分页 |
| `/member/store/addDevice` | POST | 添加设备 |
| `/member/store/delDevice/{deviceId}` | DELETE | 删除设备 |
| `/member/store/checkBall/{deviceId}` | POST | 检查设备状态 |
| `/member/store/getLockList/{deviceId}` | GET | 获取设备锁列表 |
| `/member/store/updateRoomLock` | POST | 更新房间锁 |
| `/member/store/getQrConfig` | GET | 获取二维码配置 |
| `/member/store/setQrConfig` | POST | 设置二维码配置 |
| `/member/store/addLock` | POST | 添加门锁 |

#### 11.4 门店运营
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/store/getStoreSoundInfo/{storeId}` | GET | 获取门店声音配置 |
| `/member/store/saveStoreSoundInfo` | POST | 保存门店声音配置 |
| `/member/store/getDiscountRulesPage` | GET | 获取折扣规则分页 |
| `/member/store/getDiscountRuleDetail/{discountId}` | GET | 获取折扣规则详情 |
| `/member/store/saveDiscountRuleDetail` | POST | 保存折扣规则详情 |
| `/member/store/changeDiscountRulesStatus/{discountId}` | POST | 更改折扣规则状态 |
| `/member/store/getVipConfig/{storeId}` | GET | 获取VIP配置 |
| `/member/store/saveVipConfig` | POST | 保存VIP配置 |
| `/member/store/deleteVipConfig/{id}` | DELETE | 删除VIP配置 |
| `/member/store/getTemplateList` | GET | 获取模板列表 |
| `/member/store/setTemplate` | POST | 设置模板 |
| `/member/store/getPrePayConfig/{roomId}` | GET | 获取预付费配置 |
| `/member/store/setPrePayConfig` | POST | 设置预付费配置 |
| `/member/store/resetQrcode` | POST | 重置二维码 |
| `/member/store/setDouyinId` | POST | 设置抖音ID |
| `/member/store/runYunlaba` | POST | 运行云喇叭 |
| `/member/store/controlKT` | POST | 控制空调 |
| `/member/store/openStoreDoor/{storeId}` | POST | 打开门店门 |

#### 11.5 会员管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/store/getVipPage` | GET | 获取VIP分页 |
| `/member/store/editMemberVip` | POST | 编辑会员VIP |
| `/member/store/addMemberVip` | POST | 添加会员VIP |
| `/member/store/deleteVip` | DELETE | 删除VIP |
| `/member/store/vip/blacklist` | GET | 获取VIP黑名单 |
| `/member/store/addBlackList` | POST | 添加到黑名单 |
| `/member/store/remove/{id}` | DELETE | 从黑名单移除 |

### 12. 套餐管理接口

#### 12.1 套餐管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/pkg/getPkgPage` | GET | 获取套餐分页 |
| `/member/pkg/admin/getAdminPkgPage` | GET | 管理员获取套餐分页 |
| `/member/pkg/admin/enable/{pkgId}` | POST | 启用套餐 |
| `/member/pkg/admin/delete/{id}` | DELETE | 删除套餐 |
| `/member/pkg/admin/saveAdminPkg` | POST | 保存管理员套餐 |

### 13. 保洁管理接口

#### 13.1 保洁任务
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/clear/getChartData` | GET | 获取图表数据 |
| `/member/clear/getClearBillPage` | GET | 获取保洁账单分页 |
| `/member/clear/getClearPage` | GET | 获取保洁分页 |
| `/member/clear/getDetail/{clearId}` | GET | 获取保洁详情 |
| `/member/clear/jiedan/{id}` | POST | 保洁接单 |
| `/member/clear/cancel/{id}` | POST | 保洁取消 |
| `/member/clear/start/{id}` | POST | 保洁开始 |
| `/member/clear/openStoreDoor/{id}` | POST | 保洁打开门店门 |
| `/member/clear/openRoomDoor/{id}` | POST | 保洁打开房间门 |
| `/member/clear/finish/{id}` | POST | 保洁完成 |

### 14. 统计分析接口

#### 14.1 数据报表
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/chart/getRevenueChart` | GET | 获取收入图表 |
| `/member/chart/getBusinessStatistics` | GET | 获取营业统计 |
| `/member/chart/getRevenueStatistics` | GET | 获取收入统计 |
| `/member/chart/getOrderStatistics` | GET | 获取订单统计 |
| `/member/chart/getMemberStatistics` | GET | 获取会员统计 |
| `/member/chart/getRoomUseStatistics` | GET | 获取房间使用统计 |
| `/member/chart/getRoomUseHour` | GET | 获取房间使用小时统计 |
| `/member/chart/getIncomeStatistics` | GET | 获取收入统计 |
| `/member/chart/getRechargeStatistics` | GET | 获取充值统计 |

### 15. 团购相关接口

#### 15.1 团购管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/store/getGroupPayAuthUrl` | GET | 获取团购支付授权URL |

### 16. 预约相关接口

#### 16.1 预约管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/reserve/push/rule` | POST | 推送预约规则 |

### 17. 人脸识别接口

#### 17.1 人脸管理
| 接口地址 | 方法 | 描述 |
|---------|------|------|
| `/member/store/getFaceRecordPage` | GET | 获取人脸记录分页 |
| `/member/store/moveFaceByRecord` | POST | 根据记录移动人脸 |
| `/member/store/moveFaceById/{id}` | POST | 根据ID移动人脸 |
| `/member/store/getFaceBlacklistPage` | GET | 获取人脸黑名单分页 |

## 🔧 接口使用说明

### 请求头设置
```javascript
// 在utils/http.js中设置
const http = {
  request: function(url, method = "GET", data = {}, contentType = "application/json") {
    return new Promise((resolve, reject) => {
      wx.request({
        url: baseURL + url,
        method: method,
        data: data,
        header: {
          'Content-Type': contentType,
          'Authorization': 'Bearer ' + wx.getStorageSync('token')
        },
        success: resolve,
        fail: reject
      })
    })
  }
}
```

### 认证要求
- 大部分接口需要用户登录状态
- 管理员接口需要管理员权限
- 门店相关接口需要绑定门店权限

### 分页参数
- `page`: 页码，从1开始
- `pageSize`: 每页条数，默认10
- `currentPage`: 当前页码

### 错误处理
- 统一返回格式：`{code: 200, data: {}, message: "success"}`
- 错误码说明：
  - 200: 成功
  - 401: 未登录
  - 403: 无权限
  - 500: 服务器错误

## 📊 接口分类统计

| 分类 | 接口数量 | 主要功能 |
|------|----------|----------|
| 用户认证 | 5 | 登录、注册、退出 |
| 用户信息 | 6 | 个人信息管理 |
| 门店管理 | 8 | 门店信息、房间管理 |
| 订单管理 | 15 | 订单CRUD、支付、门禁 |
| 资产管理 | 5 | 余额、优惠券管理 |
| 游戏管理 | 4 | 游戏相关接口 |
| 套餐管理 | 4 | 套餐CRUD操作 |
| 产品管理 | 8 | 产品、分类管理 |
| 产品订单 | 8 | 产品订单管理 |
| 优惠券活动 | 5 | 优惠券活动管理 |
| 商户管理 | 1 | 商户相关接口 |
| 管理员接口 | 25 | 用户、订单、门店管理 |
| 门店配置 | 30 | 门店设置、设备管理 |
| 套餐管理 | 4 | 套餐相关接口 |
| 保洁管理 | 9 | 保洁任务管理 |
| 统计分析 | 9 | 数据报表接口 |
| 团购相关 | 1 | 团购接口 |
| 预约管理 | 1 | 预约接口 |
| 人脸识别 | 4 | 人脸管理接口 |

**总计：152个接口**