#!/usr/bin/env python3
"""
数据库初始化脚本
基于db_250815.sql创建完整的24h棋牌室数据库结构
"""

import os
import sys
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from app.core.config import settings
from app.models.complete_models import Base, MemberStoreInfo, MemberRoomInfo, MemberUser
from datetime import datetime

def init_database():
    """初始化数据库"""
    print("🚀 开始初始化24h棋牌室数据库...")
    
    # 创建数据库引擎
    engine = create_engine(settings.DATABASE_URL, echo=True)
    
    # 创建所有表
    print("📋 创建数据库表...")
    Base.metadata.create_all(bind=engine)
    print("✅ 数据库表创建完成")
    
    # 创建会话
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()
    
    try:
        # 检查是否已有数据
        store_count = db.query(MemberStoreInfo).count()
        if store_count > 0:
            print("⚠️  数据库已存在数据，跳过初始化")
            return
        
        # 初始化演示数据
        print("🎯 初始化演示数据...")
        
        # 创建演示门店
        demo_store = MemberStoreInfo(
            store_name="演示-24h棋牌室",
            city_name="成都",
            content="<p>欢迎来到24h棋牌室，提供舒适的环境和优质的服务</p>",
            head_img="https://images.scyanzu.com/demo-store.jpg",
            store_env_img="https://images.scyanzu.com/demo-env.jpg",
            banner_img="https://images.scyanzu.com/demo-banner.jpg",
            notice="<p><strong>重要提示</strong></p><p>本小程序为演示环境，数据每日自动还原！</p>",
            lat=30.657349,
            lon=104.065837,
            address="四川省成都市人民南路一段86号",
            wifi_info="CMCC-Free",
            wifi_pwd="12345678",
            kefu_phone="15675555180",
            room_num=5,
            status=0
        )
        db.add(demo_store)
        db.commit()
        
        # 创建演示房间
        demo_rooms = [
            MemberRoomInfo(
                room_name="豪华棋牌室A",
                room_call_name="棋牌A",
                room_class=0,
                store_id=demo_store.store_id,
                type=1,
                price=25.00,
                deposit=50.00,
                work_price=20.00,
                tongxiao_price=80.00,
                label="豪华装修,独立空调,免费WiFi",
                image_urls="https://images.scyanzu.com/room1.jpg,https://images.scyanzu.com/room2.jpg",
                status=1,
                min_hour=2,
                lead_hour=4,
                lead_day=7
            ),
            MemberRoomInfo(
                room_name="标准棋牌室B",
                room_call_name="棋牌B",
                room_class=0,
                store_id=demo_store.store_id,
                type=2,
                price=20.00,
                deposit=30.00,
                work_price=18.00,
                tongxiao_price=70.00,
                label="标准装修,舒适环境",
                image_urls="https://images.scyanzu.com/room3.jpg",
                status=1,
                min_hour=2,
                lead_hour=4,
                lead_day=7
            ),
            MemberRoomInfo(
                room_name="专业台球室",
                room_call_name="台球室",
                room_class=1,
                store_id=demo_store.store_id,
                type=3,
                price=30.00,
                deposit=100.00,
                work_price=25.00,
                tongxiao_price=100.00,
                label="专业球桌,标准灯光",
                image_urls="https://images.scyanzu.com/pool1.jpg",
                status=1,
                min_hour=1,
                lead_hour=2,
                lead_day=3
            )
        ]
        
        for room in demo_rooms:
            db.add(room)
        
        db.commit()
        
        # 创建演示用户
        demo_user = MemberUser(
            openid="demo_openid_123456",
            nickname="演示用户",
            avatar_url="https://images.scyanzu.com/demo-avatar.jpg",
            phone="13800138000",
            balance=100.00,
            total_consume=500.00
        )
        db.add(demo_user)
        db.commit()
        
        print("✅ 演示数据初始化完成")
        print(f"   门店ID: {demo_store.store_id}")
        print(f"   房间数量: {len(demo_rooms)}")
        print(f"   演示用户ID: {demo_user.id}")
        
    except Exception as e:
        print(f"❌ 初始化失败: {e}")
        db.rollback()
        raise
    finally:
        db.close()

def check_database():
    """检查数据库连接"""
    try:
        engine = create_engine(settings.DATABASE_URL)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        print("✅ 数据库连接正常")
        return True
    except Exception as e:
        print(f"❌ 数据库连接失败: {e}")
        return False

def main():
    """主函数"""
    print("=" * 50)
    print("24h棋牌室数据库初始化工具")
    print("=" * 50)
    
    # 检查数据库连接
    if not check_database():
        print("请检查数据库配置和连接")
        return
    
    # 确认初始化
    response = input("确定要初始化数据库吗？(y/N): ")
    if response.lower() != 'y':
        print("取消初始化")
        return
    
    try:
        init_database()
        print("\n🎉 数据库初始化完成！")
        print("现在可以启动后端服务了")
        print("启动命令: python3 -m uvicorn app.main:app --reload")
    except Exception as e:
        print(f"\n❌ 初始化失败: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()