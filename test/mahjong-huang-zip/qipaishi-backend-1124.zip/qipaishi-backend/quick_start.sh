#!/bin/bash

# 🚀 24h棋牌室后端 - 一键启动脚本
# 适用于新设备的快速部署

set -e  # 遇到错误立即退出

echo "🎉 开始部署24h棋牌室后端服务..."

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 打印带颜色的信息
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查命令是否存在
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# 检查Python
print_info "检查Python环境..."
if ! command_exists python3; then
    print_error "Python3未安装，请先安装Python3.8+"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
print_info "Python版本: $PYTHON_VERSION"

# 检查MySQL
print_info "检查MySQL服务..."
if ! command_exists mysql; then
    print_error "MySQL未安装，请先安装MySQL"
    echo "安装指南:"
    echo "macOS: brew install mysql"
    echo "Ubuntu: sudo apt install mysql-server"
    exit 1
fi

# 检查虚拟环境
if [ ! -d "venv" ]; then
    print_info "创建虚拟环境..."
    python3 -m venv venv
fi

# 激活虚拟环境
print_info "激活虚拟环境..."
source venv/bin/activate

# 安装依赖
print_info "安装项目依赖..."
if [ -f "requirements.txt" ]; then
    pip install --upgrade pip
    pip install -r requirements.txt
else
    print_warning "requirements.txt不存在，安装基础依赖..."
    pip install fastapi uvicorn sqlalchemy pymysql pydantic-settings python-jose[cryptography] python-dotenv
fi

# 检查数据库
print_info "检查数据库配置..."
if [ ! -f ".env" ]; then
    print_warning ".env文件不存在，创建默认配置..."
    cat > .env << 'EOF'
# 应用配置
APP_NAME=24h棋牌室
APP_VERSION=1.0.0
DEBUG=True

# 数据库配置
DATABASE_URL=mysql+pymysql://root:root@localhost:3306/qipaishi?charset=utf8mb4

# 安全配置
SECRET_KEY=dev-secret-key-change-in-production
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=10080

# 微信小程序配置（开发环境）
WECHAT_APP_ID=dev-app-id
WECHAT_APP_SECRET=dev-app-secret

# 微信支付配置（开发环境）
WECHAT_MCH_ID=dev-mch-id
WECHAT_MCH_KEY=dev-mch-key
WECHAT_NOTIFY_URL=http://localhost:8000/api/v1/order/notify

# Redis配置（可选）
REDIS_URL=redis://localhost:6379/0

# 文件上传配置
UPLOAD_DIR=uploads
MAX_FILE_SIZE=5242880

# 日志配置
LOG_LEVEL=DEBUG
LOG_FILE=logs/app.log

# 跨域配置
CORS_ORIGINS=["*"]
EOF
fi

# 检查并创建数据库
print_info "检查数据库..."
mysql -u root -proot -e "CREATE DATABASE IF NOT EXISTS qipaishi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null || {
    print_warning "数据库连接失败，请确保MySQL已启动且root密码为'root'"
    echo "如果密码不同，请修改.env文件中的DATABASE_URL"
    exit 1
}

# 测试数据库连接
print_info "测试数据库连接..."
python3 -c "
from sqlalchemy import create_engine
try:
    engine = create_engine('mysql+pymysql://root:root@localhost:3306/qipaishi?charset=utf8mb4')
    conn = engine.connect()
    conn.close()
    print('✅ 数据库连接成功')
except Exception as e:
    print(f'❌ 数据库连接失败: {e}')
    exit(1)
"

# 检查端口
PORT=8000
for port in 8000 8001 8002 8003 8004; do
    if ! lsof -ti:$port >/dev/null 2>&1; then
        PORT=$port
        break
    fi
done

if [ $PORT -ne 8000 ]; then
    print_warning "端口8000被占用，使用端口$PORT"
fi

# 创建必要的目录
mkdir -p uploads logs

# 启动服务
print_info "启动服务..."
echo "🎯 服务启动成功！"
echo "📍 访问地址: http://localhost:$PORT"
echo "📚 API文档: http://localhost:$PORT/docs"
echo "🔍 健康检查: http://localhost:$PORT/health"
echo ""
echo "📋 测试命令:"
echo "curl http://localhost:$PORT/health"
echo ""
echo "🛑 停止服务: Ctrl+C"

# 启动服务
python3 -m uvicorn app.main:app --reload --host 0.0.0.0 --port $PORT