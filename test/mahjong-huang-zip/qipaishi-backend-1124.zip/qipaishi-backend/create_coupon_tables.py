#!/usr/bin/env python3
"""
创建优惠券活动相关表
"""

import asyncio
import logging
from sqlalchemy import text
from app.core.database import engine
from app.models.coupon_active import Base

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def create_coupon_tables():
    """创建优惠券活动相关表"""
    try:
        logger.info("开始创建优惠券活动相关表...")
        Base.metadata.create_all(bind=engine)
        logger.info("优惠券活动相关表创建成功")
        
        # 检查表是否存在
        with engine.connect() as conn:
            # 检查member_coupon_active表
            result = conn.execute(text("SHOW TABLES LIKE 'member_coupon_active'"))
            active_table_exists = result.fetchone() is not None
            
            # 检查member_coupon表
            result = conn.execute(text("SHOW TABLES LIKE 'member_coupon'"))
            coupon_table_exists = result.fetchone() is not None
            
            if active_table_exists and coupon_table_exists:
                logger.info("✅ 所有优惠券活动相关表已创建成功")
            else:
                logger.error("❌ 部分表创建失败")
                
    except Exception as e:
        logger.error(f"创建表失败: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(create_coupon_tables())