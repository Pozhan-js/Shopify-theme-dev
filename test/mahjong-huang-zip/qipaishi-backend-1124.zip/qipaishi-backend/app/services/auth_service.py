import httpx
from sqlalchemy.orm import Session
from app.models.member import Member
from app.core.security import create_access_token, create_refresh_token
from app.core.config import settings

class AuthService:
    def __init__(self, db: Session):
        self.db = db
    
    async def wechat_login(self, login_data):
        """微信登录"""
        # 1. 通过code获取openid和session_key
        code = login_data.code
        wx_url = f"https://api.weixin.qq.com/sns/jscode2session"
        params = {
            "appid": settings.WECHAT_APP_ID,
            "secret": settings.WECHAT_APP_SECRET,
            "js_code": code,
            "grant_type": "authorization_code"
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.get(wx_url, params=params)
            wx_data = response.json()
        
        if "openid" not in wx_data:
            raise ValueError("微信登录失败")
        
        openid = wx_data["openid"]
        session_key = wx_data.get("session_key")
        
        # 2. 查找或创建用户
        member = self.db.query(Member).filter(Member.openid == openid).first()
        
        if not member:
            # 解密用户信息
            # 这里简化处理，实际应该解密encryptedData
            member = Member(
                openid=openid,
                nickname=login_data.get("nickname", ""),
                avatar_url=login_data.get("avatarUrl", "")
            )
            self.db.add(member)
            self.db.commit()
            self.db.refresh(member)
        else:
            # 更新用户信息
            if login_data.get("nickname"):
                member.nickname = login_data["nickname"]
            if login_data.get("avatarUrl"):
                member.avatar_url = login_data["avatarUrl"]
            self.db.commit()
            self.db.refresh(member)
        
        # 3. 创建token
        access_token = create_access_token({"sub": str(member.id)})
        refresh_token = create_refresh_token({"sub": str(member.id)})
        
        return {
            "accessToken": access_token,
            "refreshToken": refresh_token,
            "userId": member.id,
            "nickname": member.nickname,
            "avatarUrl": member.avatar_url
        }