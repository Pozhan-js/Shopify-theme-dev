from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_
from app.models.order import Order, OrderItem, OrderLog
from app.models.store import Room, RoomSchedule
from app.models.member import Member
from app.core.config import settings
import uuid

class OrderService:
    def __init__(self, db: Session):
        self.db = db
    
    async def create_order(self, member_id: int, order_data):
        """创建订单"""
        # 1. 验证房间和时间
        room = self.db.query(Room).filter(
            Room.id == order_data.room_id,
            Room.deleted == False
        ).first()
        
        if not room:
            raise ValueError("房间不存在")
        
        # 2. 检查时间冲突
        appointment_date = datetime.strptime(order_data.appointment_date, "%Y-%m-%d")
        
        # 检查排班
        schedule = self.db.query(RoomSchedule).filter(
            RoomSchedule.room_id == order_data.room_id,
            RoomSchedule.date == appointment_date,
            RoomSchedule.start_time <= order_data.start_time,
            RoomSchedule.end_time >= order_data.end_time,
            RoomSchedule.status == 1
        ).first()
        
        if not schedule:
            # 检查默认营业时间
            start_hour = int(order_data.start_time.split(":")[0])
            if start_hour < 8 or start_hour >= 24:
                raise ValueError("不在营业时间内")
        
        # 检查已有订单
        existing_order = self.db.query(Order).filter(
            Order.room_id == order_data.room_id,
            Order.appointment_date == appointment_date,
            Order.start_time < order_data.end_time,
            Order.end_time > order_data.start_time,
            Order.status.in_([1, 2, 3]),  # 待支付、已支付、已完成
            Order.deleted == False
        ).first()
        
        if existing_order:
            raise ValueError("该时间段已被预约")
        
        # 3. 计算价格
        duration = order_data.duration
        original_price = room.price * duration
        discount_price = 0
        pay_price = original_price - discount_price
        
        # 4. 创建订单
        order_no = self.generate_order_no()
        order = Order(
            order_no=order_no,
            member_id=member_id,
            store_id=room.store_id,
            room_id=order_data.room_id,
            appointment_date=appointment_date,
            start_time=order_data.start_time,
            end_time=order_data.end_time,
            duration=duration,
            original_price=original_price,
            discount_price=discount_price,
            pay_price=pay_price,
            contact_name=order_data.contact_name,
            contact_phone=order_data.contact_phone,
            remark=order_data.remark
        )
        
        self.db.add(order)
        self.db.commit()
        self.db.refresh(order)
        
        # 5. 创建订单明细
        order_item = OrderItem(
            order_id=order.id,
            item_type=1,  # 房间费
            item_id=room.id,
            item_name=room.name,
            quantity=1,
            price=room.price,
            total_price=room.price * duration
        )
        
        self.db.add(order_item)
        
        # 6. 记录日志
        log = OrderLog(
            order_id=order.id,
            action="create",
            description="用户创建订单",
            operator=f"member_{member_id}"
        )
        self.db.add(log)
        
        self.db.commit()
        
        return {
            "orderId": order.id,
            "orderNo": order.order_no,
            "payPrice": float(order.pay_price)
        }
    
    async def process_payment(self, order: Order, pay_type: int):
        """处理支付"""
        if pay_type == 1:  # 微信支付
            # 这里应该调用微信支付API
            # 简化处理，直接标记为已支付
            order.status = 2
            order.pay_status = 2
            order.pay_time = datetime.now()
            order.pay_type = 1
            
            # 记录日志
            log = OrderLog(
                order_id=order.id,
                action="pay",
                description="用户完成支付",
                operator=f"member_{order.member_id}"
            )
            self.db.add(log)
            self.db.commit()
            
            return {"message": "支付成功"}
        
        elif pay_type == 2:  # 余额支付
            member = self.db.query(Member).filter(Member.id == order.member_id).first()
            if member.balance < order.pay_price:
                raise ValueError("余额不足")
            
            member.balance -= order.pay_price
            order.status = 2
            order.pay_status = 2
            order.pay_time = datetime.now()
            order.pay_type = 2
            
            # 记录日志
            log = OrderLog(
                order_id=order.id,
                action="pay",
                description="用户使用余额支付",
                operator=f"member_{order.member_id}"
            )
            self.db.add(log)
            self.db.commit()
            
            return {"message": "支付成功"}
    
    async def process_refund(self, order: Order, reason: str):
        """处理退款"""
        # 这里应该调用微信退款API
        # 简化处理，直接标记为已退款
        order.status = 5  # 已退款
        order.refund_amount = order.pay_price
        order.refund_reason = reason
        order.refund_time = datetime.now()
        
        # 如果是余额支付，退还余额
        if order.pay_type == 2:
            member = self.db.query(Member).filter(Member.id == order.member_id).first()
            member.balance += order.pay_price
        
        # 记录日志
        log = OrderLog(
            order_id=order.id,
            action="refund",
            description=f"用户申请退款，原因：{reason}",
            operator=f"member_{order.member_id}"
        )
        self.db.add(log)
        self.db.commit()
        
        return {"message": "退款申请已提交"}
    
    def generate_order_no(self):
        """生成订单号"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        random_str = str(uuid.uuid4())[:6].upper()
        return f"MJ{timestamp}{random_str}"