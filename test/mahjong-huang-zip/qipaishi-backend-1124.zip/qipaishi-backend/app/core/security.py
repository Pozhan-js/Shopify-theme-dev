from datetime import datetime, timedelta
from typing import Optional
import jwt
from passlib.context import CryptContext
from fastapi import HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.models.member import Member
from app.models.admin import AdminUser

# 密码加密上下文
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

security = HTTPBearer()

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """创建访问令牌"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt

def create_refresh_token(data: dict):
    """创建刷新令牌"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt

def verify_token(token: str) -> dict:
    """验证令牌"""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token已过期")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Token无效")

async def get_current_member(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> Member:
    """获取当前登录用户"""
    token = credentials.credentials
    payload = verify_token(token)
    
    member_id = payload.get("sub")
    if member_id is None:
        raise HTTPException(status_code=401, detail="Token无效")
    
    member = db.query(Member).filter(
        Member.id == member_id,
        Member.deleted == False
    ).first()
    
    if member is None:
        raise HTTPException(status_code=401, detail="用户不存在")
    
    return member

async def get_current_member_optional(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> Optional[Member]:
    """可选的当前用户（用于不需要登录的接口）"""
    try:
        return await get_current_member(credentials, db)
    except HTTPException:
        return None

async def get_current_admin(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> dict:
    """获取当前登录管理员"""
    token = credentials.credentials
    payload = verify_token(token)
    
    # 检查是否为管理员token
    token_type = payload.get("type")
    if token_type != "admin":
        raise HTTPException(status_code=401, detail="需要管理员权限")
    
    admin_id = payload.get("sub")
    if admin_id is None:
        raise HTTPException(status_code=401, detail="Token无效")
    
    admin = db.query(AdminUser).filter(
        AdminUser.id == admin_id,
        AdminUser.deleted == False,
        AdminUser.status == 1
    ).first()
    
    if admin is None:
        raise HTTPException(status_code=401, detail="管理员不存在或已被禁用")
    
    return {
        "id": admin.id,
        "username": admin.username,
        "real_name": admin.real_name,
        "role": admin.role
    }

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """验证密码"""
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    """获取密码哈希"""
    return pwd_context.hash(password)