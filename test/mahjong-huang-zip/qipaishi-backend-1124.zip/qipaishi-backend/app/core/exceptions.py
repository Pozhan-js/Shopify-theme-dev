from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse
from typing import Union
import logging

logger = logging.getLogger(__name__)

class BusinessException(HTTPException):
    """业务异常"""
    def __init__(self, code: int = 400, message: str = "业务处理失败"):
        super().__init__(status_code=400, detail=message)
        self.code = code

class ValidationException(HTTPException):
    """验证异常"""
    def __init__(self, message: str = "参数验证失败"):
        super().__init__(status_code=422, detail=message)

class NotFoundException(HTTPException):
    """资源不存在异常"""
    def __init__(self, message: str = "资源不存在"):
        super().__init__(status_code=404, detail=message)

class UnauthorizedException(HTTPException):
    """未授权异常"""
    def __init__(self, message: str = "未授权访问"):
        super().__init__(status_code=401, detail=message)

class ForbiddenException(HTTPException):
    """权限不足异常"""
    def __init__(self, message: str = "权限不足"):
        super().__init__(status_code=403, detail=message)

async def business_exception_handler(request: Request, exc: BusinessException):
    """业务异常处理器"""
    logger.warning(f"Business exception: {exc.detail}")
    return JSONResponse(
        status_code=200,
        content={
            "code": exc.code,
            "msg": exc.detail,
            "data": None
        }
    )

async def http_exception_handler(request: Request, exc: HTTPException):
    """HTTP异常处理器"""
    logger.error(f"HTTP exception: {exc.detail}")
    return JSONResponse(
        status_code=200,
        content={
            "code": exc.status_code,
            "msg": exc.detail,
            "data": None
        }
    )

async def general_exception_handler(request: Request, exc: Exception):
    """通用异常处理器"""
    logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=200,
        content={
            "code": 500,
            "msg": "服务器内部错误",
            "data": None
        }
    )