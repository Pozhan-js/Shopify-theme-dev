from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class OrderCreate(BaseModel):
    room_id: int = Field(..., description="房间ID")
    appointment_date: str = Field(..., description="预约日期 YYYY-MM-DD")
    start_time: str = Field(..., description="开始时间 HH:MM")
    end_time: str = Field(..., description="结束时间 HH:MM")
    duration: int = Field(..., description="时长(小时)")
    contact_name: str = Field(..., description="联系人姓名")
    contact_phone: str = Field(..., description="联系电话")
    remark: Optional[str] = Field(None, description="备注")
    coupon_id: Optional[int] = Field(None, description="优惠券ID")

class OrderResponse(BaseModel):
    id: int
    order_no: str
    member_id: int
    store_id: int
    room_id: int
    appointment_date: datetime
    start_time: str
    end_time: str
    duration: int
    original_price: float
    discount_price: float
    pay_price: float
    status: int
    pay_status: int
    pay_time: Optional[datetime]
    pay_type: Optional[int]
    contact_name: str
    contact_phone: str
    remark: Optional[str]
    create_time: datetime
    
    class Config:
        orm_mode = True