"""
优惠券活动相关Schema
"""

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from decimal import Decimal

class CouponActiveResponse(BaseModel):
    """优惠券活动响应模型"""
    id: int = Field(..., description="优惠券活动ID")
    coupon_name: str = Field(..., description="优惠券名称")
    coupon_type: int = Field(..., description="优惠券类型：1-满减券 2-折扣券")
    coupon_value: Decimal = Field(..., description="优惠券面值/折扣值")
    min_amount: Decimal = Field(..., description="最低使用金额")
    start_time: datetime = Field(..., description="开始时间")
    end_time: datetime = Field(..., description="结束时间")
    total_count: int = Field(..., description="总数量")
    used_count: int = Field(..., description="已领取数量")
    status: int = Field(..., description="状态：0-停止 1-进行中")
    description: Optional[str] = Field(None, description="描述")
    create_time: datetime = Field(..., description="创建时间")

    class Config:
        orm_mode = True

class CouponActiveCreate(BaseModel):
    """优惠券活动创建模型"""
    coupon_name: str = Field(..., description="优惠券名称")
    coupon_type: int = Field(..., description="优惠券类型：1-满减券 2-折扣券")
    coupon_value: Decimal = Field(..., description="优惠券面值/折扣值")
    min_amount: Decimal = Field(default=0.00, description="最低使用金额")
    start_time: datetime = Field(..., description="开始时间")
    end_time: datetime = Field(..., description="结束时间")
    total_count: int = Field(..., description="总数量")
    description: Optional[str] = Field(None, description="描述")

class CouponActiveUpdate(BaseModel):
    """优惠券活动更新模型"""
    coupon_name: Optional[str] = Field(None, description="优惠券名称")
    coupon_type: Optional[int] = Field(None, description="优惠券类型")
    coupon_value: Optional[Decimal] = Field(None, description="优惠券面值/折扣值")
    min_amount: Optional[Decimal] = Field(None, description="最低使用金额")
    start_time: Optional[datetime] = Field(None, description="开始时间")
    end_time: Optional[datetime] = Field(None, description="结束时间")
    total_count: Optional[int] = Field(None, description="总数量")
    status: Optional[int] = Field(None, description="状态：0-停止 1-进行中")
    description: Optional[str] = Field(None, description="描述")

class UserCouponResponse(BaseModel):
    """用户优惠券响应模型"""
    id: int = Field(..., description="用户优惠券ID")
    coupon_id: int = Field(..., description="优惠券活动ID")
    user_id: int = Field(..., description="用户ID")
    coupon_code: str = Field(..., description="优惠券码")
    status: int = Field(..., description="状态：0-未使用 1-已使用 2-已过期")
    used_time: Optional[datetime] = Field(None, description="使用时间")
    order_id: Optional[int] = Field(None, description="使用订单ID")
    create_time: datetime = Field(..., description="创建时间")

    class Config:
        orm_mode = True