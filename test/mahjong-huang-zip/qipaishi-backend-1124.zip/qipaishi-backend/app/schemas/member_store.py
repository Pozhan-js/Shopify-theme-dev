from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class MemberStoreCreate(BaseModel):
    member_id: int
    store_name: str = Field(..., min_length=1, max_length=100)
    store_address: Optional[str] = Field(None, max_length=255)
    store_phone: Optional[str] = Field(None, max_length=20)
    business_license: Optional[str] = Field(None, max_length=100)
    legal_person: Optional[str] = Field(None, max_length=50)
    legal_phone: Optional[str] = Field(None, max_length=20)
    legal_id_card: Optional[str] = Field(None, max_length=18)
    store_images: Optional[List[str]] = None
    license_images: Optional[List[str]] = None
    id_card_images: Optional[List[str]] = None

class MemberStoreUpdate(BaseModel):
    store_name: Optional[str] = Field(None, min_length=1, max_length=100)
    store_address: Optional[str] = Field(None, max_length=255)
    store_phone: Optional[str] = Field(None, max_length=20)
    business_license: Optional[str] = Field(None, max_length=100)
    legal_person: Optional[str] = Field(None, max_length=50)
    legal_phone: Optional[str] = Field(None, max_length=20)
    legal_id_card: Optional[str] = Field(None, max_length=18)
    store_images: Optional[List[str]] = None
    license_images: Optional[List[str]] = None
    id_card_images: Optional[List[str]] = None

class MemberStoreStaffCreate(BaseModel):
    store_id: int
    name: str = Field(..., min_length=1, max_length=50)
    phone: str = Field(..., max_length=20)
    position: Optional[str] = Field(None, max_length=50)
    id_card: Optional[str] = Field(None, max_length=18)

class MemberStoreStaffUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=50)
    phone: Optional[str] = Field(None, max_length=20)
    position: Optional[str] = Field(None, max_length=50)
    id_card: Optional[str] = Field(None, max_length=18)
    status: Optional[int] = Field(None, ge=0, le=1)