"""
基础设施日志相关Schema
"""

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class InfraApiAccessLogResponse(BaseModel):
    """API访问日志响应模型"""
    id: int = Field(..., description="日志主键")
    trace_id: str = Field(..., description="链路追踪编号")
    user_id: int = Field(..., description="用户编号")
    user_type: int = Field(..., description="用户类型")
    application_name: str = Field(..., description="应用名")
    request_method: str = Field(..., description="请求方法名")
    request_url: str = Field(..., description="请求地址")
    request_params: str = Field(..., description="请求参数")
    user_ip: str = Field(..., description="用户 IP")
    user_agent: str = Field(..., description="浏览器 UA")
    begin_time: datetime = Field(..., description="开始请求时间")
    end_time: datetime = Field(..., description="结束请求时间")
    duration: int = Field(..., description="执行时长")
    result_code: int = Field(..., description="结果码")
    result_msg: Optional[str] = Field(None, description="结果提示")
    create_time: datetime = Field(..., description="创建时间")

    class Config:
        orm_mode = True

class InfraApiErrorLogResponse(BaseModel):
    """API错误日志响应模型"""
    id: int = Field(..., description="编号")
    trace_id: str = Field(..., description="链路追踪编号")
    user_id: int = Field(..., description="用户编号")
    user_type: int = Field(..., description="用户类型")
    application_name: str = Field(..., description="应用名")
    request_method: str = Field(..., description="请求方法名")
    request_url: str = Field(..., description="请求地址")
    request_params: str = Field(..., description="请求参数")
    user_ip: str = Field(..., description="用户 IP")
    user_agent: str = Field(..., description="浏览器 UA")
    exception_time: datetime = Field(..., description="异常发生时间")
    exception_name: str = Field(..., description="异常名")
    exception_message: str = Field(..., description="异常导致的消息")
    exception_root_cause_message: str = Field(..., description="异常导致的根消息")
    exception_stack_trace: str = Field(..., description="异常的栈轨迹")
    exception_class_name: str = Field(..., description="异常发生的类全名")
    exception_file_name: str = Field(..., description="异常发生的类文件")
    exception_method_name: str = Field(..., description="异常发生的方法名")
    exception_line_number: int = Field(..., description="异常发生的方法所在行")
    process_status: int = Field(..., description="处理状态")
    process_time: Optional[datetime] = Field(None, description="处理时间")
    process_user_id: Optional[int] = Field(None, description="处理用户编号")
    create_time: datetime = Field(..., description="创建时间")

    class Config:
        orm_mode = True

class InfraApiErrorLogUpdate(BaseModel):
    """API错误日志更新模型"""
    process_status: int = Field(..., description="处理状态")
    process_user_id: Optional[int] = Field(None, description="处理用户编号")