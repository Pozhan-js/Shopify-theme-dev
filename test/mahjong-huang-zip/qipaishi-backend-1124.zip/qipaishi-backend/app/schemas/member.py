from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class MemberLogin(BaseModel):
    code: str = Field(..., description="微信登录code")
    encryptedData: Optional[str] = Field(None, description="加密数据")
    iv: Optional[str] = Field(None, description="初始向量")
    nickname: Optional[str] = Field(None, description="昵称")
    avatarUrl: Optional[str] = Field(None, description="头像URL")

class MemberUpdate(BaseModel):
    nickname: Optional[str] = Field(None, description="昵称")
    avatar_url: Optional[str] = Field(None, description="头像URL")
    phone: Optional[str] = Field(None, description="手机号")
    real_name: Optional[str] = Field(None, description="真实姓名")
    id_card: Optional[str] = Field(None, description="身份证号")

class MemberResponse(BaseModel):
    id: int
    openid: str
    nickname: Optional[str]
    avatar_url: Optional[str]
    phone: Optional[str]
    real_name: Optional[str]
    balance: float
    total_recharge: float
    total_consume: float
    points: int
    level: int
    status: int
    create_time: datetime
    
    class Config:
        orm_mode = True