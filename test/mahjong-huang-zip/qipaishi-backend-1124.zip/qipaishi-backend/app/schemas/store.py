from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class StoreCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    phone: Optional[str] = Field(None, max_length=20)
    address: Optional[str] = Field(None, max_length=255)
    longitude: Optional[float] = None
    latitude: Optional[float] = None
    business_hours: Optional[str] = Field(None, max_length=100)
    description: Optional[str] = None
    images: Optional[List[str]] = None
    status: int = Field(1, ge=0, le=1)
    sort_order: int = Field(0, ge=0)

class StoreUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    phone: Optional[str] = Field(None, max_length=20)
    address: Optional[str] = Field(None, max_length=255)
    longitude: Optional[float] = None
    latitude: Optional[float] = None
    business_hours: Optional[str] = Field(None, max_length=100)
    description: Optional[str] = None
    images: Optional[List[str]] = None
    status: Optional[int] = Field(None, ge=0, le=1)
    sort_order: Optional[int] = Field(None, ge=0)

class RoomCreate(BaseModel):
    store_id: int
    name: str = Field(..., min_length=1, max_length=100)
    type: int = Field(..., ge=1, le=4)
    capacity: int = Field(4, ge=1)
    price: float = Field(..., gt=0)
    description: Optional[str] = None
    images: Optional[List[str]] = None
    equipment: Optional[dict] = None
    status: int = Field(1, ge=0, le=1)
    sort_order: int = Field(0, ge=0)

class RoomUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    type: Optional[int] = Field(None, ge=1, le=4)
    capacity: Optional[int] = Field(None, ge=1)
    price: Optional[float] = Field(None, gt=0)
    description: Optional[str] = None
    images: Optional[List[str]] = None
    equipment: Optional[dict] = None
    status: Optional[int] = Field(None, ge=0, le=1)
    sort_order: Optional[int] = Field(None, ge=0)