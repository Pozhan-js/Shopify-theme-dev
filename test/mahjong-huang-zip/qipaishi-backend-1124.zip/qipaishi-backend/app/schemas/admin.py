from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime

class AdminLogin(BaseModel):
    username: str
    password: str

class AdminUserCreate(BaseModel):
    username: str
    password: str
    real_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    role: str = "admin"
    remark: Optional[str] = None

class AdminUserUpdate(BaseModel):
    real_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    avatar: Optional[str] = None
    password: Optional[str] = None
    remark: Optional[str] = None

class AdminUserResponse(BaseModel):
    id: int
    username: str
    real_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    avatar: Optional[str] = None
    role: str
    status: int
    last_login_time: Optional[datetime] = None
    last_login_ip: Optional[str] = None
    login_count: int
    remark: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

class AdminUserList(BaseModel):
    list: list[AdminUserResponse]
    total: int
    page: int
    page_size: int

class AdminLoginLogResponse(BaseModel):
    id: int
    user_id: int
    login_time: datetime
    login_ip: Optional[str] = None
    user_agent: Optional[str] = None
    login_result: int
    failure_reason: Optional[str] = None
    username: Optional[str] = None

    class Config:
        orm_mode = True

class AdminOperationLogResponse(BaseModel):
    id: int
    user_id: int
    operation_module: Optional[str] = None
    operation_type: Optional[str] = None
    operation_desc: Optional[str] = None
    request_url: Optional[str] = None
    request_method: Optional[str] = None
    request_params: Optional[str] = None
    response_data: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    operation_time: datetime
    execution_time: Optional[int] = None
    username: Optional[str] = None

    class Config:
        orm_mode = True