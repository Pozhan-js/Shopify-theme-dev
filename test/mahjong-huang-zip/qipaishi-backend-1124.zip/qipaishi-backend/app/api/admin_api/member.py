from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional, List
from datetime import datetime
import json
import os
import uuid

from app.core.database import get_db
from app.core.security import get_current_admin
from app.models.member_store import MemberStoreInfo, MemberStoreStaff
from app.models.member import Member

router = APIRouter(tags=["会员管理"])

# 会员门店信息管理
@router.get("/store-info/list")
async def get_store_info_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    keyword: Optional[str] = None,
    status: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取会员门店信息列表"""
    query = db.query(MemberStoreInfo).filter(MemberStoreInfo.deleted == False)
    
    if keyword:
        query = query.filter(
            (MemberStoreInfo.store_name.contains(keyword)) |
            (MemberStoreInfo.store_address.contains(keyword)) |
            (MemberStoreInfo.legal_person.contains(keyword))
        )
    
    if status is not None:
        query = query.filter(MemberStoreInfo.status == status)
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            query = query.filter(MemberStoreInfo.created_at >= start_dt)
        except ValueError:
            pass
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            end_dt = end_dt.replace(hour=23, minute=59, second=59)
            query = query.filter(MemberStoreInfo.created_at <= end_dt)
        except ValueError:
            pass
    
    total = query.count()
    stores = query.order_by(MemberStoreInfo.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    # 获取关联的会员信息
    result = []
    for store in stores:
        member = db.query(Member).filter(Member.id == store.member_id).first()
        result.append({
            "id": store.id,
            "memberId": store.member_id,
            "memberName": member.nickname if member else None,
            "memberPhone": member.phone if member else None,
            "storeName": store.store_name,
            "storeAddress": store.store_address,
            "storePhone": store.store_phone,
            "businessLicense": store.business_license,
            "legalPerson": store.legal_person,
            "legalPhone": store.legal_phone,
            "legalIdCard": store.legal_id_card,
            "storeImages": json.loads(store.store_images) if store.store_images else [],
            "licenseImages": json.loads(store.license_images) if store.license_images else [],
            "idCardImages": json.loads(store.id_card_images) if store.id_card_images else [],
            "status": store.status,
            "auditRemark": store.audit_remark,
            "auditTime": store.audit_time,
            "createdAt": store.created_at,
            "updatedAt": store.updated_at
        })
    
    return {
        "code": 200,
        "data": {
            "list": result,
            "total": total
        },
        "msg": "success"
    }

@router.post("/store-info/create")
async def create_store_info(
    member_id: int,
    store_name: str,
    store_address: Optional[str] = None,
    store_phone: Optional[str] = None,
    business_license: Optional[str] = None,
    legal_person: Optional[str] = None,
    legal_phone: Optional[str] = None,
    legal_id_card: Optional[str] = None,
    store_images: Optional[List[str]] = None,
    license_images: Optional[List[str]] = None,
    id_card_images: Optional[List[str]] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """创建会员门店信息"""
    # 检查会员是否存在
    member = db.query(Member).filter(
        Member.id == member_id,
        Member.deleted == False
    ).first()
    
    if not member:
        return {
            "code": 404,
            "data": None,
            "msg": "会员不存在"
        }
    
    # 检查是否已存在门店信息
    existing_store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.member_id == member_id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if existing_store:
        return {
            "code": 400,
            "data": None,
            "msg": "该会员已存在门店信息"
        }
    
    store = MemberStoreInfo(
        member_id=member_id,
        store_name=store_name,
        store_address=store_address,
        store_phone=store_phone,
        business_license=business_license,
        legal_person=legal_person,
        legal_phone=legal_phone,
        legal_id_card=legal_id_card,
        store_images=json.dumps(store_images) if store_images else None,
        license_images=json.dumps(license_images) if license_images else None,
        id_card_images=json.dumps(id_card_images) if id_card_images else None,
        status=1  # 待审核
    )
    
    db.add(store)
    db.commit()
    db.refresh(store)
    
    return {
        "code": 200,
        "data": {"id": store.id},
        "msg": "创建成功"
    }

@router.put("/store-info/update")
async def update_store_info(
    id: int,
    store_name: Optional[str] = None,
    store_address: Optional[str] = None,
    store_phone: Optional[str] = None,
    business_license: Optional[str] = None,
    legal_person: Optional[str] = None,
    legal_phone: Optional[str] = None,
    legal_id_card: Optional[str] = None,
    store_images: Optional[List[str]] = None,
    license_images: Optional[List[str]] = None,
    id_card_images: Optional[List[str]] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """更新会员门店信息"""
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.id == id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        return {
            "code": 404,
            "data": None,
            "msg": "门店信息不存在"
        }
    
    update_data = {}
    if store_name is not None:
        update_data["store_name"] = store_name
    if store_address is not None:
        update_data["store_address"] = store_address
    if store_phone is not None:
        update_data["store_phone"] = store_phone
    if business_license is not None:
        update_data["business_license"] = business_license
    if legal_person is not None:
        update_data["legal_person"] = legal_person
    if legal_phone is not None:
        update_data["legal_phone"] = legal_phone
    if legal_id_card is not None:
        update_data["legal_id_card"] = legal_id_card
    if store_images is not None:
        update_data["store_images"] = json.dumps(store_images)
    if license_images is not None:
        update_data["license_images"] = json.dumps(license_images)
    if id_card_images is not None:
        update_data["id_card_images"] = json.dumps(id_card_images)
    
    for field, value in update_data.items():
        setattr(store, field, value)
    
    db.commit()
    db.refresh(store)
    
    return {
        "code": 200,
        "data": None,
        "msg": "更新成功"
    }

@router.delete("/store-info/delete")
async def delete_store_info(
    id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """删除会员门店信息"""
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.id == id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        return {
            "code": 404,
            "data": None,
            "msg": "门店信息不存在"
        }
    
    store.deleted = True
    db.commit()
    
    return {
        "code": 200,
        "data": None,
        "msg": "删除成功"
    }

@router.get("/store-info/detail")
async def get_store_info_detail(
    id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取会员门店详情"""
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.id == id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        return {
            "code": 404,
            "data": None,
            "msg": "门店信息不存在"
        }
    
    member = db.query(Member).filter(Member.id == store.member_id).first()
    
    return {
        "code": 200,
        "data": {
            "id": store.id,
            "memberId": store.member_id,
            "memberName": member.nickname if member else None,
            "memberPhone": member.phone if member else None,
            "storeName": store.store_name,
            "storeAddress": store.store_address,
            "storePhone": store.store_phone,
            "businessLicense": store.business_license,
            "legalPerson": store.legal_person,
            "legalPhone": store.legal_phone,
            "legalIdCard": store.legal_id_card,
            "storeImages": json.loads(store.store_images) if store.store_images else [],
            "licenseImages": json.loads(store.license_images) if store.license_images else [],
            "idCardImages": json.loads(store.id_card_images) if store.id_card_images else [],
            "status": store.status,
            "auditRemark": store.audit_remark,
            "auditTime": store.audit_time,
            "createdAt": store.created_at,
            "updatedAt": store.updated_at
        },
        "msg": "success"
    }

@router.put("/store-info/audit")
async def audit_store_info(
    id: int,
    status: int,
    audit_remark: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """审核会员门店信息"""
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.id == id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        return {
            "code": 404,
            "data": None,
            "msg": "门店信息不存在"
        }
    
    if status not in [1, 2, 3]:  # 1待审核 2已通过 3已拒绝
        return {
            "code": 400,
            "data": None,
            "msg": "无效的状态值"
        }
    
    store.status = status
    store.audit_remark = audit_remark
    store.audit_time = datetime.now()
    store.audit_admin_id = current_admin["id"]
    
    db.commit()
    db.refresh(store)
    
    return {
        "code": 200,
        "data": None,
        "msg": "审核完成"
    }