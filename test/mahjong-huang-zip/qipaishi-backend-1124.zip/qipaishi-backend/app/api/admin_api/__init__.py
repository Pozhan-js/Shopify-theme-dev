from fastapi import APIRouter
from .member import router as member_router

admin_api_router = APIRouter(prefix="/admin-api")

admin_api_router.include_router(member_router, prefix="/member")