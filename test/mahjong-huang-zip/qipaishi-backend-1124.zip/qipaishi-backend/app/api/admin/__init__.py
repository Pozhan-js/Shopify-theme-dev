from fastapi import APIRouter

from .auth import router as auth_router
from .user import router as user_router
from .store import router as store_router
from .order import router as order_router
from .system import router as system_router
from .infra_log import router as infra_log_router

admin_router = APIRouter(prefix="/admin", tags=["后台管理"])

# 注册所有管理接口
admin_router.include_router(auth_router, prefix="/auth")
admin_router.include_router(user_router, prefix="/user")
admin_router.include_router(store_router, prefix="/store")
admin_router.include_router(order_router, prefix="/order")
admin_router.include_router(system_router, prefix="/system")
admin_router.include_router(infra_log_router, prefix="/infra-log")