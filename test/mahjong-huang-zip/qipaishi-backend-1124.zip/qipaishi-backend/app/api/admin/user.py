from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional
from datetime import datetime, timedelta

from app.core.database import get_db
from app.core.security import get_current_admin
from app.models.member import Member
from app.models.order import Order
from app.schemas.admin import AdminUserList

router = APIRouter(prefix="/user", tags=["用户管理"])

@router.get("/list", response_model=AdminUserList)
async def get_user_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    keyword: Optional[str] = None,
    status: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取用户列表"""
    query = db.query(Member).filter(Member.deleted == False)
    
    if keyword:
        query = query.filter(
            (Member.nickname.contains(keyword)) |
            (Member.phone.contains(keyword)) |
            (Member.openid.contains(keyword))
        )
    
    if status is not None:
        query = query.filter(Member.status == status)
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            query = query.filter(Member.created_at >= start_dt)
        except ValueError:
            pass
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            end_dt = end_dt.replace(hour=23, minute=59, second=59)
            query = query.filter(Member.created_at <= end_dt)
        except ValueError:
            pass
    
    total = query.count()
    users = query.order_by(Member.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": users,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/detail/{user_id}")
async def get_user_detail(
    user_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取用户详情"""
    user = db.query(Member).filter(
        Member.id == user_id,
        Member.deleted == False
    ).first()
    
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    
    # 获取用户统计信息
    from app.models.order import Order
    order_stats = db.query(Order).filter(
        Order.member_id == user_id,
        Order.deleted == False
    )
    
    total_orders = order_stats.count()
    total_amount = db.query(func.sum(Order.total_amount)).filter(
        Order.member_id == user_id,
        Order.status == 3,  # 已完成
        Order.deleted == False
    ).scalar() or 0
    
    return {
        "user": user,
        "statistics": {
            "total_orders": total_orders,
            "total_amount": float(total_amount)
        }
    }

@router.put("/status/{user_id}")
async def update_user_status(
    user_id: int,
    status: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """更新用户状态"""
    user = db.query(Member).filter(
        Member.id == user_id,
        Member.deleted == False
    ).first()
    
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    
    user.status = status
    db.commit()
    db.refresh(user)
    
    return {"message": "状态更新成功", "user": user}

@router.delete("/{user_id}")
async def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """删除用户（软删除）"""
    user = db.query(Member).filter(
        Member.id == user_id,
        Member.deleted == False
    ).first()
    
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    
    user.deleted = True
    db.commit()
    
    return {"message": "用户删除成功"}

@router.get("/statistics")
async def get_user_statistics(
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取用户统计信息"""
    from sqlalchemy import func
    
    # 总用户数
    total_users = db.query(Member).filter(Member.deleted == False).count()
    
    # 今日新增
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    today_new = db.query(Member).filter(
        Member.deleted == False,
        Member.created_at >= today
    ).count()
    
    # 本周新增
    week_start = today - timedelta(days=today.weekday())
    week_new = db.query(Member).filter(
        Member.deleted == False,
        Member.created_at >= week_start
    ).count()
    
    # 本月新增
    month_start = today.replace(day=1)
    month_new = db.query(Member).filter(
        Member.deleted == False,
        Member.created_at >= month_start
    ).count()
    
    # 活跃用户（最近7天有订单）
    active_date = today - timedelta(days=7)
    active_users = db.query(func.count(func.distinct(Order.member_id))).filter(
        Order.created_at >= active_date,
        Order.deleted == False
    ).scalar()
    
    return {
        "total_users": total_users,
        "today_new": today_new,
        "week_new": week_new,
        "month_new": month_new,
        "active_users": active_users or 0
    }