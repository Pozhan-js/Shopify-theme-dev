from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional
from datetime import datetime, timedelta

from app.core.database import get_db
from app.core.security import get_current_admin
from app.models.order import Order, OrderItem
from app.models.member import Member
from app.models.store import Store, Room

router = APIRouter(prefix="/order", tags=["订单管理"])

@router.get("/list")
async def get_order_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    order_no: Optional[str] = None,
    member_id: Optional[int] = None,
    store_id: Optional[int] = None,
    status: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取订单列表"""
    query = db.query(Order).filter(Order.deleted == False)
    
    if order_no:
        query = query.filter(Order.order_no.contains(order_no))
    
    if member_id:
        query = query.filter(Order.member_id == member_id)
    
    if store_id:
        query = query.filter(Order.store_id == store_id)
    
    if status is not None:
        query = query.filter(Order.status == status)
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            query = query.filter(Order.created_at >= start_dt)
        except ValueError:
            pass
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            end_dt = end_dt.replace(hour=23, minute=59, second=59)
            query = query.filter(Order.created_at <= end_dt)
        except ValueError:
            pass
    
    total = query.count()
    orders = query.order_by(Order.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    # 获取关联数据
    result = []
    for order in orders:
        member = db.query(Member).filter(Member.id == order.member_id).first()
        store = db.query(Store).filter(Store.id == order.store_id).first()
        room = db.query(Room).filter(Room.id == order.room_id).first()
        
        result.append({
            "id": order.id,
            "order_no": order.order_no,
            "member": {
                "id": member.id if member else None,
                "nickname": member.nickname if member else None,
                "phone": member.phone if member else None
            },
            "store": {
                "id": store.id if store else None,
                "name": store.name if store else None
            },
            "room": {
                "id": room.id if room else None,
                "name": room.name if room else None
            },
            "appointment_date": order.appointment_date,
            "start_time": order.start_time,
            "end_time": order.end_time,
            "total_amount": float(order.total_amount),
            "status": order.status,
            "payment_time": order.payment_time,
            "created_at": order.created_at,
            "updated_at": order.updated_at
        })
    
    return {
        "list": result,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/detail/{order_id}")
async def get_order_detail(
    order_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取订单详情"""
    order = db.query(Order).filter(
        Order.id == order_id,
        Order.deleted == False
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    # 获取关联数据
    member = db.query(Member).filter(Member.id == order.member_id).first()
    store = db.query(Store).filter(Store.id == order.store_id).first()
    room = db.query(Room).filter(Room.id == order.room_id).first()
    
    # 获取订单项
    order_items = db.query(OrderItem).filter(
        OrderItem.order_id == order_id,
        OrderItem.deleted == False
    ).all()
    
    return {
        "order": order,
        "member": member,
        "store": store,
        "room": room,
        "items": order_items
    }

@router.put("/status/{order_id}")
async def update_order_status(
    order_id: int,
    status: int,
    remark: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """更新订单状态"""
    order = db.query(Order).filter(
        Order.id == order_id,
        Order.deleted == False
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    # 状态检查
    if status not in [1, 2, 3, 4, 5]:  # 1待支付 2已支付 3已完成 4已取消 5已退款
        raise HTTPException(status_code=400, detail="无效的状态值")
    
    order.status = status
    if remark:
        order.remark = remark
    
    # 如果是完成状态，设置完成时间
    if status == 3:
        order.completed_time = datetime.now()
    
    # 如果是退款状态，设置退款时间
    if status == 5:
        order.refund_time = datetime.now()
    
    db.commit()
    db.refresh(order)
    
    return {"message": "订单状态更新成功", "order": order}

@router.post("/refund/{order_id}")
async def refund_order(
    order_id: int,
    refund_amount: Optional[float] = None,
    refund_reason: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """订单退款"""
    order = db.query(Order).filter(
        Order.id == order_id,
        Order.deleted == False
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    if order.status not in [2, 3]:  # 只有已支付或已完成的订单可以退款
        raise HTTPException(status_code=400, detail="当前订单状态不支持退款")
    
    # 计算退款金额
    if refund_amount is None:
        refund_amount = float(order.total_amount)
    
    if refund_amount > float(order.total_amount):
        raise HTTPException(status_code=400, detail="退款金额不能大于订单金额")
    
    # 这里应该调用微信支付退款接口
    # 模拟退款成功
    order.status = 5  # 已退款
    order.refund_amount = refund_amount
    order.refund_reason = refund_reason
    order.refund_time = datetime.now()
    
    db.commit()
    db.refresh(order)
    
    return {"message": "退款成功", "order": order}

@router.get("/statistics")
async def get_order_statistics(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    store_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取订单统计信息"""
    query = db.query(Order).filter(Order.deleted == False)
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            query = query.filter(Order.created_at >= start_dt)
        except ValueError:
            pass
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            end_dt = end_dt.replace(hour=23, minute=59, second=59)
            query = query.filter(Order.created_at <= end_dt)
        except ValueError:
            pass
    
    if store_id:
        query = query.filter(Order.store_id == store_id)
    
    # 总订单数
    total_orders = query.count()
    
    # 总销售额
    total_amount = query.with_entities(func.sum(Order.total_amount)).scalar() or 0
    
    # 各状态订单数
    status_counts = {}
    for status in [1, 2, 3, 4, 5]:
        count = query.filter(Order.status == status).count()
        status_counts[status] = count
    
    # 今日数据
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    today_query = db.query(Order).filter(
        Order.deleted == False,
        Order.created_at >= today
    )
    
    if store_id:
        today_query = today_query.filter(Order.store_id == store_id)
    
    today_orders = today_query.count()
    today_amount = today_query.with_entities(func.sum(Order.total_amount)).scalar() or 0
    
    # 本周数据
    week_start = today - timedelta(days=today.weekday())
    week_query = db.query(Order).filter(
        Order.deleted == False,
        Order.created_at >= week_start
    )
    
    if store_id:
        week_query = week_query.filter(Order.store_id == store_id)
    
    week_orders = week_query.count()
    week_amount = week_query.with_entities(func.sum(Order.total_amount)).scalar() or 0
    
    # 本月数据
    month_start = today.replace(day=1)
    month_query = db.query(Order).filter(
        Order.deleted == False,
        Order.created_at >= month_start
    )
    
    if store_id:
        month_query = month_query.filter(Order.store_id == store_id)
    
    month_orders = month_query.count()
    month_amount = month_query.with_entities(func.sum(Order.total_amount)).scalar() or 0
    
    return {
        "total_orders": total_orders,
        "total_amount": float(total_amount),
        "status_counts": status_counts,
        "today": {
            "orders": today_orders,
            "amount": float(today_amount)
        },
        "week": {
            "orders": week_orders,
            "amount": float(week_amount)
        },
        "month": {
            "orders": month_orders,
            "amount": float(month_amount)
        }
    }