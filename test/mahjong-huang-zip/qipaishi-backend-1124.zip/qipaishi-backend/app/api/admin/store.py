from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import datetime
import json
import os
import uuid

from app.core.database import get_db
from app.core.security import get_current_admin
from app.models.store import Store, Room, RoomSchedule
from app.schemas.store import StoreCreate, StoreUpdate, RoomCreate, RoomUpdate

router = APIRouter(prefix="/store", tags=["门店管理"])

@router.get("/list")
async def get_store_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    keyword: Optional[str] = None,
    status: Optional[int] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取门店列表"""
    query = db.query(Store).filter(Store.deleted == False)
    
    if keyword:
        query = query.filter(
            (Store.name.contains(keyword)) |
            (Store.address.contains(keyword)) |
            (Store.phone.contains(keyword))
        )
    
    if status is not None:
        query = query.filter(Store.status == status)
    
    total = query.count()
    stores = query.order_by(Store.sort_order.desc(), Store.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": stores,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/detail/{store_id}")
async def get_store_detail(
    store_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取门店详情"""
    store = db.query(Store).filter(
        Store.id == store_id,
        Store.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店不存在")
    
    # 获取房间数量
    room_count = db.query(Room).filter(
        Room.store_id == store_id,
        Room.deleted == False
    ).count()
    
    return {
        "store": store,
        "room_count": room_count
    }

@router.post("/create")
async def create_store(
    store_data: StoreCreate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """创建门店"""
    store = Store(**store_data.dict())
    db.add(store)
    db.commit()
    db.refresh(store)
    
    return {"message": "门店创建成功", "store": store}

@router.put("/update/{store_id}")
async def update_store(
    store_id: int,
    store_data: StoreUpdate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """更新门店信息"""
    store = db.query(Store).filter(
        Store.id == store_id,
        Store.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店不存在")
    
    update_data = store_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(store, field, value)
    
    db.commit()
    db.refresh(store)
    
    return {"message": "门店更新成功", "store": store}

@router.delete("/{store_id}")
async def delete_store(
    store_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """删除门店"""
    store = db.query(Store).filter(
        Store.id == store_id,
        Store.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店不存在")
    
    # 检查是否有房间
    room_count = db.query(Room).filter(
        Room.store_id == store_id,
        Room.deleted == False
    ).count()
    
    if room_count > 0:
        raise HTTPException(status_code=400, detail="门店下存在房间，无法删除")
    
    store.deleted = True
    db.commit()
    
    return {"message": "门店删除成功"}

@router.post("/upload-image")
async def upload_store_image(
    file: UploadFile = File(...),
    current_admin: dict = Depends(get_current_admin)
):
    """上传门店图片"""
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="请上传图片文件")
    
    # 生成唯一文件名
    file_extension = file.filename.split('.')[-1]
    filename = f"{uuid.uuid4().hex}.{file_extension}"
    
    # 保存文件
    upload_dir = "uploads/stores"
    os.makedirs(upload_dir, exist_ok=True)
    file_path = os.path.join(upload_dir, filename)
    
    with open(file_path, "wb") as buffer:
        content = await file.read()
        buffer.write(content)
    
    # 返回可访问的URL
    file_url = f"/uploads/stores/{filename}"
    
    return {"url": file_url}

# 房间管理
@router.get("/room/list/{store_id}")
async def get_store_rooms(
    store_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取门店房间列表"""
    query = db.query(Room).filter(
        Room.store_id == store_id,
        Room.deleted == False
    )
    
    total = query.count()
    rooms = query.order_by(Room.sort_order.desc(), Room.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": rooms,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.post("/room/create")
async def create_room(
    room_data: RoomCreate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """创建房间"""
    # 检查门店是否存在
    store = db.query(Store).filter(
        Store.id == room_data.store_id,
        Store.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店不存在")
    
    room = Room(**room_data.dict())
    db.add(room)
    db.commit()
    db.refresh(room)
    
    return {"message": "房间创建成功", "room": room}

@router.put("/room/update/{room_id}")
async def update_room(
    room_id: int,
    room_data: RoomUpdate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """更新房间信息"""
    room = db.query(Room).filter(
        Room.id == room_id,
        Room.deleted == False
    ).first()
    
    if not room:
        raise HTTPException(status_code=404, detail="房间不存在")
    
    update_data = room_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(room, field, value)
    
    db.commit()
    db.refresh(room)
    
    return {"message": "房间更新成功", "room": room}

@router.delete("/room/{room_id}")
async def delete_room(
    room_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """删除房间"""
    room = db.query(Room).filter(
        Room.id == room_id,
        Room.deleted == False
    ).first()
    
    if not room:
        raise HTTPException(status_code=404, detail="房间不存在")
    
    # 检查是否有预约
    from app.models.order import Order
    order_count = db.query(Order).filter(
        Order.room_id == room_id,
        Order.status.in_([1, 2, 3]),  # 待支付、已支付、已完成
        Order.deleted == False
    ).count()
    
    if order_count > 0:
        raise HTTPException(status_code=400, detail="房间存在预约记录，无法删除")
    
    room.deleted = True
    db.commit()
    
    return {"message": "房间删除成功"}

@router.get("/statistics")
async def get_store_statistics(
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取门店统计信息"""
    from sqlalchemy import func
    
    # 总门店数
    total_stores = db.query(Store).filter(Store.deleted == False).count()
    
    # 营业中门店数
    active_stores = db.query(Store).filter(
        Store.deleted == False,
        Store.status == 1
    ).count()
    
    # 总房间数
    total_rooms = db.query(Room).filter(Room.deleted == False).count()
    
    # 可用房间数
    available_rooms = db.query(Room).filter(
        Room.deleted == False,
        Room.status == 1
    ).count()
    
    return {
        "total_stores": total_stores,
        "active_stores": active_stores,
        "total_rooms": total_rooms,
        "available_rooms": available_rooms
    }