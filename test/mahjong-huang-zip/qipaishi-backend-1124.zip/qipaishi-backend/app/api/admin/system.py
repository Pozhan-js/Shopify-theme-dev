from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional
from datetime import datetime, timedelta

from app.core.database import get_db
from app.core.security import get_current_admin
from app.models.admin import AdminUser, AdminLoginLog, AdminOperationLog
from app.schemas.admin import AdminUserCreate, AdminUserUpdate, AdminUserResponse, AdminLoginLogResponse, AdminOperationLogResponse

router = APIRouter(prefix="/system", tags=["系统管理"])

# 管理员管理
@router.get("/admin/list")
async def get_admin_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    keyword: Optional[str] = None,
    role: Optional[str] = None,
    status: Optional[int] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取管理员列表"""
    query = db.query(AdminUser).filter(AdminUser.deleted == False)
    
    if keyword:
        query = query.filter(
            (AdminUser.username.contains(keyword)) |
            (AdminUser.real_name.contains(keyword)) |
            (AdminUser.email.contains(keyword))
        )
    
    if role:
        query = query.filter(AdminUser.role == role)
    
    if status is not None:
        query = query.filter(AdminUser.status == status)
    
    total = query.count()
    admins = query.order_by(AdminUser.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": admins,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.post("/admin/create")
async def create_admin(
    admin_data: AdminUserCreate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """创建管理员"""
    from app.core.security import get_password_hash
    
    # 检查用户名是否已存在
    existing_admin = db.query(AdminUser).filter(
        AdminUser.username == admin_data.username,
        AdminUser.deleted == False
    ).first()
    
    if existing_admin:
        raise HTTPException(status_code=400, detail="用户名已存在")
    
    # 创建新管理员
    admin = AdminUser(
        username=admin_data.username,
        password_hash=get_password_hash(admin_data.password),
        real_name=admin_data.real_name,
        email=admin_data.email,
        phone=admin_data.phone,
        role=admin_data.role,
        status=1
    )
    
    db.add(admin)
    db.commit()
    db.refresh(admin)
    
    return {"message": "管理员创建成功", "admin": AdminUserResponse.from_orm(admin)}

@router.put("/admin/update/{admin_id}")
async def update_admin(
    admin_id: int,
    admin_data: AdminUserUpdate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """更新管理员信息"""
    admin = db.query(AdminUser).filter(
        AdminUser.id == admin_id,
        AdminUser.deleted == False
    ).first()
    
    if not admin:
        raise HTTPException(status_code=404, detail="管理员不存在")
    
    update_data = admin_data.dict(exclude_unset=True)
    if "password" in update_data:
        from app.core.security import get_password_hash
        update_data["password_hash"] = get_password_hash(update_data.pop("password"))
    
    for field, value in update_data.items():
        setattr(admin, field, value)
    
    db.commit()
    db.refresh(admin)
    
    return {"message": "管理员更新成功", "admin": AdminUserResponse.from_orm(admin)}

@router.delete("/admin/{admin_id}")
async def delete_admin(
    admin_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """删除管理员"""
    if admin_id == current_admin["id"]:
        raise HTTPException(status_code=400, detail="不能删除自己的账户")
    
    admin = db.query(AdminUser).filter(
        AdminUser.id == admin_id,
        AdminUser.deleted == False
    ).first()
    
    if not admin:
        raise HTTPException(status_code=404, detail="管理员不存在")
    
    admin.deleted = True
    db.commit()
    
    return {"message": "管理员删除成功"}

# 登录日志
@router.get("/login-log/list")
async def get_login_log_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    username: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取登录日志列表"""
    query = db.query(AdminLoginLog).join(AdminUser).filter(AdminUser.deleted == False)
    
    if username:
        query = query.filter(AdminUser.username.contains(username))
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            query = query.filter(AdminLoginLog.login_time >= start_dt)
        except ValueError:
            pass
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            end_dt = end_dt.replace(hour=23, minute=59, second=59)
            query = query.filter(AdminLoginLog.login_time <= end_dt)
        except ValueError:
            pass
    
    total = query.count()
    logs = query.order_by(AdminLoginLog.login_time.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    # 格式化数据
    result = []
    for log in logs:
        result.append({
            "id": log.id,
            "user_id": log.user_id,
            "username": log.user.username,
            "real_name": log.user.real_name,
            "login_time": log.login_time,
            "login_ip": log.login_ip,
            "user_agent": log.user_agent,
            "login_result": log.login_result,
            "failure_reason": log.failure_reason
        })
    
    return {
        "list": result,
        "total": total,
        "page": page,
        "page_size": page_size
    }

# 操作日志
@router.get("/operation-log/list")
async def get_operation_log_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    username: Optional[str] = None,
    module: Optional[str] = None,
    operation_type: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取操作日志列表"""
    query = db.query(AdminOperationLog).join(AdminUser).filter(AdminUser.deleted == False)
    
    if username:
        query = query.filter(AdminUser.username.contains(username))
    
    if module:
        query = query.filter(AdminOperationLog.operation_module.contains(module))
    
    if operation_type:
        query = query.filter(AdminOperationLog.operation_type == operation_type)
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            query = query.filter(AdminOperationLog.operation_time >= start_dt)
        except ValueError:
            pass
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            end_dt = end_dt.replace(hour=23, minute=59, second=59)
            query = query.filter(AdminOperationLog.operation_time <= end_dt)
        except ValueError:
            pass
    
    total = query.count()
    logs = query.order_by(AdminOperationLog.operation_time.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    # 格式化数据
    result = []
    for log in logs:
        result.append({
            "id": log.id,
            "user_id": log.user_id,
            "username": log.user.username,
            "real_name": log.user.real_name,
            "operation_module": log.operation_module,
            "operation_type": log.operation_type,
            "operation_desc": log.operation_desc,
            "request_url": log.request_url,
            "request_method": log.request_method,
            "operation_time": log.operation_time,
            "execution_time": log.execution_time,
            "ip_address": log.ip_address
        })
    
    return {
        "list": result,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/dashboard")
async def get_dashboard_data(
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取仪表盘数据"""
    from app.models.member import Member
    from app.models.order import Order
    from app.models.store import Store, Room
    
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    
    # 用户统计
    total_users = db.query(Member).filter(Member.deleted == False).count()
    today_new_users = db.query(Member).filter(
        Member.deleted == False,
        Member.created_at >= today
    ).count()
    
    # 订单统计
    total_orders = db.query(Order).filter(Order.deleted == False).count()
    today_orders = db.query(Order).filter(
        Order.deleted == False,
        Order.created_at >= today
    ).count()
    
    # 销售额统计
    total_sales = db.query(func.sum(Order.total_amount)).filter(
        Order.deleted == False,
        Order.status == 3  # 已完成
    ).scalar() or 0
    
    today_sales = db.query(func.sum(Order.total_amount)).filter(
        Order.deleted == False,
        Order.status == 3,
        Order.created_at >= today
    ).scalar() or 0
    
    # 门店统计
    total_stores = db.query(Store).filter(Store.deleted == False).count()
    total_rooms = db.query(Room).filter(Room.deleted == False).count()
    
    # 最近7天订单趋势
    trend_data = []
    for i in range(7):
        date = today - timedelta(days=i)
        next_date = date + timedelta(days=1)
        
        day_orders = db.query(Order).filter(
            Order.deleted == False,
            Order.created_at >= date,
            Order.created_at < next_date
        ).count()
        
        day_amount = db.query(func.sum(Order.total_amount)).filter(
            Order.deleted == False,
            Order.status == 3,
            Order.created_at >= date,
            Order.created_at < next_date
        ).scalar() or 0
        
        trend_data.append({
            "date": date.strftime("%Y-%m-%d"),
            "orders": day_orders,
            "amount": float(day_amount)
        })
    
    trend_data.reverse()
    
    return {
        "user_stats": {
            "total_users": total_users,
            "today_new_users": today_new_users
        },
        "order_stats": {
            "total_orders": total_orders,
            "today_orders": today_orders
        },
        "sales_stats": {
            "total_sales": float(total_sales),
            "today_sales": float(today_sales)
        },
        "store_stats": {
            "total_stores": total_stores,
            "total_rooms": total_rooms
        },
        "trend_data": trend_data
    }