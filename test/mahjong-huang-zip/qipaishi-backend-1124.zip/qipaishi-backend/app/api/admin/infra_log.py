"""
基础设施日志管理接口
基于migrate.sql中的infra_api_access_log和infra_api_error_log表
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import Optional, List
from datetime import datetime, timedelta

from app.core.database import get_db
from app.core.security import get_current_admin
from app.models.infra_log import InfraApiAccessLog, InfraApiErrorLog
from app.schemas.infra_log import InfraApiAccessLogResponse, InfraApiErrorLogResponse, InfraApiErrorLogUpdate

router = APIRouter(prefix="/infra-log", tags=["基础设施日志"])

# API访问日志接口
@router.get("/access-log/list", response_model=dict)
async def get_api_access_log_list(
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(10, ge=1, le=100, description="每页条数"),
    user_id: Optional[int] = Query(None, description="用户编号"),
    user_type: Optional[int] = Query(None, description="用户类型"),
    application_name: Optional[str] = Query(None, description="应用名"),
    request_url: Optional[str] = Query(None, description="请求地址"),
    result_code: Optional[int] = Query(None, description="结果码"),
    start_date: Optional[str] = Query(None, description="开始日期(YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="结束日期(YYYY-MM-DD)"),
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取API访问日志列表"""
    query = db.query(InfraApiAccessLog).filter(InfraApiAccessLog.deleted == False)
    
    # 条件筛选
    if user_id:
        query = query.filter(InfraApiAccessLog.user_id == user_id)
    
    if user_type is not None:
        query = query.filter(InfraApiAccessLog.user_type == user_type)
    
    if application_name:
        query = query.filter(InfraApiAccessLog.application_name.contains(application_name))
    
    if request_url:
        query = query.filter(InfraApiAccessLog.request_url.contains(request_url))
    
    if result_code is not None:
        query = query.filter(InfraApiAccessLog.result_code == result_code)
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            query = query.filter(InfraApiAccessLog.begin_time >= start_dt)
        except ValueError:
            raise HTTPException(status_code=400, detail="开始日期格式错误")
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            end_dt = end_dt.replace(hour=23, minute=59, second=59)
            query = query.filter(InfraApiAccessLog.begin_time <= end_dt)
        except ValueError:
            raise HTTPException(status_code=400, detail="结束日期格式错误")
    
    # 统计总数
    total = query.count()
    
    # 分页查询
    logs = query.order_by(InfraApiAccessLog.begin_time.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": [InfraApiAccessLogResponse.from_orm(log) for log in logs],
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/access-log/{log_id}", response_model=InfraApiAccessLogResponse)
async def get_api_access_log_detail(
    log_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取API访问日志详情"""
    log = db.query(InfraApiAccessLog).filter(
        InfraApiAccessLog.id == log_id,
        InfraApiAccessLog.deleted == False
    ).first()
    
    if not log:
        raise HTTPException(status_code=404, detail="日志不存在")
    
    return InfraApiAccessLogResponse.from_orm(log)

# API错误日志接口
@router.get("/error-log/list", response_model=dict)
async def get_api_error_log_list(
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(10, ge=1, le=100, description="每页条数"),
    user_id: Optional[int] = Query(None, description="用户编号"),
    user_type: Optional[int] = Query(None, description="用户类型"),
    application_name: Optional[str] = Query(None, description="应用名"),
    request_url: Optional[str] = Query(None, description="请求地址"),
    exception_name: Optional[str] = Query(None, description="异常名"),
    process_status: Optional[int] = Query(None, description="处理状态"),
    start_date: Optional[str] = Query(None, description="开始日期(YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="结束日期(YYYY-MM-DD)"),
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取API错误日志列表"""
    query = db.query(InfraApiErrorLog).filter(InfraApiErrorLog.deleted == False)
    
    # 条件筛选
    if user_id:
        query = query.filter(InfraApiErrorLog.user_id == user_id)
    
    if user_type is not None:
        query = query.filter(InfraApiErrorLog.user_type == user_type)
    
    if application_name:
        query = query.filter(InfraApiErrorLog.application_name.contains(application_name))
    
    if request_url:
        query = query.filter(InfraApiErrorLog.request_url.contains(request_url))
    
    if exception_name:
        query = query.filter(InfraApiErrorLog.exception_name.contains(exception_name))
    
    if process_status is not None:
        query = query.filter(InfraApiErrorLog.process_status == process_status)
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            query = query.filter(InfraApiErrorLog.exception_time >= start_dt)
        except ValueError:
            raise HTTPException(status_code=400, detail="开始日期格式错误")
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            end_dt = end_dt.replace(hour=23, minute=59, second=59)
            query = query.filter(InfraApiErrorLog.exception_time <= end_dt)
        except ValueError:
            raise HTTPException(status_code=400, detail="结束日期格式错误")
    
    # 统计总数
    total = query.count()
    
    # 分页查询
    logs = query.order_by(InfraApiErrorLog.exception_time.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": [InfraApiErrorLogResponse.from_orm(log) for log in logs],
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/error-log/{log_id}", response_model=InfraApiErrorLogResponse)
async def get_api_error_log_detail(
    log_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取API错误日志详情"""
    log = db.query(InfraApiErrorLog).filter(
        InfraApiErrorLog.id == log_id,
        InfraApiErrorLog.deleted == False
    ).first()
    
    if not log:
        raise HTTPException(status_code=404, detail="日志不存在")
    
    return InfraApiErrorLogResponse.from_orm(log)

@router.put("/error-log/{log_id}/process", response_model=dict)
async def process_api_error_log(
    log_id: int,
    process_data: InfraApiErrorLogUpdate,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """处理API错误日志"""
    log = db.query(InfraApiErrorLog).filter(
        InfraApiErrorLog.id == log_id,
        InfraApiErrorLog.deleted == False
    ).first()
    
    if not log:
        raise HTTPException(status_code=404, detail="日志不存在")
    
    log.process_status = process_data.process_status
    log.process_user_id = process_data.process_user_id or current_admin["id"]
    log.process_time = datetime.utcnow()
    
    db.commit()
    db.refresh(log)
    
    return {"message": "处理成功", "log": InfraApiErrorLogResponse.from_orm(log)}

# 统计接口
@router.get("/stats/summary", response_model=dict)
async def get_log_summary(
    days: int = Query(7, ge=1, le=30, description="统计天数"),
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取日志统计概览"""
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=days)
    
    # API访问统计
    access_stats = db.query(
        func.count(InfraApiAccessLog.id).label('total_requests'),
        func.sum(func.case([(InfraApiAccessLog.result_code == 0, 1)], else_=0)).label('success_requests'),
        func.sum(func.case([(InfraApiAccessLog.result_code != 0, 1)], else_=0)).label('error_requests'),
        func.avg(InfraApiAccessLog.duration).label('avg_duration')
    ).filter(
        InfraApiAccessLog.begin_time >= start_date,
        InfraApiAccessLog.deleted == False
    ).first()
    
    # API错误统计
    error_stats = db.query(
        func.count(InfraApiErrorLog.id).label('total_errors'),
        func.sum(func.case([(InfraApiErrorLog.process_status == 0, 1)], else_=0)).label('unprocessed_errors'),
        func.sum(func.case([(InfraApiErrorLog.process_status == 1, 1)], else_=0)).label('processed_errors')
    ).filter(
        InfraApiErrorLog.exception_time >= start_date,
        InfraApiErrorLog.deleted == False
    ).first()
    
    # 每日趋势
    daily_stats = []
    for i in range(days):
        date = start_date + timedelta(days=i)
        next_date = date + timedelta(days=1)
        
        daily_access = db.query(func.count(InfraApiAccessLog.id)).filter(
            InfraApiAccessLog.begin_time >= date,
            InfraApiAccessLog.begin_time < next_date,
            InfraApiAccessLog.deleted == False
        ).scalar() or 0
        
        daily_errors = db.query(func.count(InfraApiErrorLog.id)).filter(
            InfraApiErrorLog.exception_time >= date,
            InfraApiErrorLog.exception_time < next_date,
            InfraApiErrorLog.deleted == False
        ).scalar() or 0
        
        daily_stats.append({
            "date": date.strftime("%Y-%m-%d"),
            "access_count": daily_access,
            "error_count": daily_errors
        })
    
    return {
        "access_stats": {
            "total_requests": access_stats.total_requests or 0,
            "success_requests": access_stats.success_requests or 0,
            "error_requests": access_stats.error_requests or 0,
            "success_rate": round((access_stats.success_requests or 0) / max(access_stats.total_requests or 1, 1) * 100, 2),
            "avg_duration": round(access_stats.avg_duration or 0, 2)
        },
        "error_stats": {
            "total_errors": error_stats.total_errors or 0,
            "unprocessed_errors": error_stats.unprocessed_errors or 0,
            "processed_errors": error_stats.processed_errors or 0,
            "process_rate": round((error_stats.processed_errors or 0) / max(error_stats.total_errors or 1, 1) * 100, 2)
        },
        "daily_trend": daily_stats
    }