from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from datetime import timedelta
from typing import Optional

from app.core.database import get_db
from app.core.security import create_access_token, verify_password, get_current_admin
from app.models.admin import AdminUser
from app.schemas.admin import AdminLogin, AdminUserResponse, AdminUserCreate, AdminUserUpdate

router = APIRouter(prefix="/auth", tags=["后台认证"])

@router.post("/login")
async def admin_login(
    login_data: AdminLogin,
    db: Session = Depends(get_db)
):
    """管理员登录"""
    user = db.query(AdminUser).filter(
        AdminUser.username == login_data.username,
        AdminUser.deleted == False
    ).first()
    
    if not user or not verify_password(login_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="用户名或密码错误"
        )
    
    if user.status == 0:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="账户已被禁用"
        )
    
    # 更新最后登录时间
    user.last_login_time = datetime.now()
    db.commit()
    
    # 创建token
    access_token = create_access_token(
        data={"sub": str(user.id), "type": "admin"},
        expires_delta=timedelta(hours=24)
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": AdminUserResponse.from_orm(user)
    }

@router.post("/register")
async def admin_register(
    user_data: AdminUserCreate,
    db: Session = Depends(get_db)
):
    """管理员注册（超级管理员使用）"""
    # 检查用户名是否已存在
    existing_user = db.query(AdminUser).filter(
        AdminUser.username == user_data.username
    ).first()
    
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="用户名已存在"
        )
    
    # 创建新用户
    user = AdminUser(
        username=user_data.username,
        password_hash=get_password_hash(user_data.password),
        real_name=user_data.real_name,
        email=user_data.email,
        phone=user_data.phone,
        role=user_data.role,
        status=1
    )
    
    db.add(user)
    db.commit()
    db.refresh(user)
    
    return AdminUserResponse.from_orm(user)

@router.get("/profile")
async def get_admin_profile(
    current_admin: AdminUser = Depends(get_current_admin)
):
    """获取管理员信息"""
    return AdminUserResponse.from_orm(current_admin)

@router.put("/profile")
async def update_admin_profile(
    user_update: AdminUserUpdate,
    current_admin: AdminUser = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """更新管理员信息"""
    update_data = user_update.dict(exclude_unset=True)
    if "password" in update_data:
        update_data["password_hash"] = get_password_hash(update_data.pop("password"))
    
    for field, value in update_data.items():
        setattr(current_admin, field, value)
    
    db.commit()
    db.refresh(current_admin)
    return AdminUserResponse.from_orm(current_admin)