from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Optional, List
from datetime import datetime
import json
import os
import uuid

from app.core.database import get_db
from app.core.security import get_current_admin
from app.models.member_store import MemberStoreInfo, MemberStoreStaff
from app.models.member import Member

router = APIRouter(prefix="/member-store", tags=["会员门店管理"])

@router.get("/list")
async def get_member_store_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    keyword: Optional[str] = None,
    status: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取会员门店信息列表"""
    query = db.query(MemberStoreInfo).filter(MemberStoreInfo.deleted == False)
    
    if keyword:
        query = query.filter(
            (MemberStoreInfo.store_name.contains(keyword)) |
            (MemberStoreInfo.store_address.contains(keyword)) |
            (MemberStoreInfo.store_phone.contains(keyword))
        )
    
    if status is not None:
        query = query.filter(MemberStoreInfo.status == status)
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            query = query.filter(MemberStoreInfo.created_at >= start_dt)
        except ValueError:
            pass
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            end_dt = end_dt.replace(hour=23, minute=59, second=59)
            query = query.filter(MemberStoreInfo.created_at <= end_dt)
        except ValueError:
            pass
    
    total = query.count()
    stores = query.order_by(MemberStoreInfo.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    # 获取关联的会员信息
    result = []
    for store in stores:
        member = db.query(Member).filter(Member.id == store.member_id).first()
        result.append({
            "id": store.id,
            "member_id": store.member_id,
            "member": {
                "id": member.id if member else None,
                "nickname": member.nickname if member else None,
                "phone": member.phone if member else None
            },
            "store_name": store.store_name,
            "store_address": store.store_address,
            "store_phone": store.store_phone,
            "business_license": store.business_license,
            "legal_person": store.legal_person,
            "legal_phone": store.legal_phone,
            "legal_id_card": store.legal_id_card,
            "store_images": json.loads(store.store_images) if store.store_images else [],
            "license_images": json.loads(store.license_images) if store.license_images else [],
            "id_card_images": json.loads(store.id_card_images) if store.id_card_images else [],
            "status": store.status,
            "audit_remark": store.audit_remark,
            "audit_time": store.audit_time,
            "created_at": store.created_at,
            "updated_at": store.updated_at
        })
    
    return {
        "list": result,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/detail/{store_id}")
async def get_member_store_detail(
    store_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取会员门店详情"""
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.id == store_id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店信息不存在")
    
    member = db.query(Member).filter(Member.id == store.member_id).first()
    
    # 获取员工列表
    staff = db.query(MemberStoreStaff).filter(
        MemberStoreStaff.store_id == store_id,
        MemberStoreStaff.deleted == False
    ).all()
    
    return {
        "store": {
            "id": store.id,
            "member_id": store.member_id,
            "member": {
                "id": member.id if member else None,
                "nickname": member.nickname if member else None,
                "phone": member.phone if member else None
            },
            "store_name": store.store_name,
            "store_address": store.store_address,
            "store_phone": store.store_phone,
            "business_license": store.business_license,
            "legal_person": store.legal_person,
            "legal_phone": store.legal_phone,
            "legal_id_card": store.legal_id_card,
            "store_images": json.loads(store.store_images) if store.store_images else [],
            "license_images": json.loads(store.license_images) if store.license_images else [],
            "id_card_images": json.loads(store.id_card_images) if store.id_card_images else [],
            "status": store.status,
            "audit_remark": store.audit_remark,
            "audit_time": store.audit_time,
            "audit_admin_id": store.audit_admin_id,
            "created_at": store.created_at,
            "updated_at": store.updated_at
        },
        "staff": staff
    }

@router.post("/create")
async def create_member_store(
    member_id: int,
    store_name: str,
    store_address: Optional[str] = None,
    store_phone: Optional[str] = None,
    business_license: Optional[str] = None,
    legal_person: Optional[str] = None,
    legal_phone: Optional[str] = None,
    legal_id_card: Optional[str] = None,
    store_images: Optional[List[str]] = None,
    license_images: Optional[List[str]] = None,
    id_card_images: Optional[List[str]] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """创建会员门店信息"""
    # 检查会员是否存在
    member = db.query(Member).filter(
        Member.id == member_id,
        Member.deleted == False
    ).first()
    
    if not member:
        raise HTTPException(status_code=404, detail="会员不存在")
    
    # 检查是否已存在门店信息
    existing_store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.member_id == member_id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if existing_store:
        raise HTTPException(status_code=400, detail="该会员已存在门店信息")
    
    store = MemberStoreInfo(
        member_id=member_id,
        store_name=store_name,
        store_address=store_address,
        store_phone=store_phone,
        business_license=business_license,
        legal_person=legal_person,
        legal_phone=legal_phone,
        legal_id_card=legal_id_card,
        store_images=json.dumps(store_images) if store_images else None,
        license_images=json.dumps(license_images) if license_images else None,
        id_card_images=json.dumps(id_card_images) if id_card_images else None,
        status=1  # 待审核
    )
    
    db.add(store)
    db.commit()
    db.refresh(store)
    
    return {"message": "门店信息创建成功", "store_id": store.id}

@router.put("/update/{store_id}")
async def update_member_store(
    store_id: int,
    store_name: Optional[str] = None,
    store_address: Optional[str] = None,
    store_phone: Optional[str] = None,
    business_license: Optional[str] = None,
    legal_person: Optional[str] = None,
    legal_phone: Optional[str] = None,
    legal_id_card: Optional[str] = None,
    store_images: Optional[List[str]] = None,
    license_images: Optional[List[str]] = None,
    id_card_images: Optional[List[str]] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """更新会员门店信息"""
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.id == store_id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店信息不存在")
    
    update_data = {}
    if store_name is not None:
        update_data["store_name"] = store_name
    if store_address is not None:
        update_data["store_address"] = store_address
    if store_phone is not None:
        update_data["store_phone"] = store_phone
    if business_license is not None:
        update_data["business_license"] = business_license
    if legal_person is not None:
        update_data["legal_person"] = legal_person
    if legal_phone is not None:
        update_data["legal_phone"] = legal_phone
    if legal_id_card is not None:
        update_data["legal_id_card"] = legal_id_card
    if store_images is not None:
        update_data["store_images"] = json.dumps(store_images)
    if license_images is not None:
        update_data["license_images"] = json.dumps(license_images)
    if id_card_images is not None:
        update_data["id_card_images"] = json.dumps(id_card_images)
    
    for field, value in update_data.items():
        setattr(store, field, value)
    
    db.commit()
    db.refresh(store)
    
    return {"message": "门店信息更新成功", "store": store}

@router.put("/audit/{store_id}")
async def audit_member_store(
    store_id: int,
    status: int,
    audit_remark: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """审核会员门店信息"""
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.id == store_id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店信息不存在")
    
    if status not in [1, 2, 3]:  # 1待审核 2已通过 3已拒绝
        raise HTTPException(status_code=400, detail="无效的状态值")
    
    store.status = status
    store.audit_remark = audit_remark
    store.audit_time = datetime.now()
    store.audit_admin_id = current_admin["id"]
    
    db.commit()
    db.refresh(store)
    
    return {"message": "审核完成", "store": store}

@router.delete("/{store_id}")
async def delete_member_store(
    store_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """删除会员门店信息"""
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.id == store_id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店信息不存在")
    
    store.deleted = True
    db.commit()
    
    return {"message": "门店信息删除成功"}

# 员工管理
@router.get("/staff/list/{store_id}")
async def get_store_staff_list(
    store_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    status: Optional[int] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """获取门店员工列表"""
    query = db.query(MemberStoreStaff).filter(
        MemberStoreStaff.store_id == store_id,
        MemberStoreStaff.deleted == False
    )
    
    if status is not None:
        query = query.filter(MemberStoreStaff.status == status)
    
    total = query.count()
    staff = query.order_by(MemberStoreStaff.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": staff,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.post("/staff/create")
async def create_store_staff(
    store_id: int,
    name: str,
    phone: str,
    position: Optional[str] = None,
    id_card: Optional[str] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """创建门店员工"""
    # 检查门店是否存在
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.id == store_id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店信息不存在")
    
    staff = MemberStoreStaff(
        store_id=store_id,
        name=name,
        phone=phone,
        position=position,
        id_card=id_card,
        status=1,
        hire_date=datetime.now()
    )
    
    db.add(staff)
    db.commit()
    db.refresh(staff)
    
    return {"message": "员工创建成功", "staff": staff}

@router.put("/staff/update/{staff_id}")
async def update_store_staff(
    staff_id: int,
    name: Optional[str] = None,
    phone: Optional[str] = None,
    position: Optional[str] = None,
    id_card: Optional[str] = None,
    status: Optional[int] = None,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """更新员工信息"""
    staff = db.query(MemberStoreStaff).filter(
        MemberStoreStaff.id == staff_id,
        MemberStoreStaff.deleted == False
    ).first()
    
    if not staff:
        raise HTTPException(status_code=404, detail="员工不存在")
    
    update_data = {}
    if name is not None:
        update_data["name"] = name
    if phone is not None:
        update_data["phone"] = phone
    if position is not None:
        update_data["position"] = position
    if id_card is not None:
        update_data["id_card"] = id_card
    if status is not None:
        update_data["status"] = status
        if status == 0:  # 离职
            update_data["leave_date"] = datetime.now()
    
    for field, value in update_data.items():
        setattr(staff, field, value)
    
    db.commit()
    db.refresh(staff)
    
    return {"message": "员工信息更新成功", "staff": staff}

@router.delete("/staff/{staff_id}")
async def delete_store_staff(
    staff_id: int,
    db: Session = Depends(get_db),
    current_admin: dict = Depends(get_current_admin)
):
    """删除员工"""
    staff = db.query(MemberStoreStaff).filter(
        MemberStoreStaff.id == staff_id,
        MemberStoreStaff.deleted == False
    ).first()
    
    if not staff:
        raise HTTPException(status_code=404, detail="员工不存在")
    
    staff.deleted = True
    db.commit()
    
    return {"message": "员工删除成功"}

@router.post("/upload-image")
async def upload_store_image(
    file: UploadFile = File(...),
    current_admin: dict = Depends(get_current_admin)
):
    """上传门店相关图片"""
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="请上传图片文件")
    
    # 生成唯一文件名
    file_extension = file.filename.split('.')[-1]
    filename = f"{uuid.uuid4().hex}.{file_extension}"
    
    # 保存文件
    upload_dir = "uploads/member-stores"
    os.makedirs(upload_dir, exist_ok=True)
    file_path = os.path.join(upload_dir, filename)
    
    with open(file_path, "wb") as buffer:
        content = await file.read()
        buffer.write(content)
    
    # 返回可访问的URL
    file_url = f"/uploads/member-stores/{filename}"
    
    return {"url": file_url}