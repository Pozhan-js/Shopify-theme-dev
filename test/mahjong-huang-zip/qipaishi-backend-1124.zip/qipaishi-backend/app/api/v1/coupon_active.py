"""
优惠券活动相关接口
补充24h_qipaishi微信小程序缺失的优惠券活动接口
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Path
from sqlalchemy.orm import Session
from sqlalchemy import and_
from typing import Optional, List
from datetime import datetime

from app.core.database import get_db
from app.models.complete_models import MemberCoupon, MemberCouponActive
from app.schemas.coupon_active import (
    CouponActiveResponse, 
    CouponActiveCreate, 
    CouponActiveUpdate
)

router = APIRouter(prefix="/member/couponActive", tags=["优惠券活动"])

@router.get("/getById")
async def get_coupon_active_by_id(
    coupon_id: int = Query(..., description="优惠券ID"),
    db: Session = Depends(get_db)
):
    """根据ID获取优惠券活动"""
    coupon_active = db.query(MemberCouponActive).filter(
        MemberCouponActive.id == coupon_id,
        MemberCouponActive.deleted == False
    ).first()
    
    if not coupon_active:
        raise HTTPException(status_code=404, detail="优惠券活动不存在")
    
    return {
        "code": 200,
        "msg": "success",
        "data": {
            "id": coupon_active.id,
            "coupon_name": coupon_active.coupon_name,
            "coupon_type": coupon_active.coupon_type,
            "coupon_value": float(coupon_active.coupon_value),
            "min_amount": float(coupon_active.min_amount),
            "start_time": coupon_active.start_time,
            "end_time": coupon_active.end_time,
            "total_count": coupon_active.total_count,
            "used_count": coupon_active.used_count,
            "status": coupon_active.status,
            "description": coupon_active.description
        }
    }

@router.post("/putCoupon")
async def put_coupon(
    coupon_id: int = Query(..., description="优惠券ID"),
    user_id: int = Query(..., description="用户ID"),
    db: Session = Depends(get_db)
):
    """领取优惠券"""
    # 检查优惠券活动是否存在
    coupon_active = db.query(MemberCouponActive).filter(
        MemberCouponActive.id == coupon_id,
        MemberCouponActive.deleted == False,
        MemberCouponActive.status == 1
    ).first()
    
    if not coupon_active:
        raise HTTPException(status_code=404, detail="优惠券活动不存在或已下架")
    
    # 检查是否已领取
    existing_coupon = db.query(MemberCoupon).filter(
        MemberCoupon.coupon_id == coupon_id,
        MemberCoupon.user_id == user_id,
        MemberCoupon.deleted == False
    ).first()
    
    if existing_coupon:
        return {"code": 400, "msg": "已领取过该优惠券"}
    
    # 检查库存
    if coupon_active.used_count >= coupon_active.total_count:
        return {"code": 400, "msg": "优惠券已领完"}
    
    # 创建用户优惠券
    new_coupon = MemberCoupon(
        coupon_id=coupon_id,
        user_id=user_id,
        coupon_code=f"COUPON_{user_id}_{coupon_id}_{int(datetime.now().timestamp())}",
        status=0,  # 未使用
        create_time=datetime.now()
    )
    
    # 更新已领取数量
    coupon_active.used_count += 1
    
    db.add(new_coupon)
    db.commit()
    
    return {"code": 200, "msg": "领取成功"}

@router.post("/saveAdminByCouponId")
async def save_admin_by_coupon_id(
    coupon_data: dict,
    db: Session = Depends(get_db)
):
    """管理员保存优惠券活动"""
    coupon_id = coupon_data.get("couponId")
    
    if coupon_id:
        # 更新现有优惠券
        coupon_active = db.query(MemberCouponActive).filter(
            MemberCouponActive.id == coupon_id,
            MemberCouponActive.deleted == False
        ).first()
        
        if not coupon_active:
            raise HTTPException(status_code=404, detail="优惠券活动不存在")
        
        for key, value in coupon_data.items():
            if hasattr(coupon_active, key):
                setattr(coupon_active, key, value)
        
        coupon_active.update_time = datetime.now()
    else:
        # 创建新优惠券
        coupon_active = MemberCouponActive(**coupon_data)
        db.add(coupon_active)
    
    db.commit()
    
    return {"code": 200, "msg": "保存成功"}

@router.get("/getAdminByCouponId")
async def get_admin_by_coupon_id(
    coupon_id: int = Query(..., description="优惠券ID"),
    db: Session = Depends(get_db)
):
    """管理员获取优惠券活动"""
    coupon_active = db.query(MemberCouponActive).filter(
        MemberCouponActive.id == coupon_id,
        MemberCouponActive.deleted == False
    ).first()
    
    if not coupon_active:
        raise HTTPException(status_code=404, detail="优惠券活动不存在")
    
    return {
        "code": 200,
        "msg": "success",
        "data": {
            "id": coupon_active.id,
            "coupon_name": coupon_active.coupon_name,
            "coupon_type": coupon_active.coupon_type,
            "coupon_value": float(coupon_active.coupon_value),
            "min_amount": float(coupon_active.min_amount),
            "start_time": coupon_active.start_time,
            "end_time": coupon_active.end_time,
            "total_count": coupon_active.total_count,
            "used_count": coupon_active.used_count,
            "status": coupon_active.status,
            "description": coupon_active.description,
            "create_time": coupon_active.create_time
        }
    }

@router.post("/stopActive")
async def stop_active(
    coupon_id: int = Query(..., description="优惠券ID"),
    db: Session = Depends(get_db)
):
    """停止优惠券活动"""
    coupon_active = db.query(MemberCouponActive).filter(
        MemberCouponActive.id == coupon_id,
        MemberCouponActive.deleted == False
    ).first()
    
    if not coupon_active:
        raise HTTPException(status_code=404, detail="优惠券活动不存在")
    
    coupon_active.status = 0  # 停止
    coupon_active.update_time = datetime.now()
    db.commit()
    
    return {"code": 200, "msg": "停止成功"}

@router.get("/list")
async def get_coupon_active_list(
    status: Optional[int] = Query(None, description="状态：0-全部 1-进行中 2-已结束"),
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(10, ge=1, le=100, description="每页条数"),
    db: Session = Depends(get_db)
):
    """获取优惠券活动列表"""
    query = db.query(MemberCouponActive).filter(MemberCouponActive.deleted == False)
    
    if status is not None:
        query = query.filter(MemberCouponActive.status == status)
    
    total = query.count()
    coupons = query.order_by(MemberCouponActive.create_time.desc()).offset((page-1)*page_size).limit(page_size).all()
    
    return {
        "code": 200,
        "msg": "success",
        "data": {
            "list": [{
                "id": coupon.id,
                "coupon_name": coupon.coupon_name,
                "coupon_type": coupon.coupon_type,
                "coupon_value": float(coupon.coupon_value),
                "min_amount": float(coupon.min_amount),
                "start_time": coupon.start_time,
                "end_time": coupon.end_time,
                "total_count": coupon.total_count,
                "used_count": coupon.used_count,
                "status": coupon.status,
                "description": coupon.description
            } for coupon in coupons],
            "total": total
        }
    }