from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import datetime, timedelta

from app.core.database import get_db
from app.models.store import Store, Room, RoomSchedule
from app.models.order import Order
from app.core.security import get_current_member

router = APIRouter(prefix="/store", tags=["门店"])

@router.get("/list")
async def get_store_list(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    keyword: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """获取门店列表"""
    query = db.query(Store).filter(Store.deleted == False, Store.status == 1)
    
    if keyword:
        query = query.filter(Store.name.contains(keyword))
    
    total = query.count()
    stores = query.offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": stores,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/detail/{store_id}")
async def get_store_detail(
    store_id: int,
    db: Session = Depends(get_db)
):
    """获取门店详情"""
    store = db.query(Store).filter(
        Store.id == store_id,
        Store.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店不存在")
    
    return store

@router.get("/room/list")
async def get_room_list(
    store_id: int = Query(...),
    room_type: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """获取房间列表"""
    query = db.query(Room).filter(
        Room.store_id == store_id,
        Room.deleted == False,
        Room.status == 1
    )
    
    if room_type:
        query = query.filter(Room.type == room_type)
    
    rooms = query.all()
    return {"list": rooms}

@router.get("/room/detail/{room_id}")
async def get_room_detail(
    room_id: int,
    db: Session = Depends(get_db)
):
    """获取房间详情"""
    room = db.query(Room).filter(
        Room.id == room_id,
        Room.deleted == False
    ).first()
    
    if not room:
        raise HTTPException(status_code=404, detail="房间不存在")
    
    return room

@router.get("/room/schedule")
async def get_room_schedule(
    room_id: int = Query(...),
    date: str = Query(...),
    db: Session = Depends(get_db)
):
    """获取房间排班信息"""
    # 解析日期
    try:
        query_date = datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        raise HTTPException(status_code=400, detail="日期格式错误")
    
    # 获取排班信息
    schedules = db.query(RoomSchedule).filter(
        RoomSchedule.room_id == room_id,
        RoomSchedule.date == query_date,
        RoomSchedule.deleted == False
    ).all()
    
    # 获取已预约的时间段
    orders = db.query(Order).filter(
        Order.room_id == room_id,
        Order.appointment_date == query_date,
        Order.status.in_([2, 3]),  # 已支付或已完成
        Order.deleted == False
    ).all()
    
    # 构建时间槽
    time_slots = []
    for hour in range(8, 24):  # 8:00-24:00
        time_str = f"{hour:02d}:00"
        is_available = True
        
        # 检查排班
        for schedule in schedules:
            if schedule.start_time <= time_str < schedule.end_time:
                if schedule.status == 0:
                    is_available = False
                break
        
        # 检查已预约
        for order in orders:
            if order.start_time <= time_str < order.end_time:
                is_available = False
                break
        
        time_slots.append({
            "time": time_str,
            "available": is_available
        })
    
    return {"list": time_slots}