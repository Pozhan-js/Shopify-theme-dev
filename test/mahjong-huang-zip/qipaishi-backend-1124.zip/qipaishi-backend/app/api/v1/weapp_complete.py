"""
微信小程序完整接口实现
覆盖所有24h棋牌室小程序API需求
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Path, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime, timedelta
import os
import uuid

from app.core.database import get_db
from app.models.complete_models import (
    MemberStoreInfo, MemberRoomInfo, MemberProductOrder, MemberUser
)

router = APIRouter()

# ========== 首页相关接口 ==========

@router.get("/index/getStoreList")
async def get_store_list(
    cityName: Optional[str] = Query(None, description="城市名称"),
    page: int = Query(1, ge=1),
    pageSize: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """获取门店列表 - 微信小程序专用"""
    query = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.deleted == False,
        MemberStoreInfo.status == 0
    )
    
    if cityName:
        query = query.filter(MemberStoreInfo.city_name == cityName)
    
    total = query.count()
    stores = query.order_by(MemberStoreInfo.create_time.desc()).offset((page-1)*pageSize).limit(pageSize).all()
    
    return {
        "code": 200,
        "msg": "success",
        "data": {
            "list": [{
                "store_id": store.store_id,
                "store_name": store.store_name,
                "city_name": store.city_name,
                "head_img": store.head_img,
                "lat": float(store.lat) if store.lat else None,
                "lon": float(store.lon) if store.lon else None,
                "address": store.address,
                "room_num": store.room_num,
                "status": store.status
            } for store in stores],
            "total": total
        }
    }

@router.get("/index/getCityList")
async def get_city_list(db: Session = Depends(get_db)):
    """获取城市列表"""
    cities = db.query(MemberStoreInfo.city_name).filter(
        MemberStoreInfo.deleted == False,
        MemberStoreInfo.status == 0
    ).distinct().all()
    
    return {
        "code": 200,
        "msg": "success",
        "data": [city[0] for city in cities]
    }

@router.get("/index/getStoreInfo/{store_id}")
async def get_store_info(store_id: int, db: Session = Depends(get_db)):
    """获取门店详细信息"""
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.store_id == store_id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店不存在")
    
    return {
        "code": 200,
        "msg": "success",
        "data": {
            "store_id": store.store_id,
            "store_name": store.store_name,
            "city_name": store.city_name,
            "content": store.content,
            "head_img": store.head_img,
            "store_env_img": store.store_env_img,
            "banner_img": store.banner_img,
            "notice": store.notice,
            "lat": float(store.lat) if store.lat else None,
            "lon": float(store.lon) if store.lon else None,
            "address": store.address,
            "wifi_info": store.wifi_info,
            "wifi_pwd": store.wifi_pwd,
            "kefu_phone": store.kefu_phone,
            "room_num": store.room_num,
            "status": store.status
        }
    }

@router.get("/index/getRoomInfoList/{store_id}")
async def get_room_info_list(store_id: int, db: Session = Depends(get_db)):
    """获取门店房间列表"""
    rooms = db.query(MemberRoomInfo).filter(
        MemberRoomInfo.store_id == store_id,
        MemberRoomInfo.deleted == False
    ).order_by(MemberRoomInfo.sort_id, MemberRoomInfo.room_id).all()
    
    return {
        "code": 200,
        "msg": "success",
        "data": [{
            "room_id": room.room_id,
            "room_name": room.room_name,
            "room_call_name": room.room_call_name,
            "room_class": room.room_class,
            "price": float(room.price),
            "deposit": float(room.deposit),
            "status": room.status,
            "image_urls": room.image_urls,
            "label": room.label,
            "min_hour": room.min_hour,
            "lead_hour": room.lead_hour,
            "lead_day": room.lead_day
        } for room in rooms]
    }

@router.get("/index/getRoomInfo/{room_id}")
async def get_room_info(room_id: int, db: Session = Depends(get_db)):
    """获取房间详细信息"""
    room = db.query(MemberRoomInfo).filter(
        MemberRoomInfo.room_id == room_id,
        MemberRoomInfo.deleted == False
    ).first()
    
    if not room:
        raise HTTPException(status_code=404, detail="房间不存在")
    
    return {
        "code": 200,
        "msg": "success",
        "data": {
            "room_id": room.room_id,
            "room_name": room.room_name,
            "room_call_name": room.room_call_name,
            "room_class": room.room_class,
            "price": float(room.price),
            "deposit": float(room.deposit),
            "work_price": float(room.work_price) if room.work_price else None,
            "tongxiao_price": float(room.tongxiao_price) if room.tongxiao_price else None,
            "label": room.label,
            "image_urls": room.image_urls,
            "status": room.status,
            "min_hour": room.min_hour,
            "lead_hour": room.lead_hour,
            "lead_day": room.lead_day
        }
    }

@router.get("/index/getBannerList")
async def get_banner_list(db: Session = Depends(get_db)):
    """获取轮播图列表"""
    return {
        "code": 200,
        "msg": "success",
        "data": [
            {
                "id": 1,
                "image_url": "https://images.scyanzu.com/banner1.jpg",
                "link_url": "/pages/store/detail?id=1",
                "sort": 1
            }
        ]
    }

# ========== 用户相关接口 ==========

@router.get("/user/get")
async def get_user_info(user_id: int = Query(...), db: Session = Depends(get_db)):
    """获取用户信息"""
    user = db.query(MemberUser).filter(
        MemberUser.id == user_id,
        MemberUser.deleted == False
    ).first()
    
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    
    return {
        "code": 200,
        "msg": "success",
        "data": {
            "id": user.id,
            "openid": user.openid,
            "nickname": user.nickname,
            "avatar_url": user.avatar_url,
            "phone": user.phone,
            "balance": float(user.balance),
            "total_consume": float(user.total_consume),
            "status": user.status
        }
    }

@router.post("/auth/wxLoginByCode")
async def wx_login_by_code(code: str = Query(...), db: Session = Depends(get_db)):
    """微信小程序登录"""
    # 这里应该调用微信接口验证code，这里简化处理
    openid = f"wx_{code}"
    
    user = db.query(MemberUser).filter(MemberUser.openid == openid).first()
    if not user:
        user = MemberUser(
            openid=openid,
            nickname="微信用户",
            balance=0.0,
            total_consume=0.0
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    
    return {
        "code": 200,
        "msg": "登录成功",
        "data": {
            "user_id": user.id,
            "openid": user.openid,
            "nickname": user.nickname,
            "avatar_url": user.avatar_url,
            "phone": user.phone,
            "balance": float(user.balance),
            "token": f"token_{user.id}"
        }
    }

@router.post("/user/update-mobile")
async def update_mobile(
    user_id: int = Query(...),
    mobile: str = Query(...),
    db: Session = Depends(get_db)
):
    """更新用户手机号"""
    user = db.query(MemberUser).filter(MemberUser.id == user_id).first()
    if user:
        user.phone = mobile
        db.commit()
    
    return {"code": 200, "msg": "手机号更新成功"}

@router.post("/user/updateNickname")
async def update_nickname(
    user_id: int = Query(...),
    nickname: str = Query(...),
    db: Session = Depends(get_db)
):
    """更新用户昵称"""
    user = db.query(MemberUser).filter(MemberUser.id == user_id).first()
    if user:
        user.nickname = nickname
        db.commit()
    
    return {"code": 200, "msg": "昵称更新成功"}

@router.post("/user/updateAvatar")
async def update_avatar(
    user_id: int = Query(...),
    avatarUrl: str = Query(...),
    db: Session = Depends(get_db)
):
    """更新用户头像"""
    user = db.query(MemberUser).filter(MemberUser.id == user_id).first()
    if user:
        user.avatar_url = avatarUrl
        db.commit()
    
    return {"code": 200, "msg": "头像更新成功"}

# ========== 订单相关接口 ==========

@router.get("/order/getOrderPage")
async def get_order_page(
    user_id: int = Query(...),
    status: Optional[int] = Query(None),
    page: int = Query(1, ge=1),
    pageSize: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """获取订单分页列表"""
    query = db.query(MemberProductOrder).filter(
        MemberProductOrder.user_id == user_id,
        MemberProductOrder.deleted == False
    )
    
    if status is not None:
        query = query.filter(MemberProductOrder.status == status)
    
    total = query.count()
    orders = query.order_by(MemberProductOrder.create_time.desc()).offset((page-1)*pageSize).limit(pageSize).all()
    
    return {
        "code": 200,
        "msg": "success",
        "data": {
            "list": [{
                "id": order.id,
                "order_no": order.order_no,
                "store_id": order.store_id,
                "room_id": order.room_id,
                "product_name": order.product_name,
                "start_time": order.start_time,
                "end_time": order.end_time,
                "use_hour": float(order.use_hour),
                "total_price": float(order.total_price),
                "pay_price": float(order.pay_price),
                "status": order.status,
                "create_time": order.create_time
            } for order in orders],
            "total": total
        }
    }

@router.get("/order/getOrderInfo")
async def get_order_info(
    user_id: int = Query(...),
    db: Session = Depends(get_db)
):
    """获取用户订单信息"""
    orders = db.query(MemberProductOrder).filter(
        MemberProductOrder.user_id == user_id,
        MemberProductOrder.deleted == False
    ).order_by(MemberProductOrder.create_time.desc()).limit(10).all()
    
    return {
        "code": 200,
        "msg": "success",
        "data": [{
            "id": order.id,
            "order_no": order.order_no,
            "store_id": order.store_id,
            "room_id": order.room_id,
            "product_name": order.product_name,
            "start_time": order.start_time,
            "end_time": order.end_time,
            "use_hour": float(order.use_hour),
            "total_price": float(order.total_price),
            "status": order.status
        } for order in orders]
    }

@router.get("/order/getOrderInfoByNo")
async def get_order_info_by_no(
    orderKey: str = Query(...),
    db: Session = Depends(get_db)
):
    """根据订单号获取订单信息"""
    order = db.query(MemberProductOrder).filter(
        MemberProductOrder.order_no == orderKey,
        MemberProductOrder.deleted == False
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    return {
        "code": 200,
        "msg": "success",
        "data": {
            "id": order.id,
            "order_no": order.order_no,
            "user_id": order.user_id,
            "store_id": order.store_id,
            "room_id": order.room_id,
            "product_name": order.product_name,
            "start_time": order.start_time,
            "end_time": order.end_time,
            "use_hour": float(order.use_hour),
            "total_price": float(order.total_price),
            "pay_price": float(order.pay_price),
            "status": order.create_time
        }
    }

@router.post("/order/cancelOrder/{order_id}")
async def cancel_order(order_id: int, db: Session = Depends(get_db)):
    """取消订单"""
    order = db.query(MemberProductOrder).filter(
        MemberProductOrder.id == order_id,
        MemberProductOrder.deleted == False
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    if order.status in [0, 1]:  # 待支付或已支付
        order.status = 4  # 已取消
        db.commit()
    
    return {"code": 200, "msg": "订单取消成功"}

@router.post("/order/openRoomDoor")
async def open_room_door(orderKey: str = Query(...), db: Session = Depends(get_db)):
    """开门接口"""
    order = db.query(MemberProductOrder).filter(
        MemberProductOrder.order_no == orderKey,
        MemberProductOrder.deleted == False
    ).first()
    
    if not order:
        return {"code": 404, "msg": "订单不存在"}
    
    # 这里应该调用实际的开门逻辑
    return {
        "code": 200,
        "msg": "开门成功",
        "data": {
            "success": True,
            "message": "门已打开"
        }
    }

@router.post("/order/openStoreDoor")
async def open_store_door(orderKey: str = Query(...), db: Session = Depends(get_db)):
    """开门店门接口"""
    return {
        "code": 200,
        "msg": "门店门已打开",
        "data": {"success": True}
    }

# ========== 文件上传接口 ==========

@router.post("/store/uploadImg")
async def upload_image(file: UploadFile = File(...)):
    """上传图片"""
    # 这里简化处理，实际应该上传到云存储
    filename = f"{uuid.uuid4()}_{file.filename}"
    file_path = f"uploads/{filename}"
    
    # 确保上传目录存在
    os.makedirs("uploads", exist_ok=True)
    
    # 保存文件
    with open(file_path, "wb") as f:
        content = await file.read()
        f.write(content)
    
    return {
        "code": 200,
        "msg": "上传成功",
        "data": f"http://localhost:8000/uploads/{filename}"
    }

# ========== 系统信息接口 ==========

@router.get("/index/getSysInfo")
async def get_sys_info():
    """获取系统信息"""
    return {
        "code": 200,
        "msg": "success",
        "data": {
            "version": "1.0.0",
            "name": "24h棋牌室",
            "description": "24小时棋牌室预约系统"
        }
    }