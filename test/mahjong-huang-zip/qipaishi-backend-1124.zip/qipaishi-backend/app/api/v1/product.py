from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import datetime

from app.core.database import get_db
from app.models.product import ProductCategory, Product, Coupon
from app.models.member import MemberCoupon, Member
from app.core.security import get_current_member

router = APIRouter(prefix="/product", tags=["商品"])

@router.get("/category/list")
async def get_category_list(
    status: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """获取商品分类列表"""
    query = db.query(ProductCategory).filter(ProductCategory.deleted == False)
    
    if status is not None:
        query = query.filter(ProductCategory.status == status)
    
    categories = query.order_by(ProductCategory.sort_order).all()
    return {"list": categories}

@router.get("/list")
async def get_product_list(
    category_id: Optional[int] = None,
    keyword: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """获取商品列表"""
    query = db.query(Product).filter(
        Product.deleted == False,
        Product.status == 1
    )
    
    if category_id:
        query = query.filter(Product.category_id == category_id)
    
    if keyword:
        query = query.filter(Product.name.contains(keyword))
    
    total = query.count()
    products = query.offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": products,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/detail/{product_id}")
async def get_product_detail(
    product_id: int,
    db: Session = Depends(get_db)
):
    """获取商品详情"""
    product = db.query(Product).filter(
        Product.id == product_id,
        Product.deleted == False
    ).first()
    
    if not product:
        raise HTTPException(status_code=404, detail="商品不存在")
    
    return product

@router.get("/coupon/list")
async def get_coupon_list(
    status: Optional[int] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """获取优惠券列表"""
    now = datetime.now()
    query = db.query(Coupon).filter(
        Coupon.deleted == False,
        Coupon.status == 1,
        Coupon.start_time <= now,
        Coupon.end_time >= now
    )
    
    if status is not None:
        query = query.filter(Coupon.status == status)
    
    total = query.count()
    coupons = query.offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": coupons,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.post("/coupon/receive/{coupon_id}")
async def receive_coupon(
    coupon_id: int,
    current_member: Member = Depends(get_current_member),
    db: Session = Depends(get_db)
):
    """领取优惠券"""
    coupon = db.query(Coupon).filter(
        Coupon.id == coupon_id,
        Coupon.deleted == False,
        Coupon.status == 1
    ).first()
    
    if not coupon:
        raise HTTPException(status_code=404, detail="优惠券不存在")
    
    # 检查是否已领取
    existing = db.query(MemberCoupon).filter(
        MemberCoupon.member_id == current_member.id,
        MemberCoupon.coupon_id == coupon_id,
        MemberCoupon.deleted == False
    ).first()
    
    if existing:
        raise HTTPException(status_code=400, detail="已领取过该优惠券")
    
    # 检查领取限制
    received_count = db.query(MemberCoupon).filter(
        MemberCoupon.coupon_id == coupon_id,
        MemberCoupon.deleted == False
    ).count()
    
    if coupon.total_count and received_count >= coupon.total_count:
        raise HTTPException(status_code=400, detail="优惠券已领完")
    
    user_received = db.query(MemberCoupon).filter(
        MemberCoupon.member_id == current_member.id,
        MemberCoupon.coupon_id == coupon_id,
        MemberCoupon.deleted == False
    ).count()
    
    if user_received >= coupon.limit_per_user:
        raise HTTPException(status_code=400, detail="超过领取限制")
    
    # 创建会员优惠券
    member_coupon = MemberCoupon(
        member_id=current_member.id,
        coupon_id=coupon_id,
        status=1,
        receive_time=datetime.now()
    )
    
    db.add(member_coupon)
    db.commit()
    db.refresh(member_coupon)
    
    return {"message": "领取成功"}