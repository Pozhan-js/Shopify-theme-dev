from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from typing import Optional, List
from datetime import datetime
import uuid

from app.core.database import get_db
from app.models.order import Order, OrderItem, OrderLog
from app.models.store import Room
from app.models.member import Member
from app.schemas.order import OrderCreate, OrderResponse
from app.core.security import get_current_member
from app.services.order_service import OrderService

router = APIRouter(prefix="/order", tags=["订单"])

@router.post("/create", response_model=dict)
async def create_order(
    order_data: OrderCreate,
    current_member: Member = Depends(get_current_member),
    db: Session = Depends(get_db)
):
    """创建订单"""
    order_service = OrderService(db)
    return await order_service.create_order(current_member.id, order_data)

@router.get("/list")
async def get_order_list(
    status: Optional[int] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    current_member: Member = Depends(get_current_member),
    db: Session = Depends(get_db)
):
    """获取订单列表"""
    query = db.query(Order).filter(
        Order.member_id == current_member.id,
        Order.deleted == False
    )
    
    if status:
        query = query.filter(Order.status == status)
    
    query = query.order_by(Order.create_time.desc())
    
    total = query.count()
    orders = query.offset((page - 1) * page_size).limit(page_size).all()
    
    return {
        "list": orders,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.get("/detail/{order_id}")
async def get_order_detail(
    order_id: int,
    current_member: Member = Depends(get_current_member),
    db: Session = Depends(get_db)
):
    """获取订单详情"""
    order = db.query(Order).filter(
        Order.id == order_id,
        Order.member_id == current_member.id,
        Order.deleted == False
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    return order

@router.post("/cancel/{order_id}")
async def cancel_order(
    order_id: int,
    reason: Optional[str] = None,
    current_member: Member = Depends(get_current_member),
    db: Session = Depends(get_db)
):
    """取消订单"""
    order = db.query(Order).filter(
        Order.id == order_id,
        Order.member_id == current_member.id,
        Order.deleted == False
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    if order.status != 1:  # 待支付
        raise HTTPException(status_code=400, detail="订单状态不允许取消")
    
    order.status = 4  # 已取消
    
    # 记录日志
    log = OrderLog(
        order_id=order_id,
        action="cancel",
        description=f"用户取消订单，原因：{reason or '用户主动取消'}",
        operator=f"member_{current_member.id}"
    )
    db.add(log)
    db.commit()
    
    return {"message": "订单已取消"}

@router.post("/pay/{order_id}")
async def pay_order(
    order_id: int,
    pay_type: int = Query(..., description="支付方式 1微信支付 2余额支付"),
    current_member: Member = Depends(get_current_member),
    db: Session = Depends(get_db)
):
    """支付订单"""
    order = db.query(Order).filter(
        Order.id == order_id,
        Order.member_id == current_member.id,
        Order.deleted == False
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    if order.status != 1:  # 待支付
        raise HTTPException(status_code=400, detail="订单状态不允许支付")
    
    order_service = OrderService(db)
    return await order_service.process_payment(order, pay_type)

@router.post("/refund/{order_id}")
async def refund_order(
    order_id: int,
    reason: str,
    current_member: Member = Depends(get_current_member),
    db: Session = Depends(get_db)
):
    """申请退款"""
    order = db.query(Order).filter(
        Order.id == order_id,
        Order.member_id == current_member.id,
        Order.deleted == False
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    if order.status not in [2, 3]:  # 已支付或已完成
        raise HTTPException(status_code=400, detail="订单状态不允许退款")
    
    order_service = OrderService(db)
    return await order_service.process_refund(order, reason)