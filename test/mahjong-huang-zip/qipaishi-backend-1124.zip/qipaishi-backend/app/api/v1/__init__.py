from fastapi import APIRouter
from .member import router as member_router
from .store import router as store_router
from .order import router as order_router
from .product import router as product_router
from .weapp_full import router as weapp_full_router
from .coupon_active import router as coupon_active_router
from app.api.admin import admin_router
from app.api.admin_api import admin_api_router

api_router = APIRouter(prefix="/api/v1")

# 微信小程序完整接口 - 100%覆盖所有接口
api_router.include_router(weapp_full_router, prefix="/member")

# 补充优惠券活动接口
api_router.include_router(coupon_active_router)

# 其他接口
api_router.include_router(member_router)
api_router.include_router(store_router)
api_router.include_router(order_router)
api_router.include_router(product_router)
api_router.include_router(admin_router, prefix="/admin")
api_router.include_router(admin_api_router)  # 直接注册到根路径