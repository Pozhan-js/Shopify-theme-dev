"""
微信小程序专用接口
基于24h棋牌室小程序需求
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime, timedelta

from app.core.database import get_db
from app.models.complete_models import MemberStoreInfo, MemberRoomInfo, MemberProductOrder, MemberUser
from app.core.config import settings

router = APIRouter()

# ========== 请求/响应模型 ==========

class StoreListResponse(BaseModel):
    store_id: int
    store_name: str
    city_name: str
    head_img: Optional[str]
    lat: Optional[float]
    lon: Optional[float]
    address: Optional[str]
    room_num: int = 0
    total_money: float = 0.0
    status: int = 0

class RoomListResponse(BaseModel):
    room_id: int
    room_name: str
    room_call_name: Optional[str]
    room_class: int = 0
    store_id: int
    type: int
    price: float
    deposit: float = 0.0
    work_price: Optional[float]
    tongxiao_price: Optional[float]
    label: Optional[str]
    image_urls: Optional[str]
    status: int = 1
    min_hour: int = 4
    lead_hour: int = 6
    lead_day: int = 5
    reserve: bool = True

class RoomDetailResponse(BaseModel):
    room_id: int
    room_name: str
    room_call_name: Optional[str]
    room_class: int
    qr_code: Optional[str]
    renew_code: Optional[str]
    store_id: int
    type: int
    price: float
    deposit: float
    work_price: Optional[float]
    tongxiao_price: Optional[float]
    label: Optional[str]
    image_urls: Optional[str]
    min_hour: int
    lead_hour: int
    lead_day: int
    status: int
    pre_price: float = 0.0
    min_charge: float = 0.0
    tx_price: float = 0.0
    morning_price: Optional[float]
    afternoon_price: Optional[float]
    night_price: Optional[float]

class OrderCreateRequest(BaseModel):
    user_id: int
    store_id: int
    room_id: int
    product_name: str
    product_price: float
    product_num: int = 1
    total_price: float
    start_time: datetime
    end_time: datetime
    use_hour: float
    remark: Optional[str] = None

class OrderResponse(BaseModel):
    id: int
    order_no: str
    user_id: int
    store_id: int
    room_id: int
    product_name: str
    product_price: float
    product_num: int
    total_price: float
    start_time: datetime
    end_time: datetime
    use_hour: float
    pay_price: float = 0.0
    pay_time: Optional[datetime]
    pay_type: int = 1
    status: int = 0
    remark: Optional[str]
    create_time: datetime

class UserLoginRequest(BaseModel):
    code: str
    nickname: Optional[str] = None
    avatar_url: Optional[str] = None

class UserInfoResponse(BaseModel):
    id: int
    openid: str
    nickname: Optional[str]
    avatar_url: Optional[str]
    phone: Optional[str]
    balance: float = 0.0
    total_consume: float = 0.0

# ========== 门店相关接口 ==========

@router.get("/store/list", response_model=List[StoreListResponse])
async def get_store_list(
    city_name: Optional[str] = Query(None, description="城市名称"),
    keyword: Optional[str] = Query(None, description="搜索关键词"),
    db: Session = Depends(get_db)
):
    """获取门店列表"""
    query = db.query(MemberStoreInfo).filter(MemberStoreInfo.deleted == False)
    
    if city_name:
        query = query.filter(MemberStoreInfo.city_name == city_name)
    
    if keyword:
        query = query.filter(MemberStoreInfo.store_name.contains(keyword))
    
    stores = query.order_by(MemberStoreInfo.sort_id, MemberStoreInfo.create_time.desc()).all()
    
    return [StoreListResponse(
        store_id=store.store_id,
        store_name=store.store_name,
        city_name=store.city_name,
        head_img=store.head_img,
        lat=float(store.lat) if store.lat else None,
        lon=float(store.lon) if store.lon else None,
        address=store.address,
        room_num=store.room_num,
        total_money=float(store.total_money),
        status=store.status
    ) for store in stores]

@router.get("/store/{store_id}")
async def get_store_detail(store_id: int, db: Session = Depends(get_db)):
    """获取门店详情"""
    store = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.store_id == store_id,
        MemberStoreInfo.deleted == False
    ).first()
    
    if not store:
        raise HTTPException(status_code=404, detail="门店不存在")
    
    return {
        "store_id": store.store_id,
        "store_name": store.store_name,
        "city_name": store.city_name,
        "content": store.content,
        "head_img": store.head_img,
        "store_env_img": store.store_env_img,
        "banner_img": store.banner_img,
        "notice": store.notice,
        "lat": float(store.lat) if store.lat else None,
        "lon": float(store.lon) if store.lon else None,
        "address": store.address,
        "wifi_info": store.wifi_info,
        "wifi_pwd": store.wifi_pwd,
        "kefu_phone": store.kefu_phone,
        "room_num": store.room_num,
        "status": store.status
    }

# ========== 房间相关接口 ==========

@router.get("/room/list", response_model=List[RoomListResponse])
async def get_room_list(
    store_id: int = Query(..., description="门店ID"),
    room_class: Optional[int] = Query(None, description="房间类别 0棋牌 1台球"),
    status: Optional[int] = Query(None, description="房间状态"),
    db: Session = Depends(get_db)
):
    """获取房间列表"""
    query = db.query(MemberRoomInfo).filter(
        MemberRoomInfo.store_id == store_id,
        MemberRoomInfo.deleted == False
    )
    
    if room_class is not None:
        query = query.filter(MemberRoomInfo.room_class == room_class)
    
    if status is not None:
        query = query.filter(MemberRoomInfo.status == status)
    
    rooms = query.order_by(MemberRoomInfo.sort_id, MemberRoomInfo.room_id).all()
    
    return [RoomListResponse(
        room_id=room.room_id,
        room_name=room.room_name,
        room_call_name=room.room_call_name,
        room_class=room.room_class,
        store_id=room.store_id,
        type=room.type,
        price=float(room.price),
        deposit=float(room.deposit),
        work_price=float(room.work_price) if room.work_price else None,
        tongxiao_price=float(room.tongxiao_price) if room.tongxiao_price else None,
        label=room.label,
        image_urls=room.image_urls,
        status=room.status,
        min_hour=room.min_hour,
        lead_hour=room.lead_hour,
        lead_day=room.lead_day,
        reserve=room.reserve
    ) for room in rooms]

@router.get("/room/{room_id}")
async def get_room_detail(room_id: int, db: Session = Depends(get_db)):
    """获取房间详情"""
    room = db.query(MemberRoomInfo).filter(
        MemberRoomInfo.room_id == room_id,
        MemberRoomInfo.deleted == False
    ).first()
    
    if not room:
        raise HTTPException(status_code=404, detail="房间不存在")
    
    return {
        "room_id": room.room_id,
        "room_name": room.room_name,
        "room_call_name": room.room_call_name,
        "room_class": room.room_class,
        "qr_code": room.qr_code,
        "renew_code": room.renew_code,
        "store_id": room.store_id,
        "type": room.type,
        "price": float(room.price),
        "deposit": float(room.deposit),
        "work_price": float(room.work_price) if room.work_price else None,
        "tongxiao_price": float(room.tongxiao_price) if room.tongxiao_price else None,
        "label": room.label,
        "image_urls": room.image_urls,
        "min_hour": room.min_hour,
        "lead_hour": room.lead_hour,
        "lead_day": room.lead_day,
        "status": room.status,
        "pre_price": float(room.pre_price),
        "min_charge": float(room.min_charge),
        "tx_price": float(room.tx_price),
        "morning_price": float(room.morning_price) if room.morning_price else None,
        "afternoon_price": float(room.afternoon_price) if room.afternoon_price else None,
        "night_price": float(room.night_price) if room.night_price else None
    }

# ========== 订单相关接口 ==========

@router.post("/order/create", response_model=OrderResponse)
async def create_order(order: OrderCreateRequest, db: Session = Depends(get_db)):
    """创建订单"""
    # 生成订单号
    order_no = f"QD{datetime.now().strftime('%Y%m%d%H%M%S')}{order.user_id}"
    
    # 检查房间状态
    room = db.query(MemberRoomInfo).filter(
        MemberRoomInfo.room_id == order.room_id,
        MemberRoomInfo.deleted == False
    ).first()
    
    if not room:
        raise HTTPException(status_code=404, detail="房间不存在")
    
    if room.status not in [1, 4]:  # 1空闲 4已预约
        raise HTTPException(status_code=400, detail="房间不可用")
    
    # 创建订单
    db_order = MemberProductOrder(
        order_no=order_no,
        user_id=order.user_id,
        store_id=order.store_id,
        room_id=order.room_id,
        product_name=order.product_name,
        product_price=order.product_price,
        product_num=order.product_num,
        total_price=order.total_price,
        start_time=order.start_time,
        end_time=order.end_time,
        use_hour=order.use_hour,
        remark=order.remark
    )
    
    db.add(db_order)
    db.commit()
    db.refresh(db_order)
    
    return OrderResponse(
        id=db_order.id,
        order_no=db_order.order_no,
        user_id=db_order.user_id,
        store_id=db_order.store_id,
        room_id=db_order.room_id,
        product_name=db_order.product_name,
        product_price=float(db_order.product_price),
        product_num=db_order.product_num,
        total_price=float(db_order.total_price),
        start_time=db_order.start_time,
        end_time=db_order.end_time,
        use_hour=float(db_order.use_hour),
        status=db_order.status,
        remark=db_order.remark,
        create_time=db_order.create_time
    )

@router.get("/order/list")
async def get_order_list(
    user_id: int = Query(..., description="用户ID"),
    status: Optional[int] = Query(None, description="订单状态"),
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """获取用户订单列表"""
    query = db.query(MemberProductOrder).filter(
        MemberProductOrder.user_id == user_id,
        MemberProductOrder.deleted == False
    )
    
    if status is not None:
        query = query.filter(MemberProductOrder.status == status)
    
    total = query.count()
    orders = query.order_by(MemberProductOrder.create_time.desc()).offset((page-1)*page_size).limit(page_size).all()
    
    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "list": [{
            "id": order.id,
            "order_no": order.order_no,
            "store_id": order.store_id,
            "room_id": order.room_id,
            "product_name": order.product_name,
            "product_price": float(order.product_price),
            "total_price": float(order.total_price),
            "start_time": order.start_time,
            "end_time": order.end_time,
            "use_hour": float(order.use_hour),
            "pay_price": float(order.pay_price),
            "pay_time": order.pay_time,
            "status": order.status,
            "remark": order.remark,
            "create_time": order.create_time
        } for order in orders]
    }

@router.get("/order/{order_id}")
async def get_order_detail(order_id: int, db: Session = Depends(get_db)):
    """获取订单详情"""
    order = db.query(MemberProductOrder).filter(
        MemberProductOrder.id == order_id,
        MemberProductOrder.deleted == False
    ).first()
    
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    
    return {
        "id": order.id,
        "order_no": order.order_no,
        "user_id": order.user_id,
        "store_id": order.store_id,
        "room_id": order.room_id,
        "product_name": order.product_name,
        "product_price": float(order.product_price),
        "product_num": order.product_num,
        "total_price": float(order.total_price),
        "start_time": order.start_time,
        "end_time": order.end_time,
        "use_hour": float(order.use_hour),
        "pay_price": float(order.pay_price),
        "pay_time": order.pay_time,
        "pay_type": order.pay_type,
        "pay_order_no": order.pay_order_no,
        "status": order.status,
        "remark": order.remark,
        "create_time": order.create_time
    }

# ========== 用户相关接口 ==========

@router.post("/user/login")
async def user_login(login_data: UserLoginRequest, db: Session = Depends(get_db)):
    """用户登录（微信小程序）"""
    # 这里应该调用微信接口获取openid，这里简化处理
    openid = f"mock_openid_{login_data.code}"
    
    # 查找或创建用户
    user = db.query(MemberUser).filter(MemberUser.openid == openid).first()
    
    if not user:
        user = MemberUser(
            openid=openid,
            nickname=login_data.nickname,
            avatar_url=login_data.avatar_url
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    else:
        # 更新用户信息
        if login_data.nickname:
            user.nickname = login_data.nickname
        if login_data.avatar_url:
            user.avatar_url = login_data.avatar_url
        db.commit()
    
    return UserInfoResponse(
        id=user.id,
        openid=user.openid,
        nickname=user.nickname,
        avatar_url=user.avatar_url,
        phone=user.phone,
        balance=float(user.balance),
        total_consume=float(user.total_consume)
    )

@router.get("/user/info")
async def get_user_info(user_id: int, db: Session = Depends(get_db)):
    """获取用户信息"""
    user = db.query(MemberUser).filter(
        MemberUser.id == user_id,
        MemberUser.deleted == False
    ).first()
    
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    
    return UserInfoResponse(
        id=user.id,
        openid=user.openid,
        nickname=user.nickname,
        avatar_url=user.avatar_url,
        phone=user.phone,
        balance=float(user.balance),
        total_consume=float(user.total_consume)
    )

# ========== 首页数据接口 ==========

@router.get("/home/data")
async def get_home_data(db: Session = Depends(get_db)):
    """获取首页数据"""
    # 获取推荐门店
    stores = db.query(MemberStoreInfo).filter(
        MemberStoreInfo.deleted == False,
        MemberStoreInfo.status == 0
    ).order_by(MemberStoreInfo.create_time.desc()).limit(10).all()
    
    store_list = []
    for store in stores:
        # 获取房间数量
        room_count = db.query(MemberRoomInfo).filter(
            MemberRoomInfo.store_id == store.store_id,
            MemberRoomInfo.deleted == False
        ).count()
        
        store_list.append({
            "store_id": store.store_id,
            "store_name": store.store_name,
            "city_name": store.city_name,
            "head_img": store.head_img,
            "lat": float(store.lat) if store.lat else None,
            "lon": float(store.lon) if store.lon else None,
            "address": store.address,
            "room_num": room_count,
            "label": store.label
        })
    
    return {
        "stores": store_list,
        "banners": [
            {
                "image_url": "https://example.com/banner1.jpg",
                "link_url": "/pages/store/detail?id=1"
            }
        ],
        "notice": "欢迎使用24h棋牌室预约系统"
    }