from sqlalchemy import Column, String, Integer, DateTime, Text, Boolean, DECIMAL, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import BaseModel

class Member(BaseModel):
    """会员用户表"""
    __tablename__ = "member"
    
    openid = Column(String(100), unique=True, nullable=False, comment='微信openid')
    nickname = Column(String(50), comment='昵称')
    avatar_url = Column(String(255), comment='头像URL')
    phone = Column(String(20), comment='手机号')
    real_name = Column(String(50), comment='真实姓名')
    id_card = Column(String(18), comment='身份证号')
    balance = Column(DECIMAL(10, 2), default=0.00, comment='账户余额')
    total_recharge = Column(DECIMAL(10, 2), default=0.00, comment='累计充值')
    total_consume = Column(DECIMAL(10, 2), default=0.00, comment='累计消费')
    points = Column(Integer, default=0, comment='积分')
    level = Column(Integer, default=1, comment='会员等级')
    status = Column(Integer, default=1, comment='状态 1正常 0禁用')
    
    # 关联关系
    orders = relationship("Order", back_populates="member")
    addresses = relationship("MemberAddress", back_populates="member")
    coupons = relationship("MemberCoupon", back_populates="member")
    store_info = relationship("MemberStoreInfo", back_populates="member")
    store_staff = relationship("MemberStoreStaff", back_populates="member")

class MemberAddress(BaseModel):
    """会员地址表"""
    __tablename__ = "member_address"
    
    member_id = Column(Integer, ForeignKey("member.id"), nullable=False, comment='会员ID')
    name = Column(String(50), nullable=False, comment='收货人姓名')
    phone = Column(String(20), nullable=False, comment='手机号')
    province = Column(String(50), comment='省份')
    city = Column(String(50), comment='城市')
    district = Column(String(50), comment='区县')
    address = Column(String(255), nullable=False, comment='详细地址')
    is_default = Column(Boolean, default=False, comment='是否默认地址')
    
    # 关联关系
    member = relationship("Member", back_populates="addresses")

class MemberCoupon(BaseModel):
    """会员优惠券表"""
    __tablename__ = "member_coupon"
    
    member_id = Column(Integer, ForeignKey("member.id"), nullable=False, comment='会员ID')
    coupon_id = Column(Integer, ForeignKey("coupon.id"), nullable=False, comment='优惠券ID')
    status = Column(Integer, default=1, comment='状态 1未使用 2已使用 3已过期')
    receive_time = Column(DateTime, comment='领取时间')
    use_time = Column(DateTime, comment='使用时间')
    order_id = Column(Integer, comment='使用订单ID')
    
    # 关联关系
    member = relationship("Member", back_populates="coupons")
    coupon = relationship("Coupon", back_populates="member_coupons")