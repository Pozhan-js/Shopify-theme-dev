"""
优惠券活动相关模型
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, Decimal, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class MemberCouponActive(Base):
    """优惠券活动表"""
    __tablename__ = "member_coupon_active"
    
    id = Column(Integer, primary_key=True, autoincrement=True, comment='优惠券活动ID')
    coupon_name = Column(String(100), nullable=False, comment='优惠券名称')
    coupon_type = Column(Integer, nullable=False, default=1, comment='优惠券类型：1-满减券 2-折扣券')
    coupon_value = Column(Decimal(10, 2), nullable=False, comment='优惠券面值/折扣值')
    min_amount = Column(Decimal(10, 2), nullable=False, default=0.00, comment='最低使用金额')
    start_time = Column(DateTime, nullable=False, comment='开始时间')
    end_time = Column(DateTime, nullable=False, comment='结束时间')
    total_count = Column(Integer, nullable=False, default=0, comment='总数量')
    used_count = Column(Integer, nullable=False, default=0, comment='已领取数量')
    status = Column(Integer, nullable=False, default=1, comment='状态：0-停止 1-进行中')
    description = Column(Text, nullable=True, comment='描述')
    
    # 通用字段
    create_time = Column(DateTime, nullable=False, default=datetime.utcnow, comment='创建时间')
    update_time = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow, comment='更新时间')
    deleted = Column(Boolean, nullable=False, default=False, comment='是否删除')

class MemberCoupon(Base):
    """用户优惠券表"""
    __tablename__ = "member_coupon"
    
    id = Column(Integer, primary_key=True, autoincrement=True, comment='用户优惠券ID')
    coupon_id = Column(Integer, ForeignKey('member_coupon_active.id'), nullable=False, comment='优惠券活动ID')
    user_id = Column(Integer, nullable=False, comment='用户ID')
    coupon_code = Column(String(50), nullable=False, unique=True, comment='优惠券码')
    status = Column(Integer, nullable=False, default=0, comment='状态：0-未使用 1-已使用 2-已过期')
    used_time = Column(DateTime, nullable=True, comment='使用时间')
    order_id = Column(Integer, nullable=True, comment='使用订单ID')
    
    # 通用字段
    create_time = Column(DateTime, nullable=False, default=datetime.utcnow, comment='创建时间')
    update_time = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow, comment='更新时间')
    deleted = Column(Boolean, nullable=False, default=False, comment='是否删除')
    
    # 关联关系
    coupon_active = relationship("MemberCouponActive", backref="user_coupons")