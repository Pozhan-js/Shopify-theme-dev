from sqlalchemy import Column, String, Integer, DateTime, Text, Boolean, DECIMAL, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import BaseModel

class MemberStoreInfo(BaseModel):
    """会员门店信息表"""
    __tablename__ = "member_store_info"
    
    member_id = Column(Integer, ForeignKey("member.id"), nullable=False, comment='会员ID')
    store_name = Column(String(100), nullable=False, comment='门店名称')
    store_address = Column(String(255), comment='门店地址')
    store_phone = Column(String(20), comment='门店电话')
    business_license = Column(String(100), comment='营业执照号')
    legal_person = Column(String(50), comment='法人姓名')
    legal_phone = Column(String(20), comment='法人电话')
    legal_id_card = Column(String(18), comment='法人身份证号')
    store_images = Column(Text, comment='门店图片，JSON格式')
    license_images = Column(Text, comment='营业执照图片，JSON格式')
    id_card_images = Column(Text, comment='身份证图片，JSON格式')
    status = Column(Integer, default=1, comment='状态：1待审核 2已通过 3已拒绝')
    audit_remark = Column(Text, comment='审核备注')
    audit_time = Column(DateTime, comment='审核时间')
    audit_admin_id = Column(Integer, comment='审核管理员ID')
    
    # 关联关系
    member = relationship("Member", back_populates="store_info")

class MemberStoreStaff(BaseModel):
    """会员门店员工表"""
    __tablename__ = "member_store_staff"
    
    member_id = Column(Integer, ForeignKey("member.id"), nullable=False, comment='会员ID')
    store_id = Column(Integer, ForeignKey("member_store_info.id"), nullable=False, comment='门店ID')
    name = Column(String(50), nullable=False, comment='员工姓名')
    phone = Column(String(20), nullable=False, comment='员工电话')
    position = Column(String(50), comment='职位')
    id_card = Column(String(18), comment='身份证号')
    status = Column(Integer, default=1, comment='状态：1在职 0离职')
    hire_date = Column(DateTime, comment='入职日期')
    leave_date = Column(DateTime, comment='离职日期')
    
    # 关联关系
    member = relationship("Member", back_populates="store_staff")
    store = relationship("MemberStoreInfo", back_populates="staff")