from sqlalchemy import Column, String, Integer, DateTime, Text, Boolean, DECIMAL, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import BaseModel

class Order(BaseModel):
    """订单表"""
    __tablename__ = "order"
    
    order_no = Column(String(32), unique=True, nullable=False, comment='订单号')
    member_id = Column(Integer, ForeignKey("member.id"), nullable=False, comment='会员ID')
    store_id = Column(Integer, ForeignKey("store.id"), nullable=False, comment='门店ID')
    room_id = Column(Integer, ForeignKey("room.id"), nullable=False, comment='房间ID')
    
    # 预约信息
    appointment_date = Column(DateTime, nullable=False, comment='预约日期')
    start_time = Column(String(5), nullable=False, comment='开始时间 HH:MM')
    end_time = Column(String(5), nullable=False, comment='结束时间 HH:MM')
    duration = Column(Integer, nullable=False, comment='时长(小时)')
    
    # 价格信息
    original_price = Column(DECIMAL(10, 2), nullable=False, comment='原价')
    discount_price = Column(DECIMAL(10, 2), default=0.00, comment='优惠金额')
    pay_price = Column(DECIMAL(10, 2), nullable=False, comment='实付金额')
    
    # 订单状态
    status = Column(Integer, default=1, comment='订单状态 1待支付 2已支付 3已完成 4已取消 5已退款')
    pay_status = Column(Integer, default=1, comment='支付状态 1未支付 2已支付')
    pay_time = Column(DateTime, comment='支付时间')
    pay_type = Column(Integer, comment='支付方式 1微信支付 2余额支付')
    
    # 联系信息
    contact_name = Column(String(50), nullable=False, comment='联系人姓名')
    contact_phone = Column(String(20), nullable=False, comment='联系电话')
    remark = Column(String(500), comment='备注')
    
    # 退款信息
    refund_amount = Column(DECIMAL(10, 2), default=0.00, comment='退款金额')
    refund_reason = Column(String(500), comment='退款原因')
    refund_time = Column(DateTime, comment='退款时间')
    
    # 关联关系
    member = relationship("Member", back_populates="orders")
    store = relationship("Store", back_populates="orders")
    room = relationship("Room", back_populates="orders")
    order_items = relationship("OrderItem", back_populates="order")

class OrderItem(BaseModel):
    """订单明细表"""
    __tablename__ = "order_item"
    
    order_id = Column(Integer, ForeignKey("order.id"), nullable=False, comment='订单ID')
    item_type = Column(Integer, nullable=False, comment='项目类型 1房间费 2商品')
    item_id = Column(Integer, nullable=False, comment='项目ID')
    item_name = Column(String(100), nullable=False, comment='项目名称')
    quantity = Column(Integer, default=1, comment='数量')
    price = Column(DECIMAL(10, 2), nullable=False, comment='单价')
    total_price = Column(DECIMAL(10, 2), nullable=False, comment='总价')
    
    # 关联关系
    order = relationship("Order", back_populates="order_items")

class OrderLog(BaseModel):
    """订单日志表"""
    __tablename__ = "order_log"
    
    order_id = Column(Integer, ForeignKey("order.id"), nullable=False, comment='订单ID')
    action = Column(String(50), nullable=False, comment='操作类型')
    description = Column(String(500), comment='操作描述')
    operator = Column(String(50), comment='操作人')
    
    # 关联关系
    order = relationship("Order")