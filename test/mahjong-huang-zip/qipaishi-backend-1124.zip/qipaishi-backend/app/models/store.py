from sqlalchemy import Column, String, Integer, DateTime, Text, Boolean, DECIMAL, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import BaseModel

class Store(BaseModel):
    """门店表"""
    __tablename__ = "store"
    
    name = Column(String(100), nullable=False, comment='门店名称')
    phone = Column(String(20), comment='联系电话')
    address = Column(String(255), comment='门店地址')
    longitude = Column(DECIMAL(10, 6), comment='经度')
    latitude = Column(DECIMAL(10, 6), comment='纬度')
    business_hours = Column(String(100), comment='营业时间')
    description = Column(Text, comment='门店描述')
    images = Column(Text, comment='门店图片，JSON格式')
    status = Column(Integer, default=1, comment='状态 1营业 0休息')
    sort_order = Column(Integer, default=0, comment='排序')
    
    # 关联关系
    rooms = relationship("Room", back_populates="store")
    orders = relationship("Order", back_populates="store")

class Room(BaseModel):
    """房间表"""
    __tablename__ = "room"
    
    store_id = Column(Integer, ForeignKey("store.id"), nullable=False, comment='门店ID')
    name = Column(String(100), nullable=False, comment='房间名称')
    type = Column(Integer, nullable=False, comment='房间类型 1小包 2中包 3大包 4豪包')
    capacity = Column(Integer, default=4, comment='容纳人数')
    price = Column(DECIMAL(10, 2), nullable=False, comment='价格/小时')
    description = Column(Text, comment='房间描述')
    images = Column(Text, comment='房间图片，JSON格式')
    equipment = Column(Text, comment='设备配置，JSON格式')
    status = Column(Integer, default=1, comment='状态 1可用 0不可用')
    sort_order = Column(Integer, default=0, comment='排序')
    
    # 关联关系
    store = relationship("Store", back_populates="rooms")
    schedules = relationship("RoomSchedule", back_populates="room")
    orders = relationship("Order", back_populates="room")

class RoomSchedule(BaseModel):
    """房间排班表"""
    __tablename__ = "room_schedule"
    
    room_id = Column(Integer, ForeignKey("room.id"), nullable=False, comment='房间ID')
    date = Column(DateTime, nullable=False, comment='日期')
    start_time = Column(String(5), nullable=False, comment='开始时间 HH:MM')
    end_time = Column(String(5), nullable=False, comment='结束时间 HH:MM')
    status = Column(Integer, default=1, comment='状态 1可预约 0不可预约')
    price = Column(DECIMAL(10, 2), comment='特殊时段价格')
    
    # 关联关系
    room = relationship("Room", back_populates="schedules")