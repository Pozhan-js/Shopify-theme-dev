"""
完整的24h棋牌室数据库模型
基于db_250815.sql和微信小程序需求
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, DECIMAL, ForeignKey, BigInteger, SmallInteger
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class MemberStoreInfo(Base):
    """门店信息表"""
    __tablename__ = "member_store_info"
    
    store_id = Column(BigInteger, primary_key=True, autoincrement=True, comment="门店ID")
    store_name = Column(String(255), nullable=False, comment="门店名称")
    city_name = Column(String(20), nullable=False, comment="城市名称")
    content = Column(Text, comment="门店富文本详情")
    head_img = Column(String(255), comment="缩略图url")
    store_env_img = Column(Text, comment="门店环境照片url")
    banner_img = Column(Text, comment="门店banner照片url")
    notice = Column(Text, comment="门店公告")
    lat = Column(DECIMAL(12, 8), comment="纬度")
    lon = Column(DECIMAL(12, 8), comment="经度")
    address = Column(String(255), comment="详细地址")
    qr_code = Column(String(500), comment="二维码照片")
    simple_model = Column(Boolean, default=False, comment="简洁模式")
    template_key = Column(String(255), comment="首页模板key")
    
    # 图片配置
    btn_img = Column(String(500), default="", comment="预约按钮照片")
    tg_img = Column(String(500), default="", comment="团购照片")
    open_img = Column(String(500), default="", comment="开门照片")
    wifi_img = Column(String(500), default="", comment="wifi照片")
    kf_img = Column(String(500), default="", comment="客服照片")
    cz_img = Column(String(500), default="", comment="充值照片")
    qh_img = Column(String(500), default="", comment="切换门店照片")
    
    # 配置项
    clear_open = Column(Boolean, default=True, comment="清洁状态开放")
    clear_time = Column(Integer, default=5, comment="订单清洁时间")
    show_tx_price = Column(Boolean, default=True, comment="显示通宵场价格")
    tx_start_hour = Column(Integer, default=23, comment="通宵起始小时")
    tx_hour = Column(Integer, default=9, comment="通宵时长")
    delay_light = Column(Boolean, default=True, comment="延时灯光")
    work_price = Column(Boolean, default=True, comment="启用工作日价格")
    order_door_open = Column(Boolean, default=True, comment="订单门禁常开")
    clear_open_door = Column(Boolean, default=False, comment="保洁任意开门")
    
    status = Column(SmallInteger, default=0, comment="门店状态 0正常 1审核中")
    wifi_info = Column(String(50), comment="wifi信息")
    wifi_pwd = Column(String(50), comment="wifi密码")
    label = Column(String(255), comment="房间标签，逗号分割")
    kefu_phone = Column(String(30), comment="客服电话")
    order_webhook = Column(String(500), comment="微信机器人webhook")
    game_webhook = Column(String(500), comment="在线组局机器人webhook")
    douyin_poi_id = Column(String(50), comment="抖音门店poi_id")
    
    # 统计数据
    room_num = Column(Integer, default=0, comment="房间数量")
    total_money = Column(DECIMAL(10, 2), default=0.00, comment="总收入")
    total_withdrawal = Column(DECIMAL(10, 2), default=0.00, comment="已提现")
    expire_time = Column(DateTime, comment="过期时间")
    svg = Column(Text, comment="svg代码")
    
    # 通用字段
    creator = Column(String(64), default="", comment="创建者")
    create_time = Column(DateTime, default=datetime.utcnow, comment="创建时间")
    updater = Column(String(64), default="", comment="更新者")
    update_time = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment="更新时间")
    deleted = Column(Boolean, default=False, comment="是否删除")
    tenant_id = Column(BigInteger, default=0, comment="租户编号")

class MemberStorePayConfig(Base):
    """门店支付配置表"""
    __tablename__ = "member_store_pay_config"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True, comment="配置ID")
    store_id = Column(BigInteger, ForeignKey("member_store_info.store_id"), nullable=False, comment="门店ID")
    pay_type = Column(SmallInteger, default=1, comment="支付类型 1微信支付 2余额支付")
    mch_id = Column(String(50), comment="商户号")
    mch_key = Column(String(255), comment="商户密钥")
    app_id = Column(String(50), comment="应用ID")
    app_secret = Column(String(255), comment="应用密钥")
    notify_url = Column(String(500), comment="支付通知地址")
    status = Column(SmallInteger, default=1, comment="状态 1启用 0禁用")
    
    # 通用字段
    creator = Column(String(64), default="", comment="创建者")
    create_time = Column(DateTime, default=datetime.utcnow, comment="创建时间")
    updater = Column(String(64), default="", comment="更新者")
    update_time = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment="更新时间")
    deleted = Column(Boolean, default=False, comment="是否删除")
    tenant_id = Column(BigInteger, default=0, comment="租户编号")

class MemberStorePaySplit(Base):
    """门店支付分账配置表"""
    __tablename__ = "member_store_pay_split"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True, comment="分账ID")
    store_id = Column(BigInteger, ForeignKey("member_store_info.store_id"), nullable=False, comment="门店ID")
    receiver_type = Column(SmallInteger, default=1, comment="接收方类型 1个人 2商户")
    receiver_account = Column(String(100), nullable=False, comment="接收方账号")
    receiver_name = Column(String(100), comment="接收方姓名")
    split_percentage = Column(Integer, default=100, comment="分账比例 0-100")
    split_amount = Column(DECIMAL(10, 2), default=0.00, comment="固定分账金额")
    description = Column(String(255), comment="分账描述")
    status = Column(SmallInteger, default=1, comment="状态 1启用 0禁用")
    
    # 通用字段
    creator = Column(String(64), default="", comment="创建者")
    create_time = Column(DateTime, default=datetime.utcnow, comment="创建时间")
    updater = Column(String(64), default="", comment="更新者")
    update_time = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment="更新时间")
    deleted = Column(Boolean, default=False, comment="是否删除")
    tenant_id = Column(BigInteger, default=0, comment="租户编号")
    
    # 关系
    rooms = relationship("MemberRoomInfo", back_populates="store")
    orders = relationship("MemberProductOrder", back_populates="store")

class MemberRoomInfo(Base):
    """房间信息表"""
    __tablename__ = "member_room_info"
    
    room_id = Column(BigInteger, primary_key=True, autoincrement=True, comment="房间id")
    room_name = Column(String(50), nullable=False, comment="房间名称")
    room_call_name = Column(String(50), comment="房间简称")
    room_class = Column(Integer, default=0, comment="房间类别0棋牌 1台球")
    qr_code = Column(Text, comment="房间小程序码")
    renew_code = Column(Text, comment="续费码")
    store_id = Column(BigInteger, ForeignKey("member_store_info.store_id"), nullable=False, comment="门店id")
    type = Column(SmallInteger, nullable=False, comment="房间类型")
    price = Column(DECIMAL(10, 2), nullable=False, comment="单价")
    deposit = Column(DECIMAL(10, 2), default=0.00, comment="押金")
    work_price = Column(DECIMAL(10, 2), comment="工作日价格")
    tongxiao_price = Column(DECIMAL(10, 2), comment="通宵场价格")
    label = Column(String(255), comment="房间标签，逗号分割")
    image_urls = Column(Text, comment="房间照片")
    sort_id = Column(Integer, default=0, comment="排序位置")
    yunlaba_sound = Column(Integer, comment="云喇叭音量，1-5")
    ban_time_start = Column(String(20), comment="禁用开始时间")
    ban_time_end = Column(String(20), comment="禁用结束时间")
    
    # 统计数据
    total_order_num = Column(Integer, default=0, comment="总完成订单数")
    total_money = Column(DECIMAL(10, 2), default=0.00, comment="总收益")
    
    # 时间配置
    min_hour = Column(Integer, default=4, comment="最小下单时间")
    lead_hour = Column(Integer, default=6, comment="最大提前开始时间")
    lead_day = Column(Integer, default=5, comment="最大提前下单天数")
    jump_clear = Column(Boolean, default=False, comment="跳过清洁")
    reserve = Column(Boolean, default=True, comment="是否可预定")
    
    # 状态
    status = Column(SmallInteger, default=0, comment="状态 0禁用 1空闲 2待清洁 3使用中 4已预约")
    
    # 坐标
    svg_x = Column(Integer, comment="svg x轴坐标")
    svg_y = Column(Integer, comment="svg y轴坐标")
    
    # 价格配置
    pre_price = Column(DECIMAL(10, 2), default=0.00, comment="预付费价格")
    pre_unit = Column(Integer, default=1, comment="预付费单位")
    min_charge = Column(DECIMAL(10, 2), default=0.00, comment="最低消费价格")
    
    # 包场价格
    tx_price = Column(DECIMAL(10, 2), default=0.00, comment="包场-通宵价格")
    morning_price = Column(DECIMAL(10, 2), comment="包场-上午价格")
    afternoon_price = Column(DECIMAL(10, 2), comment="包场-下午价格")
    night_price = Column(DECIMAL(10, 2), comment="包场-夜间价格")
    
    # 通用字段
    creator = Column(String(64), default="", comment="创建者")
    create_time = Column(DateTime, default=datetime.utcnow, comment="创建时间")
    updater = Column(String(64), default="", comment="更新者")
    update_time = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment="更新时间")
    deleted = Column(Boolean, default=False, comment="是否删除")
    tenant_id = Column(BigInteger, default=0, comment="租户编号")
    
    # 关系
    store = relationship("MemberStoreInfo", back_populates="rooms")
    orders = relationship("MemberProductOrder", back_populates="room")

class MemberProductOrder(Base):
    """商品购买订单表"""
    __tablename__ = "member_product_order"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True, comment="订单id")
    order_no = Column(String(64), nullable=False, unique=True, comment="订单号")
    user_id = Column(BigInteger, nullable=False, comment="用户id")
    store_id = Column(BigInteger, ForeignKey("member_store_info.store_id"), nullable=False, comment="门店id")
    room_id = Column(BigInteger, ForeignKey("member_room_info.room_id"), nullable=False, comment="房间id")
    
    # 订单信息
    product_name = Column(String(255), nullable=False, comment="商品名称")
    product_id = Column(BigInteger, comment="商品id")
    product_price = Column(DECIMAL(10, 2), nullable=False, comment="商品单价")
    product_num = Column(Integer, nullable=False, comment="商品数量")
    total_price = Column(DECIMAL(10, 2), nullable=False, comment="订单总价")
    
    # 时间信息
    start_time = Column(DateTime, comment="开始时间")
    end_time = Column(DateTime, comment="结束时间")
    use_hour = Column(DECIMAL(10, 2), comment="使用时长")
    
    # 支付信息
    pay_price = Column(DECIMAL(10, 2), default=0.00, comment="实付金额")
    pay_time = Column(DateTime, comment="支付时间")
    pay_type = Column(SmallInteger, default=1, comment="支付方式 1微信支付 2余额支付")
    pay_order_no = Column(String(64), comment="支付订单号")
    
    # 状态
    status = Column(SmallInteger, default=0, comment="订单状态 0待支付 1已支付 2使用中 3已完成 4已取消 5退款中 6已退款")
    
    # 扩展信息
    extend = Column(Text, comment="扩展信息")
    remark = Column(String(500), comment="备注")
    
    # 通用字段
    creator = Column(String(64), default="", comment="创建者")
    create_time = Column(DateTime, default=datetime.utcnow, comment="创建时间")
    updater = Column(String(64), default="", comment="更新者")
    update_time = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment="更新时间")
    deleted = Column(Boolean, default=False, comment="是否删除")
    tenant_id = Column(BigInteger, default=0, comment="租户编号")
    
    # 关系
    store = relationship("MemberStoreInfo", back_populates="orders")
    room = relationship("MemberRoomInfo", back_populates="orders")

class MemberUser(Base):
    """用户表（补充）"""
    __tablename__ = "member_user"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True, comment="用户id")
    openid = Column(String(100), unique=True, nullable=False, comment="微信openid")
    unionid = Column(String(100), comment="微信unionid")
    nickname = Column(String(50), comment="昵称")
    avatar_url = Column(String(500), comment="头像")
    phone = Column(String(20), comment="手机号")
    
    # 余额信息
    balance = Column(DECIMAL(10, 2), default=0.00, comment="余额")
    total_consume = Column(DECIMAL(10, 2), default=0.00, comment="总消费")
    
    # 状态
    status = Column(SmallInteger, default=1, comment="状态 1正常 0禁用")
    
    # 通用字段
    creator = Column(String(64), default="", comment="创建者")
    create_time = Column(DateTime, default=datetime.utcnow, comment="创建时间")
    updater = Column(String(64), default="", comment="更新者")
    update_time = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment="更新时间")
    deleted = Column(Boolean, default=False, comment="是否删除")
    tenant_id = Column(BigInteger, default=0, comment="租户编号")