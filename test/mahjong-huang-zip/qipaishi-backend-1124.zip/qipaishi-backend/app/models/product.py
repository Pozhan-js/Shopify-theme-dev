from sqlalchemy import Column, String, Integer, DateTime, Text, Boolean, DECIMAL, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import BaseModel

class ProductCategory(BaseModel):
    """商品分类表"""
    __tablename__ = "product_category"
    
    name = Column(String(50), nullable=False, comment='分类名称')
    description = Column(String(255), comment='分类描述')
    sort_order = Column(Integer, default=0, comment='排序')
    status = Column(Integer, default=1, comment='状态 1启用 0禁用')
    
    # 关联关系
    products = relationship("Product", back_populates="category")

class Product(BaseModel):
    """商品表"""
    __tablename__ = "product"
    
    category_id = Column(Integer, ForeignKey("product_category.id"), comment='分类ID')
    name = Column(String(100), nullable=False, comment='商品名称')
    description = Column(Text, comment='商品描述')
    images = Column(Text, comment='商品图片，JSON格式')
    price = Column(DECIMAL(10, 2), nullable=False, comment='价格')
    stock = Column(Integer, default=0, comment='库存数量')
    unit = Column(String(20), default='个', comment='单位')
    status = Column(Integer, default=1, comment='状态 1上架 0下架')
    sort_order = Column(Integer, default=0, comment='排序')
    
    # 关联关系
    category = relationship("ProductCategory", back_populates="products")

class Coupon(BaseModel):
    """优惠券表"""
    __tablename__ = "coupon"
    
    name = Column(String(100), nullable=False, comment='优惠券名称')
    description = Column(String(500), comment='优惠券描述')
    type = Column(Integer, nullable=False, comment='优惠券类型 1满减券 2折扣券')
    discount_amount = Column(DECIMAL(10, 2), comment='优惠金额')
    discount_percent = Column(Integer, comment='折扣百分比')
    min_amount = Column(DECIMAL(10, 2), comment='最低消费金额')
    max_discount = Column(DECIMAL(10, 2), comment='最大优惠金额')
    
    # 有效期
    start_time = Column(DateTime, nullable=False, comment='开始时间')
    end_time = Column(DateTime, nullable=False, comment='结束时间')
    
    # 发放规则
    total_count = Column(Integer, comment='总发放数量')
    received_count = Column(Integer, default=0, comment='已领取数量')
    limit_per_user = Column(Integer, default=1, comment='每人限领数量')
    
    status = Column(Integer, default=1, comment='状态 1启用 0禁用')
    
    # 关联关系
    member_coupons = relationship("MemberCoupon", back_populates="coupon")

# MemberCoupon 已在 member.py 中定义，这里只保留关联关系