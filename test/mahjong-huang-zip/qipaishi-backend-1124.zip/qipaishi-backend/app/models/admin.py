from sqlalchemy import Column, String, Integer, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime

from app.models.base import BaseModel

class AdminUser(BaseModel):
    """管理员用户表"""
    __tablename__ = "admin_user"
    
    username = Column(String(50), unique=True, nullable=False, comment='用户名')
    password_hash = Column(String(255), nullable=False, comment='密码哈希')
    real_name = Column(String(50), comment='真实姓名')
    email = Column(String(100), comment='邮箱')
    phone = Column(String(20), comment='手机号')
    avatar = Column(String(255), comment='头像URL')
    role = Column(String(20), default='admin', comment='角色：super_admin, admin, operator')
    status = Column(Integer, default=1, comment='状态：1正常 0禁用')
    last_login_time = Column(DateTime, comment='最后登录时间')
    last_login_ip = Column(String(50), comment='最后登录IP')
    login_count = Column(Integer, default=0, comment='登录次数')
    remark = Column(Text, comment='备注')
    
    # 关联关系
    logs = relationship("AdminLoginLog", back_populates="user")
    operations = relationship("AdminOperationLog", back_populates="user")

class AdminLoginLog(BaseModel):
    """管理员登录日志表"""
    __tablename__ = "admin_login_log"
    
    user_id = Column(Integer, ForeignKey("admin_user.id"), nullable=False, comment='用户ID')
    login_time = Column(DateTime, default=datetime.now, comment='登录时间')
    login_ip = Column(String(50), comment='登录IP')
    user_agent = Column(String(500), comment='用户代理')
    login_result = Column(Integer, default=1, comment='登录结果：1成功 0失败')
    failure_reason = Column(String(255), comment='失败原因')
    
    # 关联关系
    user = relationship("AdminUser", back_populates="logs")

class AdminOperationLog(BaseModel):
    """管理员操作日志表"""
    __tablename__ = "admin_operation_log"
    
    user_id = Column(Integer, ForeignKey("admin_user.id"), nullable=False, comment='用户ID')
    operation_module = Column(String(50), comment='操作模块')
    operation_type = Column(String(20), comment='操作类型：create, update, delete, query')
    operation_desc = Column(String(255), comment='操作描述')
    request_url = Column(String(255), comment='请求URL')
    request_method = Column(String(10), comment='请求方法')
    request_params = Column(Text, comment='请求参数')
    response_data = Column(Text, comment='响应数据')
    ip_address = Column(String(50), comment='IP地址')
    user_agent = Column(String(500), comment='用户代理')
    operation_time = Column(DateTime, default=datetime.now, comment='操作时间')
    execution_time = Column(Integer, comment='执行时间(ms)')
    
    # 关联关系
    user = relationship("AdminUser", back_populates="operations")

class AdminMenu(BaseModel):
    """管理员菜单表"""
    __tablename__ = "admin_menu"
    
    parent_id = Column(Integer, default=0, comment='父菜单ID')
    name = Column(String(50), nullable=False, comment='菜单名称')
    path = Column(String(255), comment='路由路径')
    component = Column(String(255), comment='组件路径')
    icon = Column(String(50), comment='图标')
    sort_order = Column(Integer, default=0, comment='排序')
    status = Column(Integer, default=1, comment='状态：1启用 0禁用')
    menu_type = Column(Integer, default=1, comment='菜单类型：1目录 2菜单 3按钮')
    permission = Column(String(100), comment='权限标识')
    remark = Column(Text, comment='备注')

class AdminRole(BaseModel):
    """管理员角色表"""
    __tablename__ = "admin_role"
    
    name = Column(String(50), unique=True, nullable=False, comment='角色名称')
    code = Column(String(50), unique=True, nullable=False, comment='角色编码')
    description = Column(String(255), comment='角色描述')
    status = Column(Integer, default=1, comment='状态：1启用 0禁用')
    sort_order = Column(Integer, default=0, comment='排序')
    remark = Column(Text, comment='备注')