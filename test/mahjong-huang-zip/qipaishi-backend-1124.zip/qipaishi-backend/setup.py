#!/usr/bin/env python3
"""
24h棋牌室后端API设置脚本
"""
import os
import sys
import subprocess

def check_python():
    """检查Python版本"""
    print("检查Python环境...")
    if sys.version_info < (3, 8):
        print("错误: 需要Python 3.8或更高版本")
        return False
    print(f"Python版本: {sys.version}")
    return True

def install_dependencies():
    """安装依赖"""
    print("安装依赖包...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], 
                      check=True, capture_output=True)
        print("依赖安装成功")
        return True
    except subprocess.CalledProcessError as e:
        print(f"依赖安装失败: {e}")
        return False

def create_directories():
    """创建必要的目录"""
    print("创建目录结构...")
    directories = ["logs", "uploads", "alembic/versions"]
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"创建目录: {directory}")

def check_env_file():
    """检查环境配置文件"""
    if not os.path.exists(".env"):
        print("创建.env文件...")
        with open(".env.example", "r") as src, open(".env", "w") as dst:
            dst.write(src.read())
        print("请编辑.env文件配置数据库和微信参数")
    else:
        print("检测到.env文件")

def main():
    """主函数"""
    print("=== 24h棋牌室后端API设置 ===")
    
    if not check_python():
        return
    
    create_directories()
    check_env_file()
    
    if install_dependencies():
        print("\n=== 设置完成 ===")
        print("1. 编辑.env文件配置数据库连接")
        print("2. 运行: python3 main.py")
        print("3. 访问: http://localhost:8000/docs")
    else:
        print("\n=== 设置失败 ===")
        print("请手动安装依赖: pip3 install -r requirements.txt")

if __name__ == "__main__":
    main()