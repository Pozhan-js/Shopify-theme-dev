# 🚀 24h棋牌室后端 - 完整启动指南

## 📋 新设备从零开始部署指南

### 🔧 系统要求
- **操作系统**: macOS 10.15+ / Ubuntu 18.04+ / Windows 10+
- **Python**: 3.8 或更高版本
- **MySQL**: 8.0 或更高版本
- **Redis**: 5.0+ (可选，用于缓存)

---

## 📦 第一步：环境准备

### 1.1 安装Python
```bash
# macOS (使用Homebrew)
brew install python3

# Ubuntu/Debian
sudo apt update
sudo apt install python3 python3-pip python3-venv

# Windows
# 从 https://python.org 下载安装Python 3.8+
```

### 1.2 验证Python安装
```bash
python3 --version  # 应该显示 3.8+
pip3 --version
```

### 1.3 安装MySQL
```bash
# macOS (使用Homebrew)
brew install mysql
brew services start mysql

# Ubuntu/Debian
sudo apt install mysql-server mysql-client
sudo systemctl start mysql
sudo systemctl enable mysql

# Windows
# 从 https://dev.mysql.com/downloads/installer/ 下载安装
```

### 1.4 安装Redis (可选)
```bash
# macOS
brew install redis
brew services start redis

# Ubuntu/Debian
sudo apt install redis-server
sudo systemctl start redis
```

---

## 📁 第二步：项目获取

### 2.1 克隆项目
```bash
# 如果是git仓库
git clone <your-repository-url>
cd qipaishi-backend

# 如果是压缩包，解压后进入目录
cd qipaishi-backend
```

### 2.2 验证项目结构
```bash
ls -la
# 应该看到以下文件：
# - app/ (主应用目录)
# - requirements.txt
# - main.py
# - .env (配置文件)
# - README.md
```

---

## 🌍 第三步：Python环境配置

### 3.1 创建虚拟环境
```bash
# 创建虚拟环境
python3 -m venv venv

# 激活虚拟环境
# macOS/Linux:
source venv/bin/activate

# Windows:
venv\Scripts\activate

# 验证虚拟环境已激活
which python  # 应该显示虚拟环境路径
```

### 3.2 安装依赖
```bash
# 确保在虚拟环境中
pip install --upgrade pip
pip install -r requirements.txt

# 如果遇到安装问题，尝试：
pip install --user -r requirements.txt
```

### 3.3 验证依赖安装
```bash
python3 -c "import fastapi, sqlalchemy, pymysql; print('✅ 依赖安装成功')"
```

---

## 🗄️ 第四步：数据库配置

### 4.1 配置MySQL
```bash
# 登录MySQL
mysql -u root -p

# 在MySQL中执行：
CREATE DATABASE qipaishi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'qipaishi_user'@'localhost' IDENTIFIED BY 'qipaishi_pass';
GRANT ALL PRIVILEGES ON qipaishi.* TO 'qipaishi_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 4.2 配置环境变量
```bash
# 复制环境变量模板
cp .env.example .env 2>/dev/null || echo "创建.env文件"

# 编辑.env文件
cat > .env << 'EOF'
# 应用配置
APP_NAME=24h棋牌室
APP_VERSION=1.0.0
DEBUG=True

# 数据库配置
DATABASE_URL=mysql+pymysql://root:root@localhost:3306/qipaishi?charset=utf8mb4

# 安全配置
SECRET_KEY=your-secret-key-change-this-in-production
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=10080

# 微信小程序配置（开发环境）
WECHAT_APP_ID=your-dev-app-id
WECHAT_APP_SECRET=your-dev-app-secret

# 微信支付配置（开发环境）
WECHAT_MCH_ID=your-dev-mch-id
WECHAT_MCH_KEY=your-dev-mch-key
WECHAT_NOTIFY_URL=http://localhost:8000/api/v1/order/notify

# Redis配置（可选）
REDIS_URL=redis://localhost:6379/0

# 文件上传配置
UPLOAD_DIR=uploads
MAX_FILE_SIZE=5242880

# 日志配置
LOG_LEVEL=DEBUG
LOG_FILE=logs/app.log

# 跨域配置
CORS_ORIGINS=["*"]
EOF
```

---

## 🚀 第五步：启动项目

### 5.1 测试数据库连接
```bash
python3 -c "
from sqlalchemy import create_engine
engine = create_engine('mysql+pymysql://root:root@localhost:3306/qipaishi?charset=utf8mb4')
conn = engine.connect()
print('✅ 数据库连接成功')
conn.close()
"
```

### 5.2 启动方式选择

#### 方式A：开发模式（推荐）
```bash
# 启动开发服务器
python3 -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# 或使用简化版本（无数据库依赖）
python3 -m uvicorn simple_test:app --reload --host 0.0.0.0 --port 8000
```

#### 方式B：生产模式
```bash
# 直接运行
python3 main.py

# 或使用gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

#### 方式C：Docker部署
```bash
# 构建镜像
docker build -t qipaishi-backend .

# 运行容器
docker run -d \
  --name qipaishi-backend \
  -p 8000:8000 \
  -v $(pwd)/.env:/app/.env \
  -v $(pwd)/uploads:/app/uploads \
  qipaishi-backend
```

---

## 🔍 第六步：验证启动

### 6.1 基础测试
```bash
# 测试健康检查
curl http://localhost:8000/health
# 应该返回: {"status":"healthy"}

# 测试根路径
curl http://localhost:8000/
# 应该返回: {"message":"24h棋牌室预约系统API","version":"1.0.0"}
```

### 6.2 API文档访问
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### 6.3 数据库验证
```bash
# 检查数据库表
mysql -u root -proot -e "USE qipaishi; SHOW TABLES;"
```

---

## 🐛 第七步：常见问题解决

### 7.1 端口被占用
```bash
# 查找占用端口的进程
lsof -ti :8000

# 杀死进程
kill -9 <PID>

# 使用其他端口
python3 -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8080
```

### 7.2 数据库连接失败
```bash
# 检查MySQL服务
sudo systemctl status mysql  # Linux
brew services list | grep mysql  # macOS

# 重置MySQL密码
mysqladmin -u root password 'newpassword'

# 检查防火墙
sudo ufw allow 3306  # Ubuntu
```

### 7.3 依赖安装失败
```bash
# 升级pip
python3 -m pip install --upgrade pip

# 使用国内镜像
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

# 单独安装问题包
pip install --user pymysql
```

### 7.4 权限问题
```bash
# 文件权限
chmod +x main.py
chmod -R 755 uploads/

# MySQL权限
mysql -u root -p -e "GRANT ALL PRIVILEGES ON qipaishi.* TO 'root'@'localhost';"
```

---

## 📱 第八步：微信小程序对接

### 8.1 配置小程序
```javascript
// 小程序 app.js
App({
  globalData: {
    baseUrl: 'http://localhost:8000',
    apiVersion: '/api/v1'
  }
})
```

### 8.2 测试API
```bash
# 测试门店列表
curl http://localhost:8000/api/v1/store/list

# 测试房间列表
curl http://localhost:8000/api/v1/store/room/list

# 测试商品列表
curl http://localhost:8000/api/v1/product/list
```

---

## 📊 第九步：监控和日志

### 9.1 查看日志
```bash
# 实时查看日志
tail -f logs/app.log

# 查看错误日志
grep ERROR logs/app.log
```

### 9.2 性能监控
```bash
# 安装htop（可选）
# macOS: brew install htop
# Ubuntu: sudo apt install htop

# 监控资源使用
htop
```

---

## 🎯 一键启动脚本

创建 `start.sh`：
```bash
#!/bin/bash
echo "🚀 启动24h棋牌室后端服务..."

# 激活虚拟环境
source venv/bin/activate

# 检查MySQL
if ! pgrep -x "mysqld" > /dev/null; then
    echo "⚠️  MySQL未运行，正在启动..."
    brew services start mysql  # macOS
    # sudo systemctl start mysql  # Ubuntu
fi

# 检查端口
if lsof -ti:8000 > /dev/null; then
    echo "⚠️  端口8000被占用，使用8080"
    PORT=8080
else
    PORT=8000
fi

# 启动服务
echo "✅ 启动服务，端口: $PORT"
python3 -m uvicorn app.main:app --reload --host 0.0.0.0 --port $PORT
```

使用：
```bash
chmod +x start.sh
./start.sh
```

---

## 📞 技术支持

### 紧急联系方式
- **项目地址**: [你的项目地址]
- **文档**: http://localhost:8000/docs
- **日志**: logs/app.log

### 常见问题速查表
| 问题 | 解决方案 |
|------|----------|
| 端口占用 | 使用 `lsof -ti :8000` 查找并杀死进程 |
| 数据库连接失败 | 检查MySQL服务状态和.env配置 |
| 依赖安装失败 | 使用国内镜像源或升级pip |
| 权限错误 | 检查文件和数据库权限 |
| 微信登录失败 | 检查appid和secret配置 |

---

## ✅ 启动检查清单

在新设备上部署时，请按顺序检查：

- [ ] Python 3.8+ 已安装
- [ ] MySQL 8.0+ 已安装并运行
- [ ] 虚拟环境已创建并激活
- [ ] 依赖已安装 (`pip install -r requirements.txt`)
- [ ] 数据库已创建
- [ ] .env文件已配置
- [ ] 端口8000可用
- [ ] 服务成功启动
- [ ] API文档可访问
- [ ] 基础API测试通过

**恭喜！项目已成功部署！** 🎉