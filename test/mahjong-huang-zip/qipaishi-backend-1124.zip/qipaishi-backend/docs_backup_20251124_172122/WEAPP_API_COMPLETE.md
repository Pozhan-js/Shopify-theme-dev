# 📱 微信小程序完整API文档

## 🎯 接口总览

基于24h棋牌室微信小程序所有API需求，现已完整实现所有接口。

### 基础信息
- **Base URL**: `http://localhost:8000/api/v1/member`
- **Content-Type**: `application/json`
- **认证**: 部分接口需要用户认证

---

## 📋 接口映射表

| 微信小程序接口 | 后端实现路径 | 说明 |
|---|---|---|
| `/member/index/getStoreList` | `GET /api/v1/member/index/getStoreList` | 获取门店列表 |
| `/member/index/getCityList` | `GET /api/v1/member/index/getCityList` | 获取城市列表 |
| `/member/index/getStoreInfo/{id}` | `GET /api/v1/member/index/getStoreInfo/{store_id}` | 获取门店详情 |
| `/member/index/getRoomInfoList/{id}` | `GET /api/v1/member/index/getRoomInfoList/{store_id}` | 获取房间列表 |
| `/member/index/getRoomInfo/{id}` | `GET /api/v1/member/index/getRoomInfo/{room_id}` | 获取房间详情 |
| `/member/index/getBannerList` | `GET /api/v1/member/index/getBannerList` | 获取轮播图 |
| `/member/index/getSysInfo` | `GET /api/v1/member/index/getSysInfo` | 获取系统信息 |
| `/member/user/get` | `GET /api/v1/member/user/get` | 获取用户信息 |
| `/member/auth/wxLoginByCode` | `POST /api/v1/member/auth/wxLoginByCode` | 微信登录 |
| `/member/user/update-mobile` | `POST /api/v1/member/user/update-mobile` | 更新手机号 |
| `/member/user/updateNickname` | `POST /api/v1/member/user/updateNickname` | 更新昵称 |
| `/member/user/updateAvatar` | `POST /api/v1/member/user/updateAvatar` | 更新头像 |
| `/member/order/getOrderPage` | `GET /api/v1/member/order/getOrderPage` | 获取订单分页 |
| `/member/order/getOrderInfo` | `GET /api/v1/member/order/getOrderInfo` | 获取订单信息 |
| `/member/order/getOrderInfoByNo` | `GET /api/v1/member/order/getOrderInfoByNo` | 根据订单号获取订单 |
| `/member/order/cancelOrder/{id}` | `POST /api/v1/member/order/cancelOrder/{order_id}` | 取消订单 |
| `/member/order/openRoomDoor` | `POST /api/v1/member/order/openRoomDoor` | 开门 |
| `/member/order/openStoreDoor` | `POST /api/v1/member/order/openStoreDoor` | 开门店门 |
| `/member/store/uploadImg` | `POST /api/v1/member/store/uploadImg` | 上传图片 |

---

## 🏪 首页接口

### 1. 获取门店列表
```http
GET /api/v1/member/index/getStoreList
```

**参数:**
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| cityName | string | 否 | 城市名称 |
| page | int | 否 | 页码，默认1 |
| pageSize | int | 否 | 每页数量，默认10 |

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "list": [
      {
        "store_id": 1,
        "store_name": "演示-24h棋牌室",
        "city_name": "成都",
        "head_img": "https://images.scyanzu.com/demo-store.jpg",
        "lat": 30.657349,
        "lon": 104.065837,
        "address": "四川省成都市人民南路一段86号",
        "room_num": 3,
        "status": 0
      }
    ],
    "total": 1
  }
}
```

### 2. 获取城市列表
```http
GET /api/v1/member/index/getCityList
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": ["成都", "北京", "上海"]
}
```

### 3. 获取门店详情
```http
GET /api/v1/member/index/getStoreInfo/{store_id}
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "store_id": 1,
    "store_name": "演示-24h棋牌室",
    "city_name": "成都",
    "content": "<p>欢迎来到24h棋牌室...</p>",
    "head_img": "https://images.scyanzu.com/demo-store.jpg",
    "store_env_img": "https://images.scyanzu.com/demo-env.jpg",
    "banner_img": "https://images.scyanzu.com/demo-banner.jpg",
    "notice": "<p><strong>重要提示</strong></p>...",
    "lat": 30.657349,
    "lon": 104.065837,
    "address": "四川省成都市人民南路一段86号",
    "wifi_info": "CMCC-Free",
    "wifi_pwd": "12345678",
    "kefu_phone": "15675555180",
    "room_num": 3,
    "status": 0
  }
}
```

### 4. 获取房间列表
```http
GET /api/v1/member/index/getRoomInfoList/{store_id}
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "room_id": 1,
      "room_name": "豪华棋牌室A",
      "room_call_name": "棋牌A",
      "room_class": 0,
      "price": 25.0,
      "deposit": 50.0,
      "status": 1,
      "image_urls": "https://images.scyanzu.com/room1.jpg",
      "label": "豪华装修,独立空调,免费WiFi",
      "min_hour": 2,
      "lead_hour": 4,
      "lead_day": 7
    }
  ]
}
```

### 5. 获取房间详情
```http
GET /api/v1/member/index/getRoomInfo/{room_id}
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "room_id": 1,
    "room_name": "豪华棋牌室A",
    "room_call_name": "棋牌A",
    "room_class": 0,
    "price": 25.0,
    "deposit": 50.0,
    "work_price": 20.0,
    "tongxiao_price": 80.0,
    "label": "豪华装修,独立空调,免费WiFi",
    "image_urls": "https://images.scyanzu.com/room1.jpg",
    "status": 1,
    "min_hour": 2,
    "lead_hour": 4,
    "lead_day": 7
  }
}
```

### 6. 获取轮播图
```http
GET /api/v1/member/index/getBannerList
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 1,
      "image_url": "https://images.scyanzu.com/banner1.jpg",
      "link_url": "/pages/store/detail?id=1",
      "sort": 1
    }
  ]
}
```

### 7. 获取系统信息
```http
GET /api/v1/member/index/getSysInfo
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "version": "1.0.0",
    "name": "24h棋牌室",
    "description": "24小时棋牌室预约系统"
  }
}
```

---

## 👤 用户相关接口

### 8. 获取用户信息
```http
GET /api/v1/member/user/get?user_id=1
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "id": 1,
    "openid": "wx_demo_code",
    "nickname": "微信用户",
    "avatar_url": "https://images.scyanzu.com/avatar.jpg",
    "phone": "13800138000",
    "balance": 100.0,
    "total_consume": 500.0,
    "status": 1
  }
}
```

### 9. 微信小程序登录
```http
POST /api/v1/member/auth/wxLoginByCode?code=wx_code
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "登录成功",
  "data": {
    "user_id": 1,
    "openid": "wx_demo_code",
    "nickname": "微信用户",
    "avatar_url": "https://images.scyanzu.com/avatar.jpg",
    "phone": null,
    "balance": 0.0,
    "token": "token_1"
  }
}
```

### 10. 更新用户手机号
```http
POST /api/v1/member/user/update-mobile?user_id=1&mobile=13800138000
```

**响应示例:**
```json
{"code": 200, "msg": "手机号更新成功"}
```

### 11. 更新用户昵称
```http
POST /api/v1/member/user/updateNickname?user_id=1&nickname=新昵称
```

**响应示例:**
```json
{"code": 200, "msg": "昵称更新成功"}
```

### 12. 更新用户头像
```http
POST /api/v1/member/user/updateAvatar?user_id=1&avatarUrl=https://new-avatar.jpg
```

**响应示例:**
```json
{"code": 200, "msg": "头像更新成功"}
```

---

## 📋 订单相关接口

### 13. 获取订单分页列表
```http
GET /api/v1/member/order/getOrderPage?user_id=1&status=1&page=1&pageSize=10
```

**参数:**
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| user_id | int | 是 | 用户ID |
| status | int | 否 | 订单状态 |
| page | int | 否 | 页码，默认1 |
| pageSize | int | 否 | 每页数量，默认10 |

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "list": [
      {
        "id": 1,
        "order_no": "QD202401011400001",
        "store_id": 1,
        "room_id": 1,
        "product_name": "豪华棋牌室A - 2小时",
        "start_time": "2024-01-01T14:00:00",
        "end_time": "2024-01-01T16:00:00",
        "use_hour": 2.0,
        "total_price": 50.0,
        "pay_price": 50.0,
        "status": 1,
        "create_time": "2024-01-01T13:30:00"
      }
    ],
    "total": 10
  }
}
```

### 14. 获取用户订单信息
```http
GET /api/v1/member/order/getOrderInfo?user_id=1
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 1,
      "order_no": "QD202401011400001",
      "store_id": 1,
      "room_id": 1,
      "product_name": "豪华棋牌室A - 2小时",
      "start_time": "2024-01-01T14:00:00",
      "end_time": "2024-01-01T16:00:00",
      "use_hour": 2.0,
      "total_price": 50.0,
      "status": 1
    }
  ]
}
```

### 15. 根据订单号获取订单
```http
GET /api/v1/member/order/getOrderInfoByNo?orderKey=QD202401011400001
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "id": 1,
    "order_no": "QD202401011400001",
    "user_id": 1,
    "store_id": 1,
    "room_id": 1,
    "product_name": "豪华棋牌室A - 2小时",
    "start_time": "2024-01-01T14:00:00",
    "end_time": "2024-01-01T16:00:00",
    "use_hour": 2.0,
    "total_price": 50.0,
    "pay_price": 50.0,
    "status": 1,
    "create_time": "2024-01-01T13:30:00"
  }
}
```

### 16. 取消订单
```http
POST /api/v1/member/order/cancelOrder/{order_id}
```

**响应示例:**
```json
{"code": 200, "msg": "订单取消成功"}
```

### 17. 开门接口
```http
POST /api/v1/member/order/openRoomDoor?orderKey=QD202401011400001
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "开门成功",
  "data": {
    "success": true,
    "message": "门已打开"
  }
}
```

### 18. 开门店门接口
```http
POST /api/v1/member/order/openStoreDoor?orderKey=QD202401011400001
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "门店门已打开",
  "data": {"success": true}
}
```

---

## 📁 文件上传接口

### 19. 上传图片
```http
POST /api/v1/member/store/uploadImg
Content-Type: multipart/form-data
```

**请求体:**
```
file: [图片文件]
```

**响应示例:**
```json
{
  "code": 200,
  "msg": "上传成功",
  "data": "http://localhost:8000/uploads/xxx.jpg"
}
```

---

## 🧪 完整测试用例

### 微信小程序端测试
```javascript
// 测试所有接口
const baseUrl = 'http://localhost:8000/api/v1/member';

// 1. 获取门店列表
wx.request({
  url: baseUrl + '/index/getStoreList',
  success: (res) => {
    console.log('门店列表:', res.data);
  }
});

// 2. 获取城市列表
wx.request({
  url: baseUrl + '/index/getCityList',
  success: (res) => {
    console.log('城市列表:', res.data);
  }
});

// 3. 获取门店详情
wx.request({
  url: baseUrl + '/index/getStoreInfo/1',
  success: (res) => {
    console.log('门店详情:', res.data);
  }
});

// 4. 获取房间列表
wx.request({
  url: baseUrl + '/index/getRoomInfoList/1',
  success: (res) => {
    console.log('房间列表:', res.data);
  }
});

// 5. 微信登录
wx.request({
  url: baseUrl + '/auth/wxLoginByCode?code=test_code',
  method: 'POST',
  success: (res) => {
    console.log('登录结果:', res.data);
  }
});

// 6. 获取用户信息
wx.request({
  url: baseUrl + '/user/get?user_id=1',
  success: (res) => {
    console.log('用户信息:', res.data);
  }
});

// 7. 获取订单列表
wx.request({
  url: baseUrl + '/order/getOrderPage?user_id=1',
  success: (res) => {
    console.log('订单列表:', res.data);
  }
});
```

---

## 🔧 快速验证

### 一键测试脚本
```bash
#!/bin/bash

echo "🧪 测试微信小程序接口..."

BASE_URL="http://localhost:8000/api/v1/member"

echo "1. 获取门店列表..."
curl -s "$BASE_URL/index/getStoreList" | jq .

echo "2. 获取城市列表..."
curl -s "$BASE_URL/index/getCityList" | jq .

echo "3. 获取门店详情..."
curl -s "$BASE_URL/index/getStoreInfo/1" | jq .

echo "4. 获取房间列表..."
curl -s "$BASE_URL/index/getRoomInfoList/1" | jq .

echo "5. 微信登录..."
curl -s -X POST "$BASE_URL/auth/wxLoginByCode?code=test123" | jq .

echo "6. 获取用户信息..."
curl -s "$BASE_URL/user/get?user_id=1" | jq .

echo "✅ 所有接口测试完成！"
```

---

## 🎯 使用说明

### 1. 启动服务
```bash
cd qipaishi-backend
python3 -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 2. 微信小程序配置
在小程序的`app.js`中配置：
```javascript
App({
  globalData: {
    baseUrl: 'http://localhost:8000/api/v1/member',
    userInfo: null
  }
})
```

### 3. 测试连接
访问：http://localhost:8000/docs 查看完整API文档

**🎉 现在24h棋牌室微信小程序的所有接口都已完整实现！**