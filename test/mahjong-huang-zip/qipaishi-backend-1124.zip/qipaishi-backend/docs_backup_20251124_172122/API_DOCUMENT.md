# 24h棋牌室后台管理系统API文档

## 系统概述

基于FastAPI开发的24小时棋牌室预约管理系统后台管理接口，提供完整的门店、用户、订单、系统管理功能。

## 认证方式

所有管理接口都需要使用JWT Token进行认证，在请求头中添加：
```
Authorization: Bearer <token>
```

### 获取管理员Token
```http
POST /api/v1/admin/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```

## 接口列表

### 1. 认证管理

#### 管理员登录
```http
POST /api/v1/admin/auth/login
```

#### 获取管理员信息
```http
GET /api/v1/admin/auth/profile
```

#### 更新管理员信息
```http
PUT /api/v1/admin/auth/profile
```

### 2. 用户管理

#### 获取用户列表
```http
GET /api/v1/admin/user/list?page=1&page_size=10&keyword=张三
```

#### 获取用户详情
```http
GET /api/v1/admin/user/detail/{user_id}
```

#### 更新用户状态
```http
PUT /api/v1/admin/user/status/{user_id}?status=0
```

#### 删除用户
```http
DELETE /api/v1/admin/user/{user_id}
```

#### 获取用户统计
```http
GET /api/v1/admin/user/statistics
```

### 3. 门店管理

#### 获取门店列表
```http
GET /api/v1/admin/store/list?page=1&page_size=10&keyword=北京
```

#### 创建门店
```http
POST /api/v1/admin/store/create
```

#### 更新门店信息
```http
PUT /api/v1/admin/store/update/{store_id}
```

#### 删除门店
```http
DELETE /api/v1/admin/store/{store_id}
```

#### 获取门店详情
```http
GET /api/v1/admin/store/detail/{store_id}
```

#### 上传门店图片
```http
POST /api/v1/admin/store/upload-image
Content-Type: multipart/form-data
```

### 4. 房间管理

#### 获取房间列表
```http
GET /api/v1/admin/store/room/list/{store_id}?page=1&page_size=10
```

#### 创建房间
```http
POST /api/v1/admin/store/room/create
```

#### 更新房间信息
```http
PUT /api/v1/admin/store/room/update/{room_id}
```

#### 删除房间
```http
DELETE /api/v1/admin/store/room/{room_id}
```

### 5. 订单管理

#### 获取订单列表
```http
GET /api/v1/admin/order/list?page=1&page_size=10&status=2
```

#### 获取订单详情
```http
GET /api/v1/admin/order/detail/{order_id}
```

#### 更新订单状态
```http
PUT /api/v1/admin/order/status/{order_id}?status=3
```

#### 订单退款
```http
POST /api/v1/admin/order/refund/{order_id}
```

#### 获取订单统计
```http
GET /api/v1/admin/order/statistics
```

### 6. 系统管理

#### 管理员管理

##### 获取管理员列表
```http
GET /api/v1/admin/system/admin/list?page=1&page_size=10
```

##### 创建管理员
```http
POST /api/v1/admin/system/admin/create
```

##### 更新管理员信息
```http
PUT /api/v1/admin/system/admin/update/{admin_id}
```

##### 删除管理员
```http
DELETE /api/v1/admin/system/admin/{admin_id}
```

#### 日志管理

##### 获取登录日志
```http
GET /api/v1/admin/system/login-log/list?page=1&page_size=10
```

##### 获取操作日志
```http
GET /api/v1/admin/system/operation-log/list?page=1&page_size=10
```

#### 仪表盘数据
```http
GET /api/v1/admin/system/dashboard
```

## 数据模型

### 用户模型
```json
{
  "id": 1,
  "openid": "用户微信OpenID",
  "nickname": "用户昵称",
  "avatar": "用户头像",
  "phone": "手机号",
  "status": 1,
  "created_at": "2024-01-01T00:00:00",
  "updated_at": "2024-01-01T00:00:00"
}
```

### 门店模型
```json
{
  "id": 1,
  "name": "北京朝阳店",
  "phone": "010-12345678",
  "address": "北京市朝阳区xxx路xxx号",
  "longitude": 116.4074,
  "latitude": 39.9042,
  "business_hours": "08:00-24:00",
  "description": "24小时营业的棋牌室",
  "images": ["image1.jpg", "image2.jpg"],
  "status": 1,
  "sort_order": 0
}
```

### 房间模型
```json
{
  "id": 1,
  "store_id": 1,
  "name": "豪华大包",
  "type": 3,
  "capacity": 8,
  "price": 88.00,
  "description": "豪华装修，配备自动麻将机",
  "images": ["room1.jpg"],
  "equipment": {"mahjong": true, "air_conditioner": true},
  "status": 1,
  "sort_order": 0
}
```

### 订单模型
```json
{
  "id": 1,
  "order_no": "202401010001",
  "member_id": 1,
  "store_id": 1,
  "room_id": 1,
  "appointment_date": "2024-01-01",
  "start_time": "14:00",
  "end_time": "18:00",
  "total_amount": 352.00,
  "status": 2,
  "payment_time": "2024-01-01T13:30:00",
  "created_at": "2024-01-01T13:00:00"
}
```

## 状态码说明

### 用户状态
- 1: 正常
- 0: 禁用

### 门店状态
- 1: 营业中
- 0: 休息中

### 房间状态
- 1: 可用
- 0: 不可用

### 订单状态
- 1: 待支付
- 2: 已支付
- 3: 已完成
- 4: 已取消
- 5: 已退款

### 房间类型
- 1: 小包
- 2: 中包
- 3: 大包
- 4: 豪包

## 错误码说明

- 400: 请求参数错误
- 401: 未授权或Token无效
- 403: 权限不足
- 404: 资源不存在
- 500: 服务器内部错误

## 分页参数

所有列表接口都支持以下分页参数：
- `page`: 页码，从1开始
- `page_size`: 每页数量，默认10，最大100

## 搜索参数

支持以下搜索参数：
- `keyword`: 关键词搜索
- `start_date`: 开始日期 (YYYY-MM-DD)
- `end_date`: 结束日期 (YYYY-MM-DD)
- `status`: 状态筛选

## 使用示例

### 1. 管理员登录
```bash
curl -X POST "http://localhost:8000/api/v1/admin/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }'
```

### 2. 获取用户列表
```bash
curl -X GET "http://localhost:8000/api/v1/admin/user/list?page=1&page_size=10" \
  -H "Authorization: Bearer <token>"
```

### 3. 创建门店
```bash
curl -X POST "http://localhost:8000/api/v1/admin/store/create" \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "北京朝阳店",
    "phone": "010-12345678",
    "address": "北京市朝阳区xxx路xxx号",
    "longitude": 116.4074,
    "latitude": 39.9042,
    "business_hours": "08:00-24:00",
    "description": "24小时营业的棋牌室",
    "status": 1
  }'
```

### 4. 获取订单统计
```bash
curl -X GET "http://localhost:8000/api/v1/admin/order/statistics" \
  -H "Authorization: Bearer <token>"
```

## 部署说明

### 环境要求
- Python 3.8+
- MySQL 5.7+
- Redis (可选)

### 安装依赖
```bash
pip install -r requirements.txt
```

### 数据库迁移
```bash
alembic upgrade head
```

### 启动服务
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 访问文档
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc