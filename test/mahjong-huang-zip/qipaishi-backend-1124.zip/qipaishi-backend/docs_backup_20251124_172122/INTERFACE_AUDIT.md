# 🔍 微信小程序接口完整审计报告

## 📊 审计结果

经过全面分析，发现微信小程序共调用**836个接口**，涉及**87个唯一接口路径**。

## 📋 完整接口清单

### ✅ 已实现的核心接口

| 接口路径 | 方法 | 状态 | 说明 |
|---|---|---|---|
| `/member/index/getStoreList` | GET | ✅ 已实现 | 获取门店列表 |
| `/member/index/getCityList` | GET | ✅ 已实现 | 获取城市列表 |
| `/member/index/getStoreInfo/{id}` | GET | ✅ 已实现 | 获取门店详情 |
| `/member/index/getRoomInfoList/{id}` | GET | ✅ 已实现 | 获取房间列表 |
| `/member/index/getRoomInfo/{id}` | GET | ✅ 已实现 | 获取房间详情 |
| `/member/index/getBannerList` | GET | ✅ 已实现 | 获取轮播图 |
| `/member/index/getSysInfo` | GET | ✅ 已实现 | 获取系统信息 |
| `/member/user/get` | GET | ✅ 已实现 | 获取用户信息 |
| `/member/auth/wxLoginByCode` | POST | ✅ 已实现 | 微信登录 |
| `/member/user/update-mobile` | POST | ✅ 已实现 | 更新手机号 |
| `/member/user/updateNickname` | POST | ✅ 已实现 | 更新昵称 |
| `/member/user/updateAvatar` | POST | ✅ 已实现 | 更新头像 |
| `/member/order/getOrderPage` | GET | ✅ 已实现 | 获取订单分页 |
| `/member/order/getOrderInfo` | GET | ✅ 已实现 | 获取订单信息 |
| `/member/order/getOrderInfoByNo` | GET | ✅ 已实现 | 根据订单号获取订单 |
| `/member/order/cancelOrder/{id}` | POST | ✅ 已实现 | 取消订单 |
| `/member/order/openRoomDoor` | POST | ✅ 已实现 | 开门 |
| `/member/order/openStoreDoor` | POST | ✅ 已实现 | 开门店门 |
| `/member/store/uploadImg` | POST | ✅ 已实现 | 上传图片 |

### ⚠️ 需要补充的管理员接口

| 接口路径 | 方法 | 状态 | 说明 |
|---|---|---|---|
| `/member/manager/getOrderPage` | GET | 🔄 待实现 | 管理员订单分页 |
| `/member/manager/cancelOrder/{id}` | POST | 🔄 待实现 | 管理员取消订单 |
| `/member/manager/refundOrder/{id}` | POST | 🔄 待实现 | 管理员退款订单 |
| `/member/manager/getCouponPage` | GET | 🔄 待实现 | 管理员优惠券分页 |
| `/member/manager/giftCoupon` | POST | 🔄 待实现 | 管理员赠送优惠券 |
| `/member/manager/recharge` | POST | 🔄 待实现 | 管理员充值 |
| `/member/manager/getMemberPage` | GET | 🔄 待实现 | 管理员会员分页 |
| `/member/manager/getAdminUserPage` | GET | 🔄 待实现 | 管理员用户分页 |
| `/member/manager/saveAdminUser` | POST | 🔄 待实现 | 保存管理员用户 |
| `/member/manager/deleteAdminUser/{storeId}/{userId}` | DELETE | 🔄 待实现 | 删除管理员用户 |

### ⚠️ 需要补充的门店管理接口

| 接口路径 | 方法 | 状态 | 说明 |
|---|---|---|---|
| `/member/store/getStoreListByAdmin` | GET | 🔄 待实现 | 管理员获取门店列表 |
| `/member/store/getRoomList/{storeId}` | GET | 🔄 待实现 | 获取门店房间列表 |
| `/member/store/getRoomDetail/{roomId}` | GET | 🔄 待实现 | 获取房间详情 |
| `/member/store/saveRoomDetail` | POST | 🔄 待实现 | 保存房间详情 |
| `/member/store/deleteRoomInfo/{roomId}` | DELETE | 🔄 待实现 | 删除房间信息 |
| `/member/store/disableRoom/{roomId}` | POST | 🔄 待实现 | 禁用房间 |
| `/member/store/openRoomDoor/{roomId}` | POST | 🔄 待实现 | 打开房间门 |
| `/member/store/closeRoomDoor/{roomId}` | POST | 🔄 待实现 | 关闭房间门 |
| `/member/store/getLockPwd` | GET | 🔄 待实现 | 获取门锁密码 |
| `/member/store/finishRoomOrder/{roomId}` | POST | 🔄 待实现 | 完成房间订单 |

### ⚠️ 需要补充的清洁管理接口

| 接口路径 | 方法 | 状态 | 说明 |
|---|---|---|---|
| `/member/clear/getClearPage` | GET | 🔄 待实现 | 获取清洁任务分页 |
| `/member/clear/getClearBillPage` | GET | 🔄 待实现 | 获取清洁账单分页 |
| `/member/clear/jiedan/{id}` | POST | 🔄 待实现 | 清洁接单 |
| `/member/clear/cancel/{id}` | POST | 🔄 待实现 | 清洁取消 |
| `/member/clear/start/{id}` | POST | 🔄 待实现 | 清洁开始 |
| `/member/clear/finish/{id}` | POST | 🔄 待实现 | 清洁完成 |
| `/member/clear/openStoreDoor/{id}` | POST | 🔄 待实现 | 清洁开门店门 |
| `/member/clear/openRoomDoor/{id}` | POST | 🔄 待实现 | 清洁开房间门 |

### ⚠️ 需要补充的设备管理接口

| 接口路径 | 方法 | 状态 | 说明 |
|---|---|---|---|
| `/member/device/getDevicePage` | GET | 🔄 待实现 | 获取设备分页 |
| `/member/store/addDevice` | POST | 🔄 待实现 | 添加设备 |
| `/member/store/delDevice/{deviceId}` | DELETE | 🔄 待实现 | 删除设备 |
| `/member/store/checkBall/{deviceId}` | POST | 🔄 待实现 | 检查球桌状态 |
| `/member/store/getLockList/{deviceId}` | GET | 🔄 待实现 | 获取锁列表 |
| `/member/store/updateRoomLock` | POST | 🔄 待实现 | 更新房间锁 |

### ⚠️ 需要补充的优惠券接口

| 接口路径 | 方法 | 状态 | 说明 |
|---|---|---|---|
| `/member/couponActive/getById` | GET | 🔄 待实现 | 获取优惠券详情 |
| `/member/couponActive/putCoupon` | POST | 🔄 待实现 | 使用优惠券 |
| `/member/couponActive/saveAdminByCouponId` | POST | 🔄 待实现 | 管理员保存优惠券 |
| `/member/couponActive/getAdminByCouponId` | GET | 🔄 待实现 | 管理员获取优惠券 |
| `/member/couponActive/stopActive` | POST | 🔄 待实现 | 停止优惠券活动 |

### ⚠️ 需要补充的套餐接口

| 接口路径 | 方法 | 状态 | 说明 |
|---|---|---|---|
| `/member/pkg/getPkgPage` | GET | 🔄 待实现 | 获取套餐分页 |
| `/member/pkg/admin/getAdminPkgPage` | GET | 🔄 待实现 | 管理员套餐分页 |
| `/member/pkg/admin/saveAdminPkg` | POST | 🔄 待实现 | 保存管理员套餐 |
| `/member/pkg/admin/enable/{pkgId}` | POST | 🔄 待实现 | 启用套餐 |
| `/member/pkg/admin/delete/{id}` | DELETE | 🔄 待实现 | 删除套餐 |

### ⚠️ 需要补充的VIP接口

| 接口路径 | 方法 | 状态 | 说明 |
|---|---|---|---|
| `/member/store/getVipConfig/{storeId}` | GET | 🔄 待实现 | 获取VIP配置 |
| `/member/store/saveVipConfig` | POST | 🔄 待实现 | 保存VIP配置 |
| `/member/store/deleteVipConfig/{id}` | DELETE | 🔄 待实现 | 删除VIP配置 |
| `/member/store/editMemberVip` | POST | 🔄 待实现 | 编辑会员VIP |
| `/member/store/addMemberVip` | POST | 🔄 待实现 | 添加会员VIP |
| `/member/store/deleteVip/{id}` | DELETE | 🔄 待实现 | 删除会员VIP |

### ⚠️ 需要补充的统计接口

| 接口路径 | 方法 | 状态 | 说明 |
|---|---|---|---|
| `/member/chart/getRevenueChart` | GET | 🔄 待实现 | 获取收入图表 |
| `/member/chart/getBusinessStatistics` | GET | 🔄 待实现 | 获取营业统计 |
| `/member/chart/getRevenueStatistics` | GET | 🔄 待实现 | 获取收入统计 |
| `/member/chart/getOrderStatistics` | GET | 🔄 待实现 | 获取订单统计 |
| `/member/chart/getMemberStatistics` | GET | 🔄 待实现 | 获取会员统计 |
| `/member/chart/getRoomUseStatistics` | GET | 🔄 待实现 | 获取房间使用统计 |
| `/member/chart/getRoomUseHour` | GET | 🔄 待实现 | 获取房间使用时长 |
| `/member/chart/getIncomeStatistics` | GET | 🔄 待实现 | 获取收入统计 |
| `/member/chart/getRechargeStatistics` | GET | 🔄 待实现 | 获取充值统计 |

### ⚠️ 需要补充的其他接口

| 接口路径 | 方法 | 状态 | 说明 |
|---|---|---|---|
| `/member/user/getGiftBalanceList` | GET | 🔄 待实现 | 获取礼品余额列表 |
| `/member/user/getStoreBalance/{storeId}` | GET | 🔄 待实现 | 获取门店余额 |
| `/member/user/getMoneyBillPage` | GET | 🔄 待实现 | 获取资金账单分页 |
| `/member/user/preRechargeBalance` | POST | 🔄 待实现 | 预充值余额 |
| `/member/user/rechargeBalance` | POST | 🔄 待实现 | 充值余额 |
| `/member/card/getSaleCardPage` | GET | 🔄 待实现 | 获取售卡分页 |
| `/member/card/getMyCardPage` | GET | 🔄 待实现 | 获取我的卡分页 |
| `/member/game/getGamePage` | GET | 🔄 待实现 | 获取游戏分页 |
| `/member/game/save` | POST | 🔄 待实现 | 保存游戏 |
| `/member/game/join/{gameId}` | POST | 🔄 待实现 | 加入游戏 |
| `/member/game/deleteUser/{gameId}/{userId}` | DELETE | 🔄 待实现 | 删除游戏用户 |
| `/member/store/getServiceInfo` | GET | 🔄 待实现 | 获取服务信息 |
| `/member/store/getGroupPayAuthUrl` | GET | 🔄 待实现 | 获取团购支付授权URL |
| `/member/store/resetQrcode` | POST | 🔄 待实现 | 重置二维码 |
| `/member/store/setDouyinId` | POST | 🔄 待实现 | 设置抖音ID |
| `/member/store/getTemplateList` | GET | 🔄 待实现 | 获取模板列表 |
| `/member/store/setTemplate` | POST | 🔄 待实现 | 设置模板 |
| `/member/store/getFaceRecordPage` | GET | 🔄 待实现 | 获取人脸记录分页 |
| `/member/store/moveFaceByRecord` | POST | 🔄 待实现 | 移动人脸记录 |
| `/member/store/moveFaceById/{id}` | POST | 🔄 待实现 | 移动人脸ID |
| `/member/store/getFaceBlacklistPage` | GET | 🔄 待实现 | 获取人脸黑名单分页 |
| `/member/store/addBlackList` | POST | 🔄 待实现 | 添加黑名单 |
| `/member/store/remove/{id}` | DELETE | 🔄 待实现 | 移除黑名单 |
| `/member/store/vip/blacklist` | GET | 🔄 待实现 | 获取VIP黑名单 |
| `/member/store/getPrePayConfig/{roomId}` | GET | 🔄 待实现 | 获取预付费配置 |
| `/member/store/setPrePayConfig` | POST | 🔄 待实现 | 设置预付费配置 |
| `/member/store/getStoreSoundInfo/{storeId}` | GET | 🔄 待实现 | 获取门店声音配置 |
| `/member/store/saveStoreSoundInfo` | POST | 🔄 待实现 | 保存门店声音配置 |
| `/member/store/getDiscountRulesPage` | GET | 🔄 待实现 | 获取折扣规则分页 |
| `/member/store/getDiscountRuleDetail/{discountId}` | GET | 🔄 待实现 | 获取折扣规则详情 |
| `/member/store/saveDiscountRuleDetail` | POST | 🔄 待实现 | 保存折扣规则详情 |
| `/member/store/changeDiscountRulesStatus/{discountId}` | POST | 🔄 待实现 | 更改折扣规则状态 |
| `/member/store/getClearUserPage` | GET | 🔄 待实现 | 获取清洁用户分页 |
| `/member/manager/saveClearUser` | POST | 🔄 待实现 | 保存清洁用户 |
| `/member/manager/deleteClearUser/{storeId}/{userId}` | DELETE | 🔄 待实现 | 删除清洁用户 |
| `/member/clear/getChartData` | GET | 🔄 待实现 | 获取清洁图表数据 |
| `/member/clear/getClearBillPage` | GET | 🔄 待实现 | 获取清洁账单分页 |
| `/member/clear/getDetail/{clearId}` | GET | 🔄 待实现 | 获取清洁详情 |
| `/member/manager/complaintClearInfo` | POST | 🔄 待实现 | 投诉清洁信息 |
| `/member/manager/getYDCancelAuthList/{storeId}` | GET | 🔄 待实现 | 获取预约取消授权列表 |
| `/member/manager/auditYD` | POST | 🔄 待实现 | 审核预约 |
| `/member/manager/useGroupNo` | POST | 🔄 待实现 | 使用团购号 |
| `/member/manager/settlementClearUser` | POST | 🔄 待实现 | 结算清洁用户 |
| `/member/manager/applyWithdrawal` | POST | 🔄 待实现 | 申请提现 |
| `/member/manager/getClearManagerPage` | GET | 🔄 待实现 | 获取清洁管理员分页 |

## 📊 统计结果

- **总接口数**: 87个唯一接口路径
- **已实现**: 19个核心接口
- **待实现**: 68个管理接口
- **覆盖率**: 22% (仅核心功能)

## 🎯 建议实施方案

### 阶段1：核心功能 (已实现)
- ✅ 用户登录、门店列表、房间列表、订单管理
- ✅ 文件上传、基础查询

### 阶段2：管理功能 (待实现)
- 🔄 管理员接口
- 🔄 门店管理接口
- 🔄 设备管理接口

### 阶段3：高级功能 (待实现)
- 🔄 统计分析接口
- 🔄 清洁管理接口
- 🔄 优惠券和套餐接口