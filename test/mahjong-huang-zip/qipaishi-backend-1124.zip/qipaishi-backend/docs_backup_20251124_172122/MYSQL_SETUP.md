# MySQL数据库配置指南

## 1. 安装MySQL

### macOS (使用Homebrew)
```bash
brew install mysql
brew services start mysql
```

### Ubuntu/Debian
```bash
sudo apt update
sudo apt install mysql-server
sudo systemctl start mysql
sudo systemctl enable mysql
```

### Windows
从MySQL官网下载安装程序：https://dev.mysql.com/downloads/installer/

## 2. 配置MySQL

### 设置root密码
```bash
mysql_secure_installation
```

### 创建数据库
```bash
mysql -u root -p
```

在MySQL命令行中执行：
```sql
CREATE DATABASE qipaishi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'qipaishi_user'@'localhost' IDENTIFIED BY 'qipaishi_password';
GRANT ALL PRIVILEGES ON qipaishi.* TO 'qipaishi_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

## 3. 更新环境变量

### 修改.env文件
根据你的MySQL配置更新：
```bash
# 使用root用户
DATABASE_URL=mysql+pymysql://root:your_password@localhost:3306/qipaishi?charset=utf8mb4

# 或者使用新建的用户
DATABASE_URL=mysql+pymysql://qipaishi_user:qipaishi_password@localhost:3306/qipaishi?charset=utf8mb4
```

## 4. 数据库迁移

### 安装依赖
```bash
pip install -r requirements.txt
```

### 初始化数据库
```bash
# 进入项目目录
cd qipaishi-backend

# 初始化Alembic（如果还没做的话）
alembic init alembic

# 创建初始迁移
alembic revision --autogenerate -m "Initial migration"

# 应用迁移
alembic upgrade head
```

### 测试数据库连接
```bash
python test_db.py
```

## 5. 常见问题解决

### 连接被拒绝
- 确保MySQL服务正在运行：`sudo systemctl status mysql`
- 检查端口是否开放：`netstat -tlnp | grep 3306`
- 验证用户权限：`mysql -u qipaishi_user -p qipaishi`

### 字符集问题
- 确保数据库使用utf8mb4字符集
- 在连接字符串中添加`charset=utf8mb4`

### 权限问题
```sql
-- 给用户所有权限
GRANT ALL PRIVILEGES ON *.* TO 'qipaishi_user'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;
```

## 6. 验证安装

### 运行测试
```bash
python -c "
from sqlalchemy import create_engine
from app.core.config import settings
engine = create_engine(settings.DATABASE_URL)
connection = engine.connect()
print('✅ MySQL连接成功！')
connection.close()
"
```

### 启动应用
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

访问 http://localhost:8000/docs 查看API文档