# 📚 24h棋牌室后端API文档

## 🎯 微信小程序专用接口

### 基础信息
- **Base URL**: `http://localhost:8000/api/v1/weapp`
- **Content-Type**: `application/json`
- **认证**: 部分接口需要用户认证

---

## 🏪 门店相关接口

### 1. 获取门店列表
```http
GET /api/v1/weapp/store/list
```

**参数:**
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| city_name | string | 否 | 城市名称 |
| keyword | string | 否 | 搜索关键词 |

**响应示例:**
```json
[
  {
    "store_id": 1,
    "store_name": "演示-24h棋牌室",
    "city_name": "成都",
    "head_img": "https://images.scyanzu.com/demo-store.jpg",
    "lat": 30.657349,
    "lon": 104.065837,
    "address": "四川省成都市人民南路一段86号",
    "room_num": 3,
    "total_money": 0.0,
    "status": 0
  }
]
```

### 2. 获取门店详情
```http
GET /api/v1/weapp/store/{store_id}
```

**响应示例:**
```json
{
  "store_id": 1,
  "store_name": "演示-24h棋牌室",
  "city_name": "成都",
  "content": "<p>欢迎来到24h棋牌室...</p>",
  "head_img": "https://images.scyanzu.com/demo-store.jpg",
  "store_env_img": "https://images.scyanzu.com/demo-env.jpg",
  "banner_img": "https://images.scyanzu.com/demo-banner.jpg",
  "notice": "<p><strong>重要提示</strong></p>...",
  "lat": 30.657349,
  "lon": 104.065837,
  "address": "四川省成都市人民南路一段86号",
  "wifi_info": "CMCC-Free",
  "wifi_pwd": "12345678",
  "kefu_phone": "15675555180",
  "room_num": 3,
  "status": 0
}
```

---

## 🏠 房间相关接口

### 3. 获取房间列表
```http
GET /api/v1/weapp/room/list
```

**参数:**
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| store_id | int | 是 | 门店ID |
| room_class | int | 否 | 房间类别 0棋牌 1台球 |
| status | int | 否 | 房间状态 |

**响应示例:**
```json
[
  {
    "room_id": 1,
    "room_name": "豪华棋牌室A",
    "room_call_name": "棋牌A",
    "room_class": 0,
    "store_id": 1,
    "type": 1,
    "price": 25.0,
    "deposit": 50.0,
    "work_price": 20.0,
    "tongxiao_price": 80.0,
    "label": "豪华装修,独立空调,免费WiFi",
    "image_urls": "https://images.scyanzu.com/room1.jpg,...",
    "status": 1,
    "min_hour": 2,
    "lead_hour": 4,
    "lead_day": 7,
    "reserve": true
  }
]
```

### 4. 获取房间详情
```http
GET /api/v1/weapp/room/{room_id}
```

**响应示例:**
```json
{
  "room_id": 1,
  "room_name": "豪华棋牌室A",
  "room_call_name": "棋牌A",
  "room_class": 0,
  "qr_code": "https://example.com/qr1.jpg",
  "renew_code": "https://example.com/renew1.jpg",
  "store_id": 1,
  "type": 1,
  "price": 25.0,
  "deposit": 50.0,
  "work_price": 20.0,
  "tongxiao_price": 80.0,
  "label": "豪华装修,独立空调,免费WiFi",
  "image_urls": "https://images.scyanzu.com/room1.jpg,...",
  "min_hour": 2,
  "lead_hour": 4,
  "lead_day": 7,
  "status": 1,
  "pre_price": 0.0,
  "min_charge": 0.0,
  "tx_price": 0.0,
  "morning_price": null,
  "afternoon_price": null,
  "night_price": null
}
```

---

## 📋 订单相关接口

### 5. 创建订单
```http
POST /api/v1/weapp/order/create
```

**请求体:**
```json
{
  "user_id": 1,
  "store_id": 1,
  "room_id": 1,
  "product_name": "豪华棋牌室A - 2小时",
  "product_price": 25.0,
  "product_num": 1,
  "total_price": 50.0,
  "start_time": "2024-01-01T14:00:00",
  "end_time": "2024-01-01T16:00:00",
  "use_hour": 2.0,
  "remark": "需要安静的环境"
}
```

**响应示例:**
```json
{
  "id": 1,
  "order_no": "QD202401011400001",
  "user_id": 1,
  "store_id": 1,
  "room_id": 1,
  "product_name": "豪华棋牌室A - 2小时",
  "product_price": 25.0,
  "product_num": 1,
  "total_price": 50.0,
  "start_time": "2024-01-01T14:00:00",
  "end_time": "2024-01-01T16:00:00",
  "use_hour": 2.0,
  "pay_price": 0.0,
  "pay_time": null,
  "status": 0,
  "remark": "需要安静的环境",
  "create_time": "2024-01-01T13:30:00"
}
```

### 6. 获取订单列表
```http
GET /api/v1/weapp/order/list
```

**参数:**
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| user_id | int | 是 | 用户ID |
| status | int | 否 | 订单状态 |
| page | int | 否 | 页码，默认1 |
| page_size | int | 否 | 每页数量，默认10 |

**响应示例:**
```json
{
  "total": 10,
  "page": 1,
  "page_size": 10,
  "list": [
    {
      "id": 1,
      "order_no": "QD202401011400001",
      "store_id": 1,
      "room_id": 1,
      "product_name": "豪华棋牌室A - 2小时",
      "product_price": 25.0,
      "total_price": 50.0,
      "start_time": "2024-01-01T14:00:00",
      "end_time": "2024-01-01T16:00:00",
      "use_hour": 2.0,
      "pay_price": 50.0,
      "pay_time": "2024-01-01T13:45:00",
      "status": 1,
      "remark": "需要安静的环境",
      "create_time": "2024-01-01T13:30:00"
    }
  ]
}
```

### 7. 获取订单详情
```http
GET /api/v1/weapp/order/{order_id}
```

**响应示例:**
```json
{
  "id": 1,
  "order_no": "QD202401011400001",
  "user_id": 1,
  "store_id": 1,
  "room_id": 1,
  "product_name": "豪华棋牌室A - 2小时",
  "product_price": 25.0,
  "product_num": 1,
  "total_price": 50.0,
  "start_time": "2024-01-01T14:00:00",
  "end_time": "2024-01-01T16:00:00",
  "use_hour": 2.0,
  "pay_price": 50.0,
  "pay_time": "2024-01-01T13:45:00",
  "pay_type": 1,
  "pay_order_no": "wx20240101134500",
  "status": 1,
  "remark": "需要安静的环境",
  "create_time": "2024-01-01T13:30:00"
}
```

---

## 👤 用户相关接口

### 8. 用户登录（微信小程序）
```http
POST /api/v1/weapp/user/login
```

**请求体:**
```json
{
  "code": "wx_login_code",
  "nickname": "微信用户",
  "avatar_url": "https://wx.qlogo.cn/mmopen/..."
}
```

**响应示例:**
```json
{
  "id": 1,
  "openid": "mock_openid_wx_login_code",
  "nickname": "微信用户",
  "avatar_url": "https://wx.qlogo.cn/mmopen/...",
  "phone": null,
  "balance": 100.0,
  "total_consume": 500.0
}
```

### 9. 获取用户信息
```http
GET /api/v1/weapp/user/info?user_id=1
```

**响应示例:**
```json
{
  "id": 1,
  "openid": "mock_openid_wx_login_code",
  "nickname": "微信用户",
  "avatar_url": "https://wx.qlogo.cn/mmopen/...",
  "phone": "13800138000",
  "balance": 100.0,
  "total_consume": 500.0
}
```

---

## 🏠 首页数据接口

### 10. 获取首页数据
```http
GET /api/v1/weapp/home/data
```

**响应示例:**
```json
{
  "stores": [
    {
      "store_id": 1,
      "store_name": "演示-24h棋牌室",
      "city_name": "成都",
      "head_img": "https://images.scyanzu.com/demo-store.jpg",
      "lat": 30.657349,
      "lon": 104.065837,
      "address": "四川省成都市人民南路一段86号",
      "room_num": 3,
      "label": "24小时营业,免费WiFi"
    }
  ],
  "banners": [
    {
      "image_url": "https://example.com/banner1.jpg",
      "link_url": "/pages/store/detail?id=1"
    }
  ],
  "notice": "欢迎使用24h棋牌室预约系统"
}
```

---

## 📊 状态码说明

### 订单状态
| 状态码 | 说明 |
|--------|------|
| 0 | 待支付 |
| 1 | 已支付 |
| 2 | 使用中 |
| 3 | 已完成 |
| 4 | 已取消 |
| 5 | 退款中 |
| 6 | 已退款 |

### 房间状态
| 状态码 | 说明 |
|--------|------|
| 0 | 禁用 |
| 1 | 空闲 |
| 2 | 待清洁 |
| 3 | 使用中 |
| 4 | 已预约 |

### 房间类别
| 类别码 | 说明 |
|--------|------|
| 0 | 棋牌室 |
| 1 | 台球室 |
| 2 | KTV |

---

## 🧪 测试用例

### 快速测试命令
```bash
# 1. 获取门店列表
curl http://localhost:8000/api/v1/weapp/store/list

# 2. 获取房间列表
curl "http://localhost:8000/api/v1/weapp/room/list?store_id=1"

# 3. 创建订单
curl -X POST http://localhost:8000/api/v1/weapp/order/create \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": 1,
    "store_id": 1,
    "room_id": 1,
    "product_name": "豪华棋牌室A - 2小时",
    "product_price": 25.0,
    "total_price": 50.0,
    "start_time": "2024-01-01T14:00:00",
    "end_time": "2024-01-01T16:00:00",
    "use_hour": 2.0
  }'

# 4. 获取订单列表
curl "http://localhost:8000/api/v1/weapp/order/list?user_id=1"

# 5. 用户登录
curl -X POST http://localhost:8000/api/v1/weapp/user/login \
  -H "Content-Type: application/json" \
  -d '{"code": "test_code"}'
```

---

## 🔧 错误处理

### 通用错误格式
```json
{
  "detail": "错误描述"
}
```

### 常见错误码
| HTTP状态码 | 说明 |
|-------------|------|
| 400 | 请求参数错误 |
| 404 | 资源不存在 |
| 422 | 数据验证错误 |
| 500 | 服务器内部错误 |

---

## 📱 微信小程序集成

### 小程序端配置
```javascript
// app.js
App({
  globalData: {
    baseUrl: 'http://localhost:8000/api/v1/weapp',
    userInfo: null
  },
  
  request(options) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: this.globalData.baseUrl + options.url,
        method: options.method || 'GET',
        data: options.data || {},
        header: {
          'Content-Type': 'application/json'
        },
        success: resolve,
        fail: reject
      })
    })
  }
})
```

### 使用示例
```javascript
// 获取门店列表
wx.request({
  url: 'http://localhost:8000/api/v1/weapp/store/list',
  success(res) {
    console.log('门店列表:', res.data)
  }
})

// 创建订单
wx.request({
  url: 'http://localhost:8000/api/v1/weapp/order/create',
  method: 'POST',
  data: {
    user_id: 1,
    store_id: 1,
    room_id: 1,
    product_name: '豪华棋牌室A - 2小时',
    product_price: 25,
    total_price: 50,
    start_time: '2024-01-01T14:00:00',
    end_time: '2024-01-01T16:00:00',
    use_hour: 2
  },
  success(res) {
    console.log('订单创建成功:', res.data)
  }
})