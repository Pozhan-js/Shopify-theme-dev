# 🚀 本地运行指南

## ✅ 项目已成功启动！

您的24h棋牌室后端API现在运行在：
- **本地地址**: http://localhost:8000
- **API文档**: http://localhost:8000/docs
- **备用文档**: http://localhost:8000/redoc

## 📋 快速测试

### 1. 测试基础接口
```bash
# 测试健康检查
curl http://localhost:8000/health

# 测试门店列表
curl http://localhost:8000/api/v1/store/list
```

### 2. 浏览器访问
- 打开 http://localhost:8000/docs 查看完整的API文档
- 可以直接在Swagger界面测试所有接口

## 🔧 完整版本设置

### 安装所有依赖
```bash
# 安装完整依赖
python3 -m pip install fastapi uvicorn sqlalchemy pydantic-settings python-jose[cryptography] python-dotenv

# 或使用requirements.txt
python3 -m pip install -r requirements.txt
```

### 数据库配置
1. **安装MySQL** (如果尚未安装)
2. **创建数据库**
   ```sql
   CREATE DATABASE qipaishi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
3. **配置.env文件**
   ```bash
   # 编辑 .env 文件
   DATABASE_URL=mysql+pymysql://root:password@localhost:3306/qipaishi?charset=utf8mb4
   SECRET_KEY=your-secret-key-here
   WECHAT_APP_ID=your-wechat-app-id
   WECHAT_APP_SECRET=your-wechat-app-secret
   ```

### 运行完整版本
```bash
# 停止当前简化版本 (Ctrl+C)

# 运行完整版本
python3 -m uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## 📱 微信小程序测试

### 测试数据
当前简化版本提供测试数据：
- 门店列表: 2个测试门店
- 房间列表: 可扩展
- 用户认证: 模拟登录

### 前端对接
在微信小程序中配置：
```javascript
// app.js
App({
  globalData: {
    baseUrl: 'http://localhost:8000'
  }
})
```

## 🐛 常见问题

### 端口被占用
```bash
# 使用其他端口
python3 -m uvicorn simple_test:app --reload --host 0.0.0.0 --port 8080
```

### 依赖问题
```bash
# 如果安装失败，尝试
python3 -m pip install --upgrade pip
python3 -m pip install fastapi uvicorn --user
```

### 网络访问
确保防火墙允许8000端口，或使用手机热点测试。

## 🎯 下一步

1. **配置数据库**: 设置MySQL并配置连接
2. **微信配置**: 配置微信小程序appid和secret
3. **测试API**: 使用Postman或curl测试所有接口
4. **前端对接**: 将API地址配置到微信小程序

## 📞 技术支持

如果遇到问题：
1. 检查控制台错误信息
2. 确认端口8000未被占用
3. 验证Python版本 >= 3.8
4. 查看logs/app.log日志文件

项目已成功运行！🎉