# 24h棋牌室后端API

基于FastAPI开发的24小时棋牌室预约管理系统后端服务。

## 功能特性

- 🔐 微信登录认证
- 🏢 门店管理
- 🏠 房间预约
- 📅 时间排班
- 💰 订单管理
- 🎫 优惠券系统
- 📱 微信小程序对接
- 🔄 微信支付集成

## 技术栈

- **框架**: FastAPI
- **数据库**: MySQL + SQLAlchemy ORM
- **缓存**: Redis
- **认证**: JWT Token
- **部署**: Uvicorn
- **任务队列**: Celery

## 快速开始

### 1. 环境准备

```bash
# 克隆项目
git clone <repository-url>
cd qipaishi-backend

# 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows

# 安装依赖
pip install -r requirements.txt
```

### 2. 数据库配置

```bash
# 创建数据库
mysql -u root -p
CREATE DATABASE qipaishi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# 配置环境变量
cp .env.example .env
# 编辑 .env 文件，配置数据库连接信息
```

### 3. 运行项目

```bash
# 开发模式运行
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# 生产模式运行
python main.py
```

### 4. 访问API文档

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## 项目结构

```
qipaishi-backend/
├── app/
│   ├── api/              # API路由
│   │   └── v1/          # API版本1
│   ├── core/            # 核心配置
│   │   ├── config.py    # 配置管理
│   │   ├── database.py  # 数据库连接
│   │   ├── security.py  # 安全认证
│   │   ├── logging.py   # 日志配置
│   │   └── exceptions.py # 异常处理
│   ├── models/          # 数据模型
│   ├── schemas/         # 数据验证
│   ├── services/        # 业务逻辑
│   └── utils/           # 工具函数
├── uploads/             # 文件上传目录
├── logs/               # 日志目录
├── main.py             # 应用入口
├── requirements.txt    # 依赖列表
└── README.md          # 项目说明
```

## API接口

### 认证相关
- `POST /api/v1/member/auth/login` - 微信登录
- `GET /api/v1/member/info` - 获取用户信息
- `PUT /api/v1/member/info` - 更新用户信息

### 门店相关
- `GET /api/v1/store/list` - 获取门店列表
- `GET /api/v1/store/detail/{store_id}` - 获取门店详情
- `GET /api/v1/store/room/list` - 获取房间列表
- `GET /api/v1/store/room/schedule` - 获取房间排班

### 订单相关
- `POST /api/v1/order/create` - 创建订单
- `GET /api/v1/order/list` - 获取订单列表
- `GET /api/v1/order/detail/{order_id}` - 获取订单详情
- `POST /api/v1/order/pay/{order_id}` - 支付订单
- `POST /api/v1/order/cancel/{order_id}` - 取消订单

### 商品相关
- `GET /api/v1/product/list` - 获取商品列表
- `GET /api/v1/product/coupon/list` - 获取优惠券列表
- `POST /api/v1/product/coupon/receive/{coupon_id}` - 领取优惠券

## 环境变量

复制 `.env.example` 为 `.env` 并配置以下参数：

```bash
# 数据库
DATABASE_URL=mysql+pymysql://user:password@localhost:3306/qipaishi

# 微信小程序
WECHAT_APP_ID=your-app-id
WECHAT_APP_SECRET=your-app-secret

# 微信支付
WECHAT_MCH_ID=your-mch-id
WECHAT_MCH_KEY=your-mch-key
```

## 部署

### Docker部署

```bash
# 构建镜像
docker build -t qipaishi-backend .

# 运行容器
docker run -d \
  --name qipaishi-backend \
  -p 8000:8000 \
  -v $(pwd)/.env:/app/.env \
  qipaishi-backend
```

### 生产环境

建议使用以下配置：
- Nginx反向代理
- Gunicorn + Uvicorn工作进程
- MySQL主从复制
- Redis集群
- 负载均衡

## 开发规范

### 代码风格
- 使用Black格式化代码
- 遵循PEP 8规范
- 添加类型注解

### 提交规范
- 使用Conventional Commits
- 示例: `feat: 添加用户登录功能`

## 许可证

MIT License