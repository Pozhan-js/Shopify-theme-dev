#!/usr/bin/env python3
"""
创建基础设施日志表
基于migrate.sql中的定义
"""

import asyncio
import logging
from sqlalchemy import text
from app.core.database import engine
from app.models.infra_log import Base

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def create_infra_tables():
    """创建基础设施日志表"""
    try:
        # 创建表
        logger.info("开始创建基础设施日志表...")
        Base.metadata.create_all(bind=engine)
        logger.info("基础设施日志表创建成功")
        
        # 检查表是否存在
        with engine.connect() as conn:
            # 检查infra_api_access_log表
            result = conn.execute(text("SHOW TABLES LIKE 'infra_api_access_log'"))
            access_table_exists = result.fetchone() is not None
            
            # 检查infra_api_error_log表
            result = conn.execute(text("SHOW TABLES LIKE 'infra_api_error_log'"))
            error_table_exists = result.fetchone() is not None
            
            if access_table_exists and error_table_exists:
                logger.info("✅ 所有基础设施日志表已创建成功")
            else:
                logger.error("❌ 部分表创建失败")
                
    except Exception as e:
        logger.error(f"创建表失败: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(create_infra_tables())