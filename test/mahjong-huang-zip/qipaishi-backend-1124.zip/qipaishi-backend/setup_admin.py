#!/usr/bin/env python3
"""
后台管理系统初始化脚本
"""

import os
import sys
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.core.config import settings
from app.core.security import get_password_hash
from app.models.admin import AdminUser
from app.models.base import Base

def init_admin_tables():
    """初始化管理员相关表"""
    print("正在初始化管理员相关表...")
    
    # 创建数据库连接
    engine = create_engine(settings.DATABASE_URL)
    Base.metadata.create_all(bind=engine)
    
    # 创建会话
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()
    
    try:
        # 检查是否已存在管理员
        admin_count = db.query(AdminUser).filter(AdminUser.deleted == False).count()
        
        if admin_count == 0:
            # 创建默认超级管理员
            admin = AdminUser(
                username="admin",
                password_hash=get_password_hash("admin123"),
                real_name="超级管理员",
                email="admin@example.com",
                role="super_admin",
                status=1
            )
            db.add(admin)
            db.commit()
            print("✅ 默认管理员创建成功")
            print("   用户名: admin")
            print("   密码: admin123")
        else:
            print("✅ 管理员已存在，跳过创建")
            
    except Exception as e:
        print(f"❌ 初始化失败: {e}")
        db.rollback()
    finally:
        db.close()

def check_requirements():
    """检查环境要求"""
    print("正在检查环境要求...")
    
    # 检查Python版本
    if sys.version_info < (3, 8):
        print("❌ Python版本需要3.8以上")
        return False
    
    print("✅ Python版本检查通过")
    
    # 检查数据库连接
    try:
        engine = create_engine(settings.DATABASE_URL)
        engine.connect()
        print("✅ 数据库连接正常")
        return True
    except Exception as e:
        print(f"❌ 数据库连接失败: {e}")
        return False

def main():
    """主函数"""
    print("=" * 50)
    print("24h棋牌室后台管理系统初始化")
    print("=" * 50)
    
    # 检查环境
    if not check_requirements():
        print("环境检查未通过，请修复后重试")
        return
    
    # 初始化管理员表
    init_admin_tables()
    
    print("\n" + "=" * 50)
    print("初始化完成！")
    print("=" * 50)
    print("启动服务命令:")
    print("uvicorn app.main:app --reload --host 0.0.0.0 --port 8000")
    print("\n访问地址:")
    print("- Swagger文档: http://localhost:8000/docs")
    print("- 后台管理接口: http://localhost:8000/api/v1/admin")

if __name__ == "__main__":
    main()