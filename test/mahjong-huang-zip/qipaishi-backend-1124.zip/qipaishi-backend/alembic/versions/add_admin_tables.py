"""add admin tables

Revision ID: 2024112301
Revises: 
Create Date: 2024-11-23 18:00:00.000000

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '2024112301'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    # 创建管理员用户表
    op.create_table('admin_user',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('username', sa.String(length=50), nullable=False),
        sa.Column('password_hash', sa.String(length=255), nullable=False),
        sa.Column('real_name', sa.String(length=50), nullable=True),
        sa.Column('email', sa.String(length=100), nullable=True),
        sa.Column('phone', sa.String(length=20), nullable=True),
        sa.Column('avatar', sa.String(length=255), nullable=True),
        sa.Column('role', sa.String(length=20), nullable=False, server_default='admin'),
        sa.Column('status', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('last_login_time', sa.DateTime(), nullable=True),
        sa.Column('last_login_ip', sa.String(length=50), nullable=True),
        sa.Column('login_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('remark', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False, server_default='0'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('username')
    )
    
    # 创建管理员登录日志表
    op.create_table('admin_login_log',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('login_time', sa.DateTime(), nullable=False),
        sa.Column('login_ip', sa.String(length=50), nullable=True),
        sa.Column('user_agent', sa.String(length=500), nullable=True),
        sa.Column('login_result', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('failure_reason', sa.String(length=255), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False, server_default='0'),
        sa.ForeignKeyConstraint(['user_id'], ['admin_user.id']),
        sa.PrimaryKeyConstraint('id')
    )
    
    # 创建管理员操作日志表
    op.create_table('admin_operation_log',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('operation_module', sa.String(length=50), nullable=True),
        sa.Column('operation_type', sa.String(length=20), nullable=True),
        sa.Column('operation_desc', sa.String(length=255), nullable=True),
        sa.Column('request_url', sa.String(length=255), nullable=True),
        sa.Column('request_method', sa.String(length=10), nullable=True),
        sa.Column('request_params', sa.Text(), nullable=True),
        sa.Column('response_data', sa.Text(), nullable=True),
        sa.Column('ip_address', sa.String(length=50), nullable=True),
        sa.Column('user_agent', sa.String(length=500), nullable=True),
        sa.Column('operation_time', sa.DateTime(), nullable=False),
        sa.Column('execution_time', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False, server_default='0'),
        sa.ForeignKeyConstraint(['user_id'], ['admin_user.id']),
        sa.PrimaryKeyConstraint('id')
    )
    
    # 创建管理员菜单表
    op.create_table('admin_menu',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('parent_id', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('name', sa.String(length=50), nullable=False),
        sa.Column('path', sa.String(length=255), nullable=True),
        sa.Column('component', sa.String(length=255), nullable=True),
        sa.Column('icon', sa.String(length=50), nullable=True),
        sa.Column('sort_order', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('status', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('menu_type', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('permission', sa.String(length=100), nullable=True),
        sa.Column('remark', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False, server_default='0'),
        sa.PrimaryKeyConstraint('id')
    )
    
    # 创建管理员角色表
    op.create_table('admin_role',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(length=50), nullable=False),
        sa.Column('code', sa.String(length=50), nullable=False),
        sa.Column('description', sa.String(length=255), nullable=True),
        sa.Column('status', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('sort_order', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('remark', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False, server_default='0'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('code'),
        sa.UniqueConstraint('name')
    )
    
    # 插入默认管理员
    from app.core.security import get_password_hash
    op.execute(
        "INSERT INTO admin_user (username, password_hash, real_name, role, status, created_at, updated_at) VALUES ('admin', '{}', '超级管理员', 'super_admin', 1, NOW(), NOW())".format(
            get_password_hash("admin123")
        )
    )


def downgrade():
    op.drop_table('admin_role')
    op.drop_table('admin_menu')
    op.drop_table('admin_operation_log')
    op.drop_table('admin_login_log')
    op.drop_table('admin_user')