"""add member store tables

Revision ID: 2024112302
Revises: 2024112301
Create Date: 2024-11-23 18:30:00.000000

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '2024112302'
down_revision = '2024112301'
branch_labels = None
depends_on = None


def upgrade():
    # 创建会员门店信息表
    op.create_table('member_store_info',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('member_id', sa.Integer(), nullable=False),
        sa.Column('store_name', sa.String(length=100), nullable=False),
        sa.Column('store_address', sa.String(length=255), nullable=True),
        sa.Column('store_phone', sa.String(length=20), nullable=True),
        sa.Column('business_license', sa.String(length=100), nullable=True),
        sa.Column('legal_person', sa.String(length=50), nullable=True),
        sa.Column('legal_phone', sa.String(length=20), nullable=True),
        sa.Column('legal_id_card', sa.String(length=18), nullable=True),
        sa.Column('store_images', sa.Text(), nullable=True),
        sa.Column('license_images', sa.Text(), nullable=True),
        sa.Column('id_card_images', sa.Text(), nullable=True),
        sa.Column('status', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('audit_remark', sa.Text(), nullable=True),
        sa.Column('audit_time', sa.DateTime(), nullable=True),
        sa.Column('audit_admin_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False, server_default='0'),
        sa.ForeignKeyConstraint(['member_id'], ['member.id']),
        sa.PrimaryKeyConstraint('id')
    )
    
    # 创建会员门店员工表
    op.create_table('member_store_staff',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('member_id', sa.Integer(), nullable=False),
        sa.Column('store_id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=50), nullable=False),
        sa.Column('phone', sa.String(length=20), nullable=False),
        sa.Column('position', sa.String(length=50), nullable=True),
        sa.Column('id_card', sa.String(length=18), nullable=True),
        sa.Column('status', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('hire_date', sa.DateTime(), nullable=True),
        sa.Column('leave_date', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.Column('deleted', sa.Boolean(), nullable=False, server_default='0'),
        sa.ForeignKeyConstraint(['member_id'], ['member.id']),
        sa.ForeignKeyConstraint(['store_id'], ['member_store_info.id']),
        sa.PrimaryKeyConstraint('id')
    )
    
    # 创建索引
    op.create_index('idx_member_store_member_id', 'member_store_info', ['member_id'])
    op.create_index('idx_member_store_status', 'member_store_info', ['status'])
    op.create_index('idx_member_store_staff_store_id', 'member_store_staff', ['store_id'])
    op.create_index('idx_member_store_staff_status', 'member_store_staff', ['status'])


def downgrade():
    op.drop_index('idx_member_store_staff_status', 'member_store_staff')
    op.drop_index('idx_member_store_staff_store_id', 'member_store_staff')
    op.drop_index('idx_member_store_status', 'member_store_info')
    op.drop_index('idx_member_store_member_id', 'member_store_info')
    op.drop_table('member_store_staff')
    op.drop_table('member_store_info')