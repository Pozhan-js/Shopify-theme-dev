# 基础设施日志API文档

## 概述
本文档描述了基于migrate.sql中定义的`infra_api_access_log`和`infra_api_error_log`表的基础设施日志管理接口。

## 接口列表

### 1. API访问日志管理

#### 1.1 获取API访问日志列表
- **接口地址**: `GET /api/v1/admin/infra-log/access-log/list`
- **权限要求**: 管理员权限
- **请求参数**:
  - `page` (int, 可选): 页码，默认1
  - `page_size` (int, 可选): 每页条数，默认10，最大100
  - `user_id` (int, 可选): 用户编号筛选
  - `user_type` (int, 可选): 用户类型筛选
  - `application_name` (str, 可选): 应用名模糊搜索
  - `request_url` (str, 可选): 请求地址模糊搜索
  - `result_code` (int, 可选): 结果码筛选
  - `start_date` (str, 可选): 开始日期，格式YYYY-MM-DD
  - `end_date` (str, 可选): 结束日期，格式YYYY-MM-DD

- **响应示例**:
```json
{
  "list": [
    {
      "id": 1,
      "trace_id": "trace-123456",
      "user_id": 1001,
      "user_type": 1,
      "application_name": "qipaishi-backend",
      "request_method": "POST",
      "request_url": "/api/v1/member/login",
      "request_params": "{\"username\":\"test\",\"password\":\"***\"}",
      "user_ip": "192.168.1.100",
      "user_agent": "Mozilla/5.0...",
      "begin_time": "2024-01-01T10:00:00",
      "end_time": "2024-01-01T10:00:01",
      "duration": 100,
      "result_code": 0,
      "result_msg": "success",
      "create_time": "2024-01-01T10:00:01"
    }
  ],
  "total": 100,
  "page": 1,
  "page_size": 10
}
```

#### 1.2 获取API访问日志详情
- **接口地址**: `GET /api/v1/admin/infra-log/access-log/{log_id}`
- **权限要求**: 管理员权限
- **路径参数**:
  - `log_id` (int): 日志ID

### 2. API错误日志管理

#### 2.1 获取API错误日志列表
- **接口地址**: `GET /api/v1/admin/infra-log/error-log/list`
- **权限要求**: 管理员权限
- **请求参数**:
  - `page` (int, 可选): 页码，默认1
  - `page_size` (int, 可选): 每页条数，默认10，最大100
  - `user_id` (int, 可选): 用户编号筛选
  - `user_type` (int, 可选): 用户类型筛选
  - `application_name` (str, 可选): 应用名模糊搜索
  - `request_url` (str, 可选): 请求地址模糊搜索
  - `exception_name` (str, 可选): 异常名模糊搜索
  - `process_status` (int, 可选): 处理状态筛选
  - `start_date` (str, 可选): 开始日期，格式YYYY-MM-DD
  - `end_date` (str, 可选): 结束日期，格式YYYY-MM-DD

- **响应示例**:
```json
{
  "list": [
    {
      "id": 1,
      "trace_id": "trace-123456",
      "user_id": 1001,
      "user_type": 1,
      "application_name": "qipaishi-backend",
      "request_method": "POST",
      "request_url": "/api/v1/member/login",
      "request_params": "{\"username\":\"test\",\"password\":\"***\"}",
      "user_ip": "192.168.1.100",
      "user_agent": "Mozilla/5.0...",
      "exception_time": "2024-01-01T10:00:00",
      "exception_name": "java.lang.NullPointerException",
      "exception_message": "NullPointerException: null",
      "exception_root_cause_message": "NullPointerException: null",
      "exception_stack_trace": "...",
      "exception_class_name": "com.example.TestController",
      "exception_file_name": "TestController.java",
      "exception_method_name": "testMethod",
      "exception_line_number": 123,
      "process_status": 0,
      "process_time": null,
      "process_user_id": 0,
      "create_time": "2024-01-01T10:00:01"
    }
  ],
  "total": 50,
  "page": 1,
  "page_size": 10
}
```

#### 2.2 获取API错误日志详情
- **接口地址**: `GET /api/v1/admin/infra-log/error-log/{log_id}`
- **权限要求**: 管理员权限
- **路径参数**:
  - `log_id` (int): 日志ID

#### 2.3 处理API错误日志
- **接口地址**: `PUT /api/v1/admin/infra-log/error-log/{log_id}/process`
- **权限要求**: 管理员权限
- **路径参数**:
  - `log_id` (int): 日志ID
- **请求体**:
```json
{
  "process_status": 1,
  "process_user_id": 1
}
```
- **处理状态说明**:
  - `0`: 未处理
  - `1`: 已处理
  - `2`: 已忽略

### 3. 统计接口

#### 3.1 获取日志统计概览
- **接口地址**: `GET /api/v1/admin/infra-log/stats/summary`
- **权限要求**: 管理员权限
- **请求参数**:
  - `days` (int, 可选): 统计天数，默认7天，最大30天

- **响应示例**:
```json
{
  "access_stats": {
    "total_requests": 1000,
    "success_requests": 950,
    "error_requests": 50,
    "success_rate": 95.0,
    "avg_duration": 150.5
  },
  "error_stats": {
    "total_errors": 50,
    "unprocessed_errors": 20,
    "processed_errors": 30,
    "process_rate": 60.0
  },
  "daily_trend": [
    {
      "date": "2024-01-01",
      "access_count": 150,
      "error_count": 5
    }
  ]
}
```

## 数据模型

### InfraApiAccessLog (API访问日志)
| 字段名 | 类型 | 描述 |
|--------|------|------|
| id | bigint | 日志主键 |
| trace_id | varchar(64) | 链路追踪编号 |
| user_id | bigint | 用户编号 |
| user_type | tinyint | 用户类型 |
| application_name | varchar(50) | 应用名 |
| request_method | varchar(16) | 请求方法名 |
| request_url | varchar(255) | 请求地址 |
| request_params | varchar(8000) | 请求参数 |
| user_ip | varchar(50) | 用户IP |
| user_agent | varchar(512) | 浏览器UA |
| begin_time | datetime | 开始请求时间 |
| end_time | datetime | 结束请求时间 |
| duration | int | 执行时长(ms) |
| result_code | int | 结果码 |
| result_msg | varchar(512) | 结果提示 |

### InfraApiErrorLog (API错误日志)
| 字段名 | 类型 | 描述 |
|--------|------|------|
| id | int | 编号 |
| trace_id | varchar(64) | 链路追踪编号 |
| user_id | int | 用户编号 |
| user_type | tinyint | 用户类型 |
| application_name | varchar(50) | 应用名 |
| request_method | varchar(16) | 请求方法名 |
| request_url | varchar(255) | 请求地址 |
| request_params | varchar(8000) | 请求参数 |
| user_ip | varchar(50) | 用户IP |
| user_agent | varchar(512) | 浏览器UA |
| exception_time | datetime | 异常发生时间 |
| exception_name | varchar(128) | 异常名 |
| exception_message | text | 异常消息 |
| exception_root_cause_message | text | 异常根消息 |
| exception_stack_trace | text | 异常栈轨迹 |
| exception_class_name | varchar(512) | 异常类名 |
| exception_file_name | varchar(512) | 异常文件名 |
| exception_method_name | varchar(512) | 异常方法名 |
| exception_line_number | int | 异常行号 |
| process_status | tinyint | 处理状态 |
| process_time | datetime | 处理时间 |
| process_user_id | int | 处理用户编号 |

## 使用说明

1. **部署前准备**:
   - 确保已运行数据库迁移脚本
   - 执行: `python create_infra_tables.py`

2. **权限验证**:
   - 所有接口都需要管理员权限
   - 需要在请求头中添加有效的管理员token

3. **日志记录**:
   - 建议配合中间件自动记录API访问日志
   - 错误日志建议在异常处理中自动记录

4. **性能优化**:
   - 建议对频繁查询的字段添加索引
   - 定期清理历史日志数据