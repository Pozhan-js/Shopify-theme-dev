# 🚀 24h棋牌室后端启动指南

## 📋 环境要求

### 系统环境
- **操作系统**: macOS 10.15+ / Ubuntu 18.04+ / Windows 10+
- **Python**: 3.8+ (运行 `python3 --version`)
- **MySQL**: 8.0+ (运行 `mysql --version`)
- **网络**: 确保可以访问互联网

### 开发工具
- Git
- 代码编辑器 (VS Code推荐)
- MySQL客户端

## 🔧 快速启动

### 方法1：一键启动（推荐）

```bash
# 1. 进入项目目录
cd qipaishi-backend

# 2. 运行一键启动脚本
./quick_start.sh
```

### 方法2：手动启动

#### 1. 环境检查
```bash
# 检查Python版本
python3 --version

# 检查MySQL版本
mysql --version
```

#### 2. 创建虚拟环境
```bash
# 创建虚拟环境
python3 -m venv venv

# 激活虚拟环境
source venv/bin/activate  # macOS/Linux
# 或
venv\Scripts\activate  # Windows
```

#### 3. 安装依赖
```bash
pip install -r requirements.txt
```

#### 4. 数据库配置
```bash
# 创建数据库
mysql -u root -p -e "CREATE DATABASE qipaishi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# 配置环境变量
cp .env.example .env
# 编辑 .env 文件，配置数据库连接信息
```

#### 5. 启动服务
```bash
# 开发模式
python3 -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# 生产模式
python main.py
```

## ✅ 验证启动

### 服务状态检查
1. **服务启动**: 终端显示 `Uvicorn running on http://0.0.0.0:8000`
2. **健康检查**: `curl http://localhost:8000/health` 返回 `{"status":"healthy"}`
3. **API文档**: 浏览器访问 `http://localhost:8000/docs` 正常显示
4. **数据库**: 表结构自动创建完成

### 测试API端点
```bash
# 基础测试
curl http://localhost:8000/
curl http://localhost:8000/health

# 如果数据库已配置
curl http://localhost:8000/api/v1/store/list
```

## 🐛 常见问题解决

### 端口占用问题
```bash
# 检查端口占用
lsof -ti :8000,8001,8002,8003,8004

# 杀死占用进程
kill -9 <PID>
```

### 数据库连接问题
```bash
# 检查MySQL服务
mysqladmin -u root -p status

# 检查数据库
mysql -u root -p -e "SHOW DATABASES LIKE 'qipaishi';"
```

### 依赖问题
```bash
# 重新安装依赖
pip install -r requirements.txt --force-reinstall

# 清理缓存
pip cache purge
```

## 📱 微信小程序配置

### 开发环境配置
```javascript
// 小程序配置
const config = {
  baseUrl: 'http://localhost:8000',
  apiVersion: '/api/v1',
  timeout: 10000
}

// 测试连接
wx.request({
  url: config.baseUrl + '/health',
  success: (res) => {
    console.log('后端连接成功:', res.data)
  }
})
```

## 🎯 成功标准

当以下所有条件满足时，表示部署成功：

- [ ] ✅ Python 3.8+ 运行正常
- [ ] ✅ MySQL 8.0+ 运行正常（或使用SQLite测试）
- [ ] ✅ 虚拟环境已激活
- [ ] ✅ 所有依赖安装完成
- [ ] ✅ 数据库已创建
- [ ] ✅ 服务启动无错误
- [ ] ✅ 端口8000可访问
- [ ] ✅ API文档可打开
- [ ] ✅ 健康检查通过

## 🆘 故障排除

### 快速重启
```bash
# 如果服务异常，使用以下命令重启
pkill -f uvicorn
python3 -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 日志查看
```bash
# 查看应用日志
tail -f logs/app.log

# 查看系统日志
journalctl -u qipaishi-backend -f
```

## 🎉 部署完成

当看到以下信息时，表示服务已成功运行：

```
🎯 服务启动成功！
📍 访问地址: http://localhost:8000
📚 API文档: http://localhost:8000/docs
🔍 健康检查: http://localhost:8000/health
```

**恭喜！现在可以开始开发前端小程序了！** 🎊