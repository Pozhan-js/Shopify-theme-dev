# 📚 项目文档目录

## 📖 快速开始
- [项目主页](../README.md) - 项目介绍和快速开始
- [启动指南](STARTUP.md) - 详细启动步骤

## 🔧 技术文档
- [API文档](API/) - API接口文档
- [数据库文档](DATABASE/) - 数据库配置和结构
- [部署指南](DEPLOYMENT/) - 部署相关文档

## 🔗 集成文档
- [微信小程序集成](INTEGRATION/WEAPP.md)
- [支付集成](INTEGRATION/PAYMENT.md)

## 📁 文档结构
```
docs/
├── README.md           # 本文档
├── STARTUP.md          # 启动指南
├── API/                # API文档
├── DATABASE/           # 数据库文档
├── DEPLOYMENT/         # 部署文档
└── INTEGRATION/        # 集成文档
```

## 🆘 获取帮助
- 查看 [启动检查清单](../STARTUP_CHECKLIST.md)
- 查看 [文档整理总结](../DOCUMENTATION_SUMMARY.md)
- 提交Issue获取技术支持
