# 基础设施日志系统设置指南

## 概述
本指南帮助您完成基于migrate.sql的基础设施日志系统的部署和配置。

## 已添加的组件

### 1. 数据模型 (app/models/infra_log.py)
- `InfraApiAccessLog`: API访问日志模型
- `InfraApiErrorLog`: API错误日志模型

### 2. 数据验证 (app/schemas/infra_log.py)
- `InfraApiAccessLogResponse`: API访问日志响应模型
- `InfraApiErrorLogResponse`: API错误日志响应模型
- `InfraApiErrorLogUpdate`: API错误日志更新模型

### 3. API接口 (app/api/admin/infra_log.py)
- 完整的RESTful API接口，支持CRUD操作
- 包含统计和分析功能

### 4. 路由配置
- 已集成到现有的admin路由系统中
- 访问路径: `/api/v1/admin/infra-log/`

## 快速开始

### 步骤1: 安装依赖
```bash
pip install -r requirements.txt
```

### 步骤2: 创建数据库表
```bash
python create_infra_tables.py
```

### 步骤3: 启动应用
```bash
python main.py
```

## API接口详情

### 基础路径
所有接口的基础路径为: `http://localhost:8000/api/v1/admin/infra-log`

### 可用接口

#### API访问日志
- `GET /access-log/list` - 获取访问日志列表
- `GET /access-log/{log_id}` - 获取访问日志详情

#### API错误日志
- `GET /error-log/list` - 获取错误日志列表
- `GET /error-log/{log_id}` - 获取错误日志详情
- `PUT /error-log/{log_id}/process` - 处理错误日志

#### 统计分析
- `GET /stats/summary` - 获取日志统计概览

## 使用示例

### 1. 获取API访问日志
```bash
curl -X GET "http://localhost:8000/api/v1/admin/infra-log/access-log/list?page=1&page_size=10" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```

### 2. 获取API错误日志
```bash
curl -X GET "http://localhost:8000/api/v1/admin/infra-log/error-log/list?process_status=0" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```

### 3. 处理错误日志
```bash
curl -X PUT "http://localhost:8000/api/v1/admin/infra-log/error-log/1/process" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"process_status": 1, "process_user_id": 1}'
```

### 4. 获取统计信息
```bash
curl -X GET "http://localhost:8000/api/v1/admin/infra-log/stats/summary?days=7" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```

## 数据库表结构

### infra_api_access_log
完整的API访问日志表，包含以下字段：
- 请求追踪信息 (trace_id)
- 用户信息 (user_id, user_type)
- 请求详情 (method, url, params)
- 客户端信息 (ip, user_agent)
- 性能指标 (duration)
- 响应结果 (result_code, result_msg)

### infra_api_error_log
详细的API错误日志表，包含以下字段：
- 错误追踪信息 (trace_id)
- 完整的异常信息 (异常名、消息、栈轨迹)
- 代码定位信息 (类名、文件名、方法名、行号)
- 处理状态跟踪 (process_status, process_time)

## 集成建议

### 1. 自动日志记录
建议在应用中集成自动日志记录中间件：

```python
# 示例：FastAPI中间件
@app.middleware("http")
async def log_requests(request: Request, call_next):
    # 记录访问日志
    # 处理异常并记录错误日志
    pass
```

### 2. 性能优化
- 对频繁查询的字段添加索引
- 定期清理历史数据
- 考虑使用分区表处理大量数据

### 3. 监控告警
- 设置错误率阈值告警
- 监控API响应时间
- 跟踪未处理的错误日志

## 故障排除

### 常见问题

1. **表不存在**
   - 运行: `python create_infra_tables.py`

2. **权限错误**
   - 确保使用管理员token访问
   - 检查用户角色权限

3. **数据格式错误**
   - 检查日期格式是否为YYYY-MM-DD
   - 验证数字参数范围

### 调试工具

1. **查看API文档**
   - 启动后访问: `http://localhost:8000/docs`

2. **数据库检查**
   ```sql
   SHOW TABLES LIKE 'infra_api_%';
   DESCRIBE infra_api_access_log;
   DESCRIBE infra_api_error_log;
   ```

## 扩展功能

### 计划中的功能
- [ ] 日志导出功能
- [ ] 高级搜索和过滤
- [ ] 实时告警通知
- [ ] 性能分析报告
- [ ] 日志归档策略

### 自定义配置
可以在配置文件中调整以下参数：
- 日志保留天数
- 分页大小限制
- 统计时间窗口
- 异常处理策略

## 技术支持

如有问题，请检查：
1. 应用日志: `logs/app.log`
2. 数据库连接配置
3. 权限设置
4. API文档: `/docs` 或 `/redoc`