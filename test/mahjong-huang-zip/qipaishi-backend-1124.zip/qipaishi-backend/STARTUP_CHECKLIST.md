# ✅ 新设备启动检查清单

## 📋 部署前准备

### 🔍 系统环境检查
- [ ] **操作系统**: macOS 10.15+ / Ubuntu 18.04+ / Windows 10+
- [ ] **Python**: 3.8+ (运行 `python3 --version`)
- [ ] **MySQL**: 8.0+ (运行 `mysql --version`)
- [ ] **网络**: 确保可以访问互联网

### 📁 项目文件检查
- [ ] **项目目录**: `qipaishi-backend/` 完整
- [ ] **关键文件存在**:
  - [ ] `requirements.txt` (依赖列表)
  - [ ] `main.py` (主入口)
  - [ ] `app/` (应用目录)
  - [ ] `.env` (配置文件)
  - [ ] `COMPLETE_STARTUP_GUIDE.md` (完整指南)

---

## 🚀 一键启动步骤

### 方法1：使用一键脚本（推荐）
```bash
# 1. 进入项目目录
cd qipaishi-backend

# 2. 运行一键启动脚本
./quick_start.sh
```

### 方法2：手动步骤
```bash
# 1. 环境检查
python3 --version
mysql --version

# 2. 创建虚拟环境
python3 -m venv venv
source venv/bin/activate  # macOS/Linux
# 或 venv\Scripts\activate  # Windows

# 3. 安装依赖
pip install -r requirements.txt

# 4. 配置数据库
mysql -u root -p -e "CREATE DATABASE qipaishi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# 5. 启动服务
python3 -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

---

## 🔧 快速故障排除

### 常见问题速查

| 问题症状 | 解决方案 |
|----------|----------|
| `python3: command not found` | 安装Python 3.8+ |
| `mysql: command not found` | 安装MySQL 8.0+ |
| `Port 8000 already in use` | 使用端口8001-8004 |
| `Access denied for user 'root'@'localhost'` | 检查MySQL密码 |
| `ModuleNotFoundError` | 重新安装依赖 |

### 端口检查命令
```bash
# 检查端口占用
lsof -ti :8000,8001,8002,8003,8004

# 杀死占用进程
kill -9 <PID>
```

### 数据库检查命令
```bash
# 检查MySQL服务
mysqladmin -u root -p status

# 检查数据库
mysql -u root -p -e "SHOW DATABASES LIKE 'qipaishi';"
```

---

## 📊 验证步骤

### 启动后验证
1. **服务启动**: 终端显示 `Uvicorn running on http://0.0.0.0:8000`
2. **健康检查**: `curl http://localhost:8000/health` 返回 `{"status":"healthy"}`
3. **API文档**: 浏览器访问 `http://localhost:8000/docs` 正常显示
4. **数据库**: 表结构自动创建完成

### 测试API端点
```bash
# 基础测试
curl http://localhost:8000/
curl http://localhost:8000/health

# 如果数据库已配置
curl http://localhost:8000/api/v1/store/list
```

---

## 📱 微信小程序配置

### 开发环境配置
```javascript
// 小程序配置
const config = {
  baseUrl: 'http://localhost:8000',
  apiVersion: '/api/v1',
  timeout: 10000
}

// 测试连接
wx.request({
  url: config.baseUrl + '/health',
  success: (res) => {
    console.log('后端连接成功:', res.data)
  }
})
```

---

## 🎯 成功标准

当以下所有条件满足时，表示部署成功：

- [ ] ✅ Python 3.8+ 运行正常
- [ ] ✅ MySQL 8.0+ 运行正常
- [ ] ✅ 虚拟环境已激活
- [ ] ✅ 所有依赖安装完成
- [ ] ✅ 数据库已创建
- [ ] ✅ 服务启动无错误
- [ ] ✅ 端口8000可访问
- [ ] ✅ API文档可打开
- [ ] ✅ 健康检查通过

---

## 🆘 紧急联系

### 技术支持
- **项目文档**: `COMPLETE_STARTUP_GUIDE.md`
- **一键脚本**: `./quick_start.sh`
- **日志文件**: `logs/app.log`

### 快速重启
```bash
# 如果服务异常，使用以下命令重启
pkill -f uvicorn
./quick_start.sh
```

---

## 🎉 部署完成！

当看到这个界面时，你的24h棋牌室后端服务已经成功运行：

```
🎯 服务启动成功！
📍 访问地址: http://localhost:8000
📚 API文档: http://localhost:8000/docs
🔍 健康检查: http://localhost:8000/health
```

**恭喜！现在可以开始开发前端小程序了！** 🎊